import { supabase } from '/assets/supabase/supabase-client.js';
import { SUPABASE_CONFIG } from '/assets/supabase/supabase-config.js';
import { PUBLIC_SIGNUP_ROLES } from '/assets/config/app.config.js';

export async function signUpUNIBOX({ fullName, email, password, role }) {
  const normalizedRole = String(role || '').trim();

  if (!PUBLIC_SIGNUP_ROLES.includes(normalizedRole)) {
    throw new Error('Ce rôle ne peut pas être créé depuis l’inscription publique UNIBOX.');
  }

  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${SUPABASE_CONFIG.siteUrl}/index-enhanced.html#signin`,
      data: {
        full_name: fullName,
        role: normalizedRole,
      },
    },
  });

  if (error) throw error;
  return data;
}

export async function signInUNIBOX({ email, password }) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;
  return data;
}

export async function signOutUNIBOX() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function requestPasswordResetUNIBOX(email) {
  const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${SUPABASE_CONFIG.siteUrl}/auth/reset-password.html`,
  });

  if (error) throw error;
  return data;
}

export async function updatePasswordUNIBOX(newPassword) {
  const { data, error } = await supabase.auth.updateUser({
    password: newPassword,
  });

  if (error) throw error;
  return data;
}
