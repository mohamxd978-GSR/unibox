import {
  qsa,
  qs,
  go,
  setPendingSignup,
  getPendingSignup,
  clearPendingSignup,
  appToast,
  setLoading,
  setAppFlash,
} from '/assets/js/unibox-core.js';
import { ROUTES, ROLE_LABELS, PUBLIC_SIGNUP_ROLES } from '/assets/config/app.config.js';
import {
  signInUNIBOX,
  signOutUNIBOX,
  signUpUNIBOX,
  requestPasswordResetUNIBOX,
  updatePasswordUNIBOX,
} from '/assets/supabase/unibox-auth.js';
import {
  completeOnboardingForCurrentUser,
  getCurrentProfile,
  getRoleProfile,
  redirectAfterLogin,
  touchCurrentProfileLogin,
} from '/assets/supabase/unibox-profile.js';

function showError(box, message) {
  if (!box) {
    appToast(message, 'error');
    return;
  }

  box.textContent = message;
  box.classList.remove('hidden');
}

function hideBox(box) {
  box?.classList.add('hidden');
}

function initLoginPage() {
  const form = qs('#loginForm');
  const submit = qs('#loginSubmit');
  const forgot = qs('[data-link="forgot-password"]');
  const signup = qs('[data-link="signup"]');

  forgot?.addEventListener('click', (e) => {
    e.preventDefault();
    go(ROUTES.auth.forgotPassword);
  });

  signup?.addEventListener('click', (e) => {
    e.preventDefault();
    go(ROUTES.auth.signup);
  });

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = qs('#loginEmail')?.value.trim();
    const password = qs('#loginPassword')?.value;
    const errorBox = qs('#loginError');

    hideBox(errorBox);

    try {
      setLoading(submit, true, 'Connexion...');
      await signInUNIBOX({ email, password });
      await touchCurrentProfileLogin().catch(() => null);
      setAppFlash({
        message: 'Connexion réussie. Bon retour sur UNIBOX.',
        type: 'success',
      });
      await redirectAfterLogin();
    } catch (error) {
      showError(errorBox, error.message || 'Connexion impossible.');
    } finally {
      setLoading(submit, false);
    }
  });
}

function initSignupPage() {
  const form = qs('#signupForm');
  const submit = qs('#signupSubmit');
  const loginLink = qs('[data-link="login"]');
  const pending = getPendingSignup();

  if (pending) {
    if (qs('#signupFullName')) qs('#signupFullName').value = pending.fullName || '';
    if (qs('#signupEmail')) qs('#signupEmail').value = pending.email || '';
    if (qs('#signupPassword')) qs('#signupPassword').value = pending.password || '';
    if (qs('#signupPasswordConfirm')) qs('#signupPasswordConfirm').value = pending.passwordConfirm || pending.password || '';
  }

  loginLink?.addEventListener('click', (e) => {
    e.preventDefault();
    go(ROUTES.auth.login);
  });

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();

    const payload = {
      fullName: qs('#signupFullName')?.value.trim(),
      email: qs('#signupEmail')?.value.trim(),
      password: qs('#signupPassword')?.value,
      passwordConfirm: qs('#signupPasswordConfirm')?.value,
    };

    const errorBox = qs('#signupError');
    hideBox(errorBox);

    if (!payload.fullName || !payload.email || !payload.password || !payload.passwordConfirm) {
      showError(errorBox, 'Tous les champs sont obligatoires.');
      return;
    }

    if (payload.password.length < 8) {
      showError(errorBox, 'Le mot de passe doit contenir au moins 8 caractères.');
      return;
    }

    if (payload.password !== payload.passwordConfirm) {
      showError(errorBox, 'Les mots de passe ne correspondent pas.');
      return;
    }

    setLoading(submit, true, 'Préparation...');
    setPendingSignup(payload);
    go(ROUTES.auth.chooseRole);
  });
}

function initChooseRolePage() {
  const cards = qsa('[data-role-card]');
  const form = qs('#chooseRoleForm');
  const submit = qs('#chooseRoleSubmit');
  const summary = qs('#signupSummary');
  const back = qs('[data-link="back-signup"]');
  const errorBox = qs('#chooseRoleError');
  const pending = getPendingSignup();

  if (!pending) {
    go(ROUTES.auth.signup);
    return;
  }

  cards.forEach((card) => {
    const role = card.dataset.roleCard;
    if (!PUBLIC_SIGNUP_ROLES.includes(role)) {
      card.remove();
    }
  });

  if (summary) {
    summary.innerHTML = `
      <span class="material-symbols-outlined">person</span>
      <span><strong>${pending.fullName}</strong> · ${pending.email}</span>
    `;
  }

  let selectedRole = null;

  cards.forEach((card) => {
    card.addEventListener('click', () => {
      cards.forEach((node) => node.classList.remove('selected'));
      card.classList.add('selected');
      selectedRole = card.dataset.roleCard;
      submit?.removeAttribute('disabled');
      hideBox(errorBox);
    });
  });

  back?.addEventListener('click', (e) => {
    e.preventDefault();
    go(ROUTES.auth.signup);
  });

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!selectedRole || !PUBLIC_SIGNUP_ROLES.includes(selectedRole)) {
      showError(errorBox, 'Choisis un rôle public UNIBOX avant de continuer.');
      return;
    }

    try {
      setLoading(submit, true, 'Création...');
      await signUpUNIBOX({
        fullName: pending.fullName,
        email: pending.email,
        password: pending.password,
        role: selectedRole,
      });

      clearPendingSignup();
      setAppFlash({
        message: `Compte ${ROLE_LABELS[selectedRole]} créé. Connecte-toi pour terminer ton onboarding.`,
        type: 'success',
      });
      window.location.href = '/index-enhanced.html#signin';
    } catch (error) {
      showError(errorBox, error.message || 'Inscription impossible.');
    } finally {
      setLoading(submit, false);
    }
  });
}

function initForgotPasswordPage() {
  const form = qs('#forgotPasswordForm');
  const submit = qs('#forgotPasswordSubmit');
  const successBox = qs('#forgotPasswordSuccess');
  const errorBox = qs('#forgotPasswordError');

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();

    hideBox(successBox);
    hideBox(errorBox);

    const email = qs('#forgotPasswordEmail')?.value.trim();

    try {
      setLoading(submit, true, 'Envoi...');
      await requestPasswordResetUNIBOX(email);
      if (successBox) {
        successBox.textContent = `Un lien de réinitialisation a été envoyé à ${email}.`;
        successBox.classList.remove('hidden');
      }
      appToast('Lien envoyé', 'success');
    } catch (error) {
      showError(errorBox, error.message || 'Impossible d’envoyer le lien.');
    } finally {
      setLoading(submit, false);
    }
  });
}

function initResetPasswordPage() {
  const form = qs('#resetPasswordForm');
  const submit = qs('#resetPasswordSubmit');
  const successBox = qs('#resetPasswordSuccess');
  const errorBox = qs('#resetPasswordError');

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();

    hideBox(successBox);
    hideBox(errorBox);

    const password = qs('#resetPasswordNew')?.value;
    const confirmPassword = qs('#resetPasswordConfirm')?.value;

    if (!password || password.length < 8) {
      showError(errorBox, 'Le mot de passe doit contenir au moins 8 caractères.');
      return;
    }

    if (password !== confirmPassword) {
      showError(errorBox, 'Les mots de passe ne correspondent pas.');
      return;
    }

    try {
      setLoading(submit, true, 'Mise à jour...');
      await updatePasswordUNIBOX(password);
      if (successBox) {
        successBox.textContent = 'Mot de passe mis à jour. Tu peux maintenant te connecter.';
        successBox.classList.remove('hidden');
      }
      setAppFlash({
        message: 'Mot de passe mis à jour. Connecte-toi à nouveau.',
        type: 'success',
      });
      setTimeout(() => go(ROUTES.auth.login), 900);
    } catch (error) {
      showError(errorBox, error.message || 'Impossible de mettre à jour le mot de passe.');
    } finally {
      setLoading(submit, false);
    }
  });
}

async function hydrateOnboardingForm(role) {
  const profile = await getCurrentProfile();
  if (!profile || profile.role !== role) {
    go(ROUTES.auth.login);
    return null;
  }

  const roleProfile = await getRoleProfile(role, profile.id).catch(() => null);

  if (qs('#onboardingFullName')) qs('#onboardingFullName').value = profile.full_name || '';
  if (qs('#onboardingPhone')) qs('#onboardingPhone').value = profile.phone || '';
  if (qs('#onboardingCity')) qs('#onboardingCity').value = profile.city || '';
  if (qs('#onboardingCountry')) qs('#onboardingCountry').value = profile.country || '';

  if (role === 'student') {
    if (qs('#onboardingSchoolName')) qs('#onboardingSchoolName').value = roleProfile?.school_name || '';
    if (qs('#onboardingStudyLevel')) qs('#onboardingStudyLevel').value = roleProfile?.study_level || '';
    if (qs('#onboardingHeadline')) qs('#onboardingHeadline').value = roleProfile?.headline || '';
    if (qs('#onboardingAvailability')) qs('#onboardingAvailability').value = roleProfile?.availability_text || '';
    if (qs('#onboardingBio')) qs('#onboardingBio').value = roleProfile?.bio || '';
  }

  if (role === 'recruiter') {
    if (qs('#onboardingJobTitle')) qs('#onboardingJobTitle').value = roleProfile?.job_title || '';
    if (qs('#onboardingBio')) qs('#onboardingBio').value = roleProfile?.bio || '';
  }

  if (role === 'particular') {
    if (qs('#onboardingBio')) qs('#onboardingBio').value = roleProfile?.bio || '';
  }

  const summary = qs('#onboardingSummary');
  if (summary) {
    summary.textContent = `${profile.full_name} · ${ROLE_LABELS[role]}`;
  }

  return profile;
}

function collectOnboardingPayload(role) {
  const basePayload = {
    fullName: qs('#onboardingFullName')?.value.trim(),
    phone: qs('#onboardingPhone')?.value.trim(),
    city: qs('#onboardingCity')?.value.trim(),
    country: qs('#onboardingCountry')?.value.trim(),
  };

  if (role === 'student') {
    return {
      ...basePayload,
      schoolName: qs('#onboardingSchoolName')?.value.trim(),
      studyLevel: qs('#onboardingStudyLevel')?.value.trim(),
      headline: qs('#onboardingHeadline')?.value.trim(),
      availabilityText: qs('#onboardingAvailability')?.value.trim(),
      bio: qs('#onboardingBio')?.value.trim(),
    };
  }

  if (role === 'recruiter') {
    return {
      ...basePayload,
      jobTitle: qs('#onboardingJobTitle')?.value.trim(),
      bio: qs('#onboardingBio')?.value.trim(),
    };
  }

  return {
    ...basePayload,
    bio: qs('#onboardingBio')?.value.trim(),
  };
}

function validateOnboardingPayload(role, payload) {
  if (!payload.fullName) return 'Le nom complet est obligatoire.';
  if (!payload.city) return 'La localisation principale est obligatoire.';

  if (role === 'student') {
    if (!payload.schoolName) return 'Le nom de ton établissement est obligatoire.';
    if (!payload.studyLevel) return 'Ton niveau d’étude est obligatoire.';
    if (!payload.headline) return 'Ajoute un titre rapide pour ton profil étudiant.';
  }

  if (role === 'recruiter') {
    if (!payload.jobTitle) return 'Le poste occupé est obligatoire.';
  }

  return null;
}

function initOnboardingPage(role) {
  const form = qs('#onboardingForm');
  const submit = qs('#onboardingSubmit');
  const errorBox = qs('#onboardingError');
  const logout = qs('[data-action="logout"]');

  logout?.addEventListener('click', async () => {
    await signOutUNIBOX().catch(() => null);
    setAppFlash({ message: 'Déconnexion effectuée.', type: 'info' });
    go(ROUTES.auth.login);
  });

  hydrateOnboardingForm(role).catch((error) => {
    showError(errorBox, error.message || 'Impossible de charger ton onboarding.');
  });

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideBox(errorBox);

    const payload = collectOnboardingPayload(role);
    const validationError = validateOnboardingPayload(role, payload);

    if (validationError) {
      showError(errorBox, validationError);
      return;
    }

    try {
      setLoading(submit, true, 'Activation...');
      await completeOnboardingForCurrentUser(payload);
      setAppFlash({
        message: 'Onboarding terminé. Ton espace UNIBOX est prêt.',
        type: 'success',
      });
      await redirectAfterLogin();
    } catch (error) {
      showError(errorBox, error.message || 'Impossible de finaliser ton onboarding.');
    } finally {
      setLoading(submit, false);
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const page = document.body.dataset.page;

  if (page === 'login') initLoginPage();
  if (page === 'signup') initSignupPage();
  if (page === 'choose-role') initChooseRolePage();
  if (page === 'forgot-password') initForgotPasswordPage();
  if (page === 'reset-password') initResetPasswordPage();
  if (page === 'onboarding-student') initOnboardingPage('student');
  if (page === 'onboarding-recruiter') initOnboardingPage('recruiter');
  if (page === 'onboarding-particular') initOnboardingPage('particular');
});
