import { qs, qsa, appToast, setLoading } from '/assets/js/unibox-core.js';
import { mountRecruiterShell } from '/assets/js/unibox-recruiter-shell.js';
import {
  listRecruiterOffers,
  createRecruiterOffer,
  updateRecruiterOffer,
  getRecruiterOffer,
  publishRecruiterOffer,
  pauseRecruiterOffer,
  closeRecruiterOffer,
  duplicateRecruiterOffer,
  listRecruiterApplications,
  getRecruiterCandidateDetail,
  updateRecruiterApplicationStatus,
  acceptRecruiterApplication,
  scheduleRecruiterInterview,
  listRecruiterNotifications,
  markRecruiterNotificationRead,
  markAllRecruiterNotificationsRead,
  listRecruiterConversations,
  listRecruiterMessages,
  sendRecruiterMessage,
  getOrCreateRecruiterApplicationConversation,
  listRecruiterConversationParticipants,
  markRecruiterConversationRead,
  updateRecruiterProfile,
  getCurrentRecruiterCompany,
  upsertCurrentRecruiterCompany,
} from '/assets/supabase/unibox-recruiter.js';
import { getCurrentProfile, getRoleProfile } from '/assets/supabase/unibox-profile.js';
import { uploadCompanyLogo, getSafeAssetUrl } from '/assets/supabase/unibox-storage.js';
import { STORAGE_BUCKETS } from '/assets/config/app.config.js';
import { createReport, listMyReports, getReportTargetDisplay } from '/assets/supabase/unibox-reports.js';
import { supabase } from '/assets/supabase/supabase-client.js';

const EMPLOYMENT_LABELS = {
  'stage': 'Stage',
  'part-time': 'Part-time',
  'full-time': 'Full-time',
};

const OFFER_STATUS_LABELS = {
  draft: 'Brouillon',
  published: 'Publiée',
  paused: 'En pause',
  closed: 'Fermée',
  archived: 'Archivée',
};

const COMPANY_STATUS_LABELS = {
  pending_review: 'En revue',
  active: 'Active',
  suspended: 'Suspendue',
  rejected: 'Refusée',
};

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function formatEmploymentType(value) {
  return EMPLOYMENT_LABELS[value] || value || 'Type non défini';
}

function formatOfferStatus(value) {
  return OFFER_STATUS_LABELS[value] || value || 'Inconnu';
}

function formatCompanyStatus(value) {
  return COMPANY_STATUS_LABELS[value] || value || 'À compléter';
}

function formatLocation(item) {
  return [item?.address_text, item?.city, item?.country].filter(Boolean).join(' · ');
}

function formatDate(value) {
  if (!value) return '—';
  return new Date(value).toLocaleDateString('fr-FR');
}

function formatDateTime(value) {
  if (!value) return '—';
  return new Date(value).toLocaleString('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatApplicationStatus(value) {
  switch (value) {
    case 'accepted': return 'Accepté';
    case 'rejected': return 'Refusé';
    case 'withdrawn': return 'Retirée';
    case 'cancelled': return 'Annulée';
    default: return 'En examination';
  }
}

function getDocumentIcon(mimeType) {
  if (!mimeType) return 'description';
  if (mimeType.includes('pdf')) return 'picture_as_pdf';
  if (mimeType.includes('image')) return 'image';
  if (mimeType.includes('word') || mimeType.includes('document')) return 'article';
  if (mimeType.includes('sheet') || mimeType.includes('excel')) return 'table';
  return 'description';
}

function renderCandidateDocuments(documents = []) {
  if (!documents.length) {
    return `<div style="text-align: center; padding: 32px; color: #a09ab8;">
      <span class="material-symbols-outlined" style="font-size: 48px; margin-bottom: 12px; display: block;">folder_off</span>
      <p style="margin: 0; font-size: 14px;">Aucun document n'a encore été soumis.</p>
    </div>`;
  }

  return `<div style="display: grid; gap: 10px;">${documents.map((document) => {
    const icon = getDocumentIcon(document.mime_type);
    const fileName = document.file_name || 'Document';
    const ext = fileName.split('.').pop()?.toUpperCase() || '';
    return `
    <a href="${escapeHtml(document.signed_url || '#')}" ${document.signed_url ? 'target="_blank" rel="noopener"' : ''}
       style="display: flex; align-items: center; gap: 14px; padding: 14px 16px; background: #f8f6ff; border-radius: 10px; border: 1px solid #ede9f8; text-decoration: none; transition: all 0.2s ease;"
       onmouseover="this.style.borderColor='rgba(107,56,212,0.3)';this.style.transform='translateY(-1px)';this.style.boxShadow='0 4px 12px rgba(107,56,212,0.08)';"
       onmouseout="this.style.borderColor='#ede9f8';this.style.transform='';this.style.boxShadow='';">
      <span style="width: 40px; height: 40px; border-radius: 10px; background: linear-gradient(135deg, #6b38d4, #8a5ff1); display: grid; place-items: center; flex-shrink: 0;">
        <span class="material-symbols-outlined" style="font-size: 20px; color: #fff;">${icon}</span>
      </span>
      <div style="flex: 1; min-width: 0;">
        <span style="display: block; font-size: 14px; font-weight: 600; color: #1b1b25; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${escapeHtml(fileName)}</span>
        <span style="display: block; font-size: 12px; color: #a09ab8; margin-top: 2px;">${escapeHtml(document.mime_type || 'Document')} ${ext ? '· ' + ext : ''}</span>
      </div>
      <span class="material-symbols-outlined" style="font-size: 20px; color: #6b38d4; flex-shrink: 0;">open_in_new</span>
    </a>
  `}).join('')}</div>`;
}

function renderCandidateTimeline(events = []) {
  if (!events.length) {
    return `<div style="text-align: center; padding: 32px; color: #a09ab8;">
      <span class="material-symbols-outlined" style="font-size: 48px; margin-bottom: 12px; display: block;">history_toggle_off</span>
      <p style="margin: 0; font-size: 14px;">Aucune étape enregistrée pour le moment.</p>
    </div>`;
  }

  const statusColors = {
    submitted: '#6b38d4',
    under_review: '#0ea5e9',
    shortlisted: '#8b5cf6',
    interview_requested: '#f59e0b',
    accepted: '#10b981',
    rejected: '#dc2626',
    withdrawn: '#6b7280'
  };

  const statusIcons = {
    submitted: 'send',
    under_review: 'visibility',
    shortlisted: 'star',
    interview_requested: 'event',
    accepted: 'check_circle',
    rejected: 'cancel',
    withdrawn: 'logout'
  };

  return `<div style="position: relative; padding-left: 24px;">
    <div style="position: absolute; left: 11px; top: 8px; bottom: 8px; width: 2px; background: linear-gradient(to bottom, #ddd6ea, #ede9f8); border-radius: 1px;"></div>
    ${events.map((event) => {
    const status = event.to_status || event.status || 'submitted';
    const color = statusColors[status] || '#6b38d4';
    const icon = statusIcons[status] || 'circle';
    const date = new Date(event.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
    const time = new Date(event.created_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    return `
      <div style="position: relative; margin-bottom: 20px;">
        <div style="position: absolute; left: -19px; top: 2px; width: 16px; height: 16px; border-radius: 50%; background: ${color}; border: 3px solid #fff; box-shadow: 0 0 0 2px ${color}33; z-index: 1;"></div>
        <div style="background: #f8f6ff; border-radius: 10px; padding: 14px 16px; border: 1px solid #ede9f8;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 6px;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span class="material-symbols-outlined" style="font-size: 18px; color: ${color};">${icon}</span>
              <strong style="font-size: 14px; color: #1b1b25;">${escapeHtml(formatApplicationStatus(status))}</strong>
            </div>
            <span style="font-size: 11px; color: #a09ab8; white-space: nowrap;">${escapeHtml(date)} · ${escapeHtml(time)}</span>
          </div>
          ${event.note ? `<p style="margin: 4px 0 0; color: #5d576c; font-size: 13px; line-height: 1.5; padding-left: 26px;">${escapeHtml(event.note)}</p>` : ''}
        </div>
      </div>
    `}).join('')}
  </div>`;
}

function openModal(id) {
  qs(`#${id}`)?.classList.add('is-open');
}

function closeModal(modal) {
  modal?.classList.remove('is-open');
}

function initModals() {
  qsa('[data-open-modal]').forEach((button) => {
    button.addEventListener('click', () => openModal(button.dataset.openModal));
  });

  qsa('[data-modal]').forEach((modal) => {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeModal(modal);
    });
  });

  qsa('[data-close-modal]').forEach((button) => {
    button.addEventListener('click', () => {
      const modal = button.closest('[data-modal]');
      if (modal) closeModal(modal);
    });
  });
}


function renderEmptyState(target, title, body) {
  if (!target) return;
  target.innerHTML = `
    <div class="empty-state small">
      <strong>${escapeHtml(title)}</strong>
      <span>${escapeHtml(body)}</span>
    </div>
  `;
}

function renderNoCompanyState(target, options = {}) {
  if (!target) return;
  const title = options.title || 'Entreprise à compléter';
  const text = options.text || 'Avant de publier une offre, crée ton entreprise UNIBOX avec une adresse complète et une localisation claire.';
  target.innerHTML = `
    <section class="recruiter-section empty-state recruiter-empty-state">
      <h3>${escapeHtml(title)}</h3>
      <p>${escapeHtml(text)}</p>
      <div class="card-actions" style="justify-content:center;">
        <a class="btn btn-primary" href="/recruiter/rec-company.html">Configurer mon entreprise</a>
      </div>
    </section>
  `;
}

function renderOfferCards(target, items) {
  if (!target) return;

  if (!items.length) {
    target.innerHTML = `
      <article class="empty-state recruiter-empty-state">
        <h3>Aucune offre pour le moment</h3>
        <p>Crée une offre UNIBOX claire avec un type obligatoire et une localisation complète.</p>
        <div class="card-actions" style="justify-content:center;">
          <a class="btn btn-primary" href="/recruiter/rec-offre-create.html">Créer une offre</a>
        </div>
      </article>
    `;
    return;
  }

  target.innerHTML = items.map((item) => {
    const location = formatLocation(item) || 'Localisation à compléter';
    const companyName = item.companies?.name || 'Entreprise UNIBOX';
    const statusClass = `status-${item.status || 'draft'}`;
    const statusLabel = formatOfferStatus(item.status);

    return `
      <article class="offer-card">
        <div class="offer-card-body">
          <div class="offer-card-header">
            <div class="offer-card-title-area">
              <h3 class="offer-card-title">${escapeHtml(item.title)}</h3>
              <p class="offer-card-company">${escapeHtml(companyName)}</p>
            </div>
            <span class="offer-card-status ${statusClass}">${escapeHtml(statusLabel)}</span>
          </div>
          <p class="offer-card-summary">${escapeHtml(item.summary || 'Offre UNIBOX prête à être pilotée côté recruteur.')}</p>
          <div class="offer-card-meta">
            <span class="pill soft">
              <span class="material-symbols-outlined">work</span>
              ${escapeHtml(formatEmploymentType(item.contract_type))}
            </span>
            <span class="pill soft">
              <span class="material-symbols-outlined">location_on</span>
              ${escapeHtml(location)}
            </span>
            <span class="pill soft">
              <span class="material-symbols-outlined">schedule</span>
              ${escapeHtml(item.work_mode || 'À définir')}
            </span>
          </div>
        </div>
        <div class="offer-card-footer">
          <div class="offer-card-stats">
            <span class="offer-card-stat">
              <span class="material-symbols-outlined">event</span>
              <strong>${escapeHtml(formatDate(item.published_at))}</strong>
            </span>
            <span class="offer-card-stat">
              <span class="material-symbols-outlined">group</span>
              <strong>${escapeHtml(item.spots_count || 1)}</strong> spot${(item.spots_count || 1) > 1 ? 's' : ''}
            </span>
          </div>
          <div class="offer-card-actions">
            <a class="btn btn-secondary" href="/recruiter/rec-offre-edit.html?offer=${encodeURIComponent(item.id)}" title="Modifier">
              <span class="material-symbols-outlined" style="font-size:16px;">edit</span>
            </a>
            ${item.status === 'draft' ? `<button type="button" class="btn btn-secondary" data-offer-publish="${escapeHtml(item.id)}" title="Publier"><span class="material-symbols-outlined" style="font-size:16px;">publish</span></button>` : ''}
            ${item.status === 'published' ? `<button type="button" class="btn btn-secondary" data-offer-pause="${escapeHtml(item.id)}" title="Mettre en pause"><span class="material-symbols-outlined" style="font-size:16px;">pause</span></button>` : ''}
            <a class="btn btn-primary" href="/recruiter/rec-offre-detail.html?offer=${encodeURIComponent(item.id)}">
              <span class="material-symbols-outlined" style="font-size:16px;">visibility</span>
              Voir
            </a>
          </div>
        </div>
      </article>
    `;
  }).join('');
}


function renderApplications(target, items) {
  if (!items.length) {
    target.innerHTML = `
      <div class="empty-state">
        <strong>Aucune candidature reçue</strong>
        <span>Les dossiers des candidats apparaîtront ici dès qu'un étudiant postulera à l'une de tes offres publiées.</span>
      </div>
    `;
    return;
  }

  target.innerHTML = items.map((item) => {
    const candidateName = item.profiles?.full_name || 'Candidat UNIBOX';
    const initials = candidateName.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
    const offerTitle = item.offers?.title || item.minute_jobs?.title || 'Annonce supprimée';
    const docsCount = (item.application_documents || []).length;
    const listingType = item.listing_type === 'minute_job' ? 'Job minute' : 'Offre entreprise';
    const candidateCity = item.profiles?.city || '';
    const avatarPath = item.profiles?.avatar_path;
    const statusLabel = formatApplicationStatus(item.status);

    const avatarHtml = avatarPath
      ? `<div class="app-candidate-avatar" data-avatar-path="${escapeHtml(avatarPath)}">${escapeHtml(initials)}</div>`
      : `<div class="app-candidate-avatar">${escapeHtml(initials)}</div>`;

    return `
      <article class="app-card" data-app-status="${escapeHtml(item.status || '')}">
        <div class="app-card-inner">
          <div class="app-card-avatar-col">
            ${avatarHtml}
          </div>
          <div class="app-card-body">
            <div class="app-card-top">
              <div>
                <h3 class="app-card-name">${escapeHtml(candidateName)}</h3>
                <p class="app-card-job">${escapeHtml(offerTitle)}</p>
              </div>
            </div>
            <div class="app-card-meta">
              <span class="pill">${escapeHtml(statusLabel)}</span>
              <span class="pill soft">${escapeHtml(listingType)}</span>
              ${candidateCity ? `<span class="pill soft">${escapeHtml(candidateCity)}</span>` : ''}
              ${docsCount > 0 ? `<span class="pill soft">${docsCount} doc${docsCount > 1 ? 's' : ''}</span>` : ''}
            </div>
            <p class="app-card-date">Soumis le ${escapeHtml(new Date(item.submitted_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' }))}</p>
          </div>
          <div class="app-card-action-col">
            <a class="btn btn-primary" href="/recruiter/rec-candidat-detail.html?application=${encodeURIComponent(item.id)}">
              <span class="material-symbols-outlined" style="font-size:16px;">manage_search</span>
              Inspecter
            </a>
            ${item.status === 'accepted' || item.status === 'rejected' ? '' : `
            <button class="btn btn-secondary" type="button" data-shortlist-application="${escapeHtml(item.id)}">Présélectionner</button>
            `}
            ${item.profiles?.id ? `<a class="btn btn-secondary" style="color: #dc2626; border-color: #dc2626;" href="/recruiter/rec-signalement.html?targetType=profile&targetId=${encodeURIComponent(item.profiles.id)}">
              <span class="material-symbols-outlined" style="font-size:16px;">flag</span>
              Signaler
            </a>` : ''}
          </div>
        </div>
      </article>
    `;
  }).join('');

  // Hydratation asynchrone des avatars
  qsa('[data-avatar-path]', target).forEach(async (el) => {
    try {
      const url = await getSafeAssetUrl(STORAGE_BUCKETS.avatars, el.dataset.avatarPath);
      el.innerHTML = `<img src="${url}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    } catch (_) { }
  });
}

function getNotificationIcon(title = '', body = '') {
  const text = (title + ' ' + body).toLowerCase();
  if (text.includes('candidat') || text.includes('candidature') || text.includes('application')) return 'person_add';
  if (text.includes('message') || text.includes('messag')) return 'chat';
  if (text.includes('offre') || text.includes('job') || text.includes('poste')) return 'work';
  if (text.includes('entretien') || text.includes('interview')) return 'event';
  if (text.includes('accept') || text.includes('approv')) return 'check_circle';
  if (text.includes('refus') || text.includes('reject')) return 'cancel';
  if (text.includes('shortlist')) return 'star';
  return 'notifications';
}

function getNotificationColor(title = '', body = '') {
  const text = (title + ' ' + body).toLowerCase();
  if (text.includes('candidat') || text.includes('candidature')) return '#6b38d4';
  if (text.includes('message')) return '#0ea5e9';
  if (text.includes('entretien') || text.includes('interview')) return '#f59e0b';
  if (text.includes('accept') || text.includes('approv')) return '#10b981';
  if (text.includes('refus') || text.includes('reject')) return '#dc2626';
  if (text.includes('shortlist')) return '#8b5cf6';
  return '#6b7280';
}

function renderNotifications(target, items) {
  if (!target) return;
  target.innerHTML = items.map((item) => {
    const icon = getNotificationIcon(item.title, item.body);
    const color = getNotificationColor(item.title, item.body);
    const isNew = !item.is_read;
    const timeAgo = formatDateTime(item.created_at);

    return `
    <article class="notification-card" style="${isNew ? 'border-left: 3px solid ' + color + '; background: linear-gradient(135deg, #f8f6ff 0%, #ffffff 100%);' : ''} padding: 0; overflow: hidden;">
      <div style="display: flex; align-items: flex-start; gap: 16px; padding: 18px 20px;">
        <!-- Icon -->
        <div style="flex-shrink: 0; width: 44px; height: 44px; border-radius: 12px; background: ${isNew ? color + '15' : '#f5f2ff'}; display: grid; place-items: center;">
          <span class="material-symbols-outlined" style="font-size: 22px; color: ${color};">${icon}</span>
        </div>

        <!-- Content -->
        <div style="flex: 1; min-width: 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 4px;">
            <h3 style="margin: 0; font-size: 15px; font-weight: 600; color: #1b1b25; line-height: 1.4;">${escapeHtml(item.title)}</h3>
            ${isNew ? `<span style="flex-shrink: 0; width: 8px; height: 8px; border-radius: 50%; background: ${color}; margin-top: 6px;"></span>` : ''}
          </div>
          <p style="margin: 0 0 8px; color: #5d576c; font-size: 14px; line-height: 1.5;">${escapeHtml(item.body)}</p>
          <span style="font-size: 12px; color: #a09ab8; display: flex; align-items: center; gap: 4px;">
            <span class="material-symbols-outlined" style="font-size: 14px;">schedule</span>
            ${escapeHtml(timeAgo)}
          </span>
        </div>
      </div>

      <!-- Actions -->
      <div style="display: flex; gap: 8px; padding: 0 20px 14px 80px;">
        ${item.action_url ? `<a class="btn btn-primary" href="${escapeHtml(item.action_url)}" style="padding: 6px 14px; font-size: 13px;">Ouvrir</a>` : ''}
        ${isNew ? `<button class="btn btn-secondary" type="button" data-recruiter-read-notification="${escapeHtml(item.id)}" style="padding: 6px 14px; font-size: 13px;">Marquer comme lu</button>` : ''}
      </div>
    </article>
  `}).join('');
}

function fillOfferForm(data = {}) {
  if (qs('#offerTitle')) qs('#offerTitle').value = data.title || '';
  if (qs('#offerSummary')) qs('#offerSummary').value = data.summary || '';
  if (qs('#offerDescription')) qs('#offerDescription').value = data.description || '';
  if (qs('#offerRequirements')) qs('#offerRequirements').value = data.requirements || '';
  if (qs('#offerResponsibilities')) qs('#offerResponsibilities').value = data.responsibilities || '';
  if (qs('#offerEmploymentType')) qs('#offerEmploymentType').value = data.contract_type || data.employment_type || '';
  if (qs('#offerWorkMode')) qs('#offerWorkMode').value = data.work_mode || 'on-site';
  if (qs('#offerAddress')) qs('#offerAddress').value = data.address_text || '';
  if (qs('#offerCity')) qs('#offerCity').value = data.city || '';
  if (qs('#offerCountry')) qs('#offerCountry').value = data.country || 'France';
  if (qs('#offerSalary')) qs('#offerSalary').value = data.salary_label || '';
  if (qs('#offerHours')) qs('#offerHours').value = data.hours_per_week || '';
  if (qs('#offerSpots')) qs('#offerSpots').value = data.spots_count || 1;
  if (qs('#offerStartDate')) qs('#offerStartDate').value = data.start_date || '';
  if (qs('#offerDeadline')) qs('#offerDeadline').value = data.application_deadline || '';
  if (qs('#offerSkills')) qs('#offerSkills').value = (data.skills || []).join(', ');
  if (qs('#offerBenefits')) qs('#offerBenefits').value = (data.benefits || []).join(', ');
}

function collectOfferFormData() {
  return {
    title: qs('#offerTitle')?.value.trim(),
    summary: qs('#offerSummary')?.value.trim(),
    description: qs('#offerDescription')?.value.trim(),
    requirements: qs('#offerRequirements')?.value.trim(),
    responsibilities: qs('#offerResponsibilities')?.value.trim(),
    employmentType: qs('#offerEmploymentType')?.value,
    work_mode: qs('#offerWorkMode')?.value,
    address_text: qs('#offerAddress')?.value.trim(),
    city: qs('#offerCity')?.value.trim(),
    country: qs('#offerCountry')?.value.trim(),
    salary_label: qs('#offerSalary')?.value.trim(),
    hours_per_week: qs('#offerHours')?.value ? Number(qs('#offerHours').value) : null,
    spots_count: qs('#offerSpots')?.value ? Number(qs('#offerSpots').value) : 1,
    start_date: qs('#offerStartDate')?.value || null,
    application_deadline: qs('#offerDeadline')?.value || null,
    skills: (qs('#offerSkills')?.value || '').split(',').map((value) => value.trim()).filter(Boolean),
    benefits: (qs('#offerBenefits')?.value || '').split(',').map((value) => value.trim()).filter(Boolean),
  };
}

function fillCompanyForm(company = {}) {
  if (qs('#companyName')) qs('#companyName').value = company.name || '';
  if (qs('#companyLegalName')) qs('#companyLegalName').value = company.legal_name || '';
  if (qs('#companyEmail')) qs('#companyEmail').value = company.email || '';
  if (qs('#companyPhone')) qs('#companyPhone').value = company.phone || '';
  if (qs('#companyWebsite')) qs('#companyWebsite').value = company.website_url || '';
  if (qs('#companyIndustry')) qs('#companyIndustry').value = company.industry || '';
  if (qs('#companySize')) qs('#companySize').value = company.company_size || '';
  if (qs('#companyDescription')) qs('#companyDescription').value = company.description || '';
  if (qs('#companyAddress1')) qs('#companyAddress1').value = company.address_line1 || '';
  if (qs('#companyAddress2')) qs('#companyAddress2').value = company.address_line2 || '';
  if (qs('#companyPostalCode')) qs('#companyPostalCode').value = company.postal_code || '';
  if (qs('#companyCity')) qs('#companyCity').value = company.city || '';
  if (qs('#companyCountry')) qs('#companyCountry').value = company.country || 'France';
}

function collectCompanyFormData(logoPath = undefined) {
  return {
    name: qs('#companyName')?.value.trim(),
    legalName: qs('#companyLegalName')?.value.trim(),
    email: qs('#companyEmail')?.value.trim(),
    phone: qs('#companyPhone')?.value.trim(),
    websiteUrl: qs('#companyWebsite')?.value.trim(),
    industry: qs('#companyIndustry')?.value.trim(),
    companySize: qs('#companySize')?.value,
    description: qs('#companyDescription')?.value.trim(),
    addressLine1: qs('#companyAddress1')?.value.trim(),
    addressLine2: qs('#companyAddress2')?.value.trim(),
    postalCode: qs('#companyPostalCode')?.value.trim(),
    city: qs('#companyCity')?.value.trim(),
    country: qs('#companyCountry')?.value.trim(),
    ...(logoPath ? { logoPath } : {}),
  };
}

async function refreshCompanyPreview(company) {
  const logoMount = qs('#companyLogoPreview');
  const headerName = qs('#companyHeaderName');
  const headerMeta = qs('#companyHeaderMeta');
  const statusNode = qs('#companyStatusBadge');

  // New premium preview fields
  const pcpName = qs('#previewCompanyName');
  const pcpIndustry = qs('#previewCompanyIndustry');
  const pcpLocation = qs('#previewCompanyLocation');
  const pcpSize = qs('#previewCompanySize');
  const pcpDesc = qs('#previewCompanyDesc');

  if (headerName) headerName.textContent = company?.name || 'Ton entreprise UNIBOX';
  if (headerMeta) headerMeta.textContent = formatLocation({
    address_text: company?.address_line1,
    city: company?.city,
    country: company?.country,
  }) || 'Ajoute l’adresse, la ville et le pays pour rendre tes offres crédibles.';
  if (statusNode) statusNode.textContent = formatCompanyStatus(company?.status);

  if (pcpName) pcpName.textContent = company?.name || 'Mon Entreprise';
  if (pcpIndustry) pcpIndustry.textContent = company?.industry || 'Secteur à définir';
  if (pcpLocation) pcpLocation.textContent = company?.city || 'Localisation';
  if (pcpSize) pcpSize.textContent = company?.company_size || 'Taille';
  if (pcpDesc) pcpDesc.textContent = company?.description || "La description détaillée de ton entreprise apparaîtra ici. Une bonne présentation augmente considérablement l'intérêt des candidats pour tes offres UNIBOX.";

  if (!logoMount) return;
  if (company?.logo_path) {
    try {
      const url = await getSafeAssetUrl(STORAGE_BUCKETS.companyLogos, company.logo_path);
      if (url) {
        logoMount.innerHTML = `<img src="${escapeHtml(url)}" alt="Logo entreprise UNIBOX" style="width:100%; height:100%; object-fit:cover;" />`;
        return;
      }
    } catch (_error) {
    }
  }

  logoMount.innerHTML = `<img src="/assets/img/cevital-logo.png" alt="Cevital" style="width:100%; height:100%; object-fit:cover; background:#fff; padding:4px;" />`;
}

async function initDashboard() {
  const offersMount = qs('#recruiterDashboardOffers');
  const company = await getCurrentRecruiterCompany().catch(() => null);

  if (!company?.id) {
    renderNoCompanyState(offersMount, {
      title: 'Commence par ton entreprise',
      text: 'UNIBOX rattache chaque offre recruteur à une entreprise réelle. Configure-la avant de créer ta première offre.',
    });
    Object.entries({ offers: 0, published: 0, applications: 0, interviews: 0 }).forEach(([key, value]) => {
      const node = qs(`[data-kpi="${key}"]`);
      if (node) node.textContent = String(value);
    });
    return;
  }

  const items = await listRecruiterOffers().catch((error) => {
    appToast(error.message || 'Impossible de charger les offres.', 'error');
    return [];
  });
  renderOfferCards(offersMount, items.slice(0, 3));

  const applications = await listRecruiterApplications().catch(() => []);
  const metrics = {
    offers: items.length,
    published: items.filter((item) => item.status === 'published').length,
    applications: applications.length,
    interviews: applications.filter((item) => String(item.status || '').includes('interview')).length,
  };

  Object.entries(metrics).forEach(([key, value]) => {
    const node = qs(`[data-kpi="${key}"]`);
    if (node) node.textContent = String(value);
  });
}

async function bindOfferCardActions(root = document) {
  qsa('[data-offer-publish]', root).forEach((button) => {
    button.addEventListener('click', async () => {
      const original = button.innerHTML;
      try {
        setLoading(button, true, 'Publication...');
        await publishRecruiterOffer(button.dataset.offerPublish);
        appToast('Offre publiée', 'success');
        if (document.body.dataset.page === 'recruiter-offers') await initOffersList();
        if (document.body.dataset.page === 'recruiter-dashboard') await initDashboard();
      } catch (error) {
        appToast(error.message || 'Impossible de publier l’offre.', 'error');
      } finally {
        button.innerHTML = original;
        button.disabled = false;
      }
    });
  });

  qsa('[data-offer-pause]', root).forEach((button) => {
    button.addEventListener('click', async () => {
      const original = button.innerHTML;
      try {
        setLoading(button, true, 'Pause...');
        await pauseRecruiterOffer(button.dataset.offerPause);
        appToast('Offre mise en pause', 'success');
        if (document.body.dataset.page === 'recruiter-offers') await initOffersList();
        if (document.body.dataset.page === 'recruiter-dashboard') await initDashboard();
      } catch (error) {
        appToast(error.message || 'Impossible de mettre l’offre en pause.', 'error');
      } finally {
        button.innerHTML = original;
        button.disabled = false;
      }
    });
  });
}

async function initOffersList() {
  const mount = qs('#recruiterOffersList');
  const company = await getCurrentRecruiterCompany().catch(() => null);
  if (!company?.id) {
    renderNoCompanyState(mount, {
      title: 'Crée ton entreprise avant tes offres',
      text: 'Chaque offre recruteur UNIBOX doit être rattachée à une entreprise configurée avec sa localisation.',
    });
    return;
  }

  const activeChip = qs('[data-status-filter].is-active')?.dataset.statusFilter || '';
  const status = activeChip || null;
  const items = await listRecruiterOffers({ status }).catch((error) => {
    appToast(error.message || 'Impossible de charger les offres.', 'error');
    return [];
  });
  renderOfferCards(mount, items);
  await bindOfferCardActions(mount);
}

async function initOfferCreate() {
  const form = qs('#recruiterOfferCreateForm');
  const company = await getCurrentRecruiterCompany().catch(() => null);

  if (!company?.id) {
    appToast('Entreprise requise. Veuillez d\'abord créer votre entreprise.', 'error');
    form?.querySelectorAll('input, textarea, select, button').forEach((node) => node.disabled = true);
    return;
  }

  // --- Multi-step Logic ---
  let currentStep = 1;
  const totalSteps = 3;

  function showStep(stepIndex) {
    qsa('.wizard-step').forEach(el => {
      el.style.display = el.dataset.step == stepIndex ? 'block' : 'none';
    });

    qsa('.wizard-dot-container').forEach(el => {
      const dotIndex = parseInt(el.dataset.dot, 10);
      const dot = el.querySelector('.wizard-dot');
      const text = el.querySelector('span');

      if (dotIndex < stepIndex) {
        dot.style.background = '#6b38d4';
        dot.style.color = 'white';
        dot.innerHTML = '<span class="material-symbols-outlined" style="font-size: 16px;">check</span>';
        text.style.color = '#1b1b25';
      } else if (dotIndex === stepIndex) {
        dot.style.background = '#6b38d4';
        dot.style.color = 'white';
        dot.innerHTML = dotIndex;
        text.style.color = '#1b1b25';
      } else {
        dot.style.background = '#e1d6f5';
        dot.style.color = '#5d576c';
        dot.innerHTML = dotIndex;
        text.style.color = '#a09ab8';
      }
    });

    const progressPercent = ((stepIndex - 1) / (totalSteps - 1)) * 100;
    const progressBar = qs('#wizardProgressLine');
    if (progressBar) progressBar.style.width = `${progressPercent}%`;
  }

  function validateStep(stepIndex) {
    const stepEl = qs(`.wizard-step[data-step="${stepIndex}"]`);
    if (!stepEl) return true;
    const inputs = stepEl.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;
    inputs.forEach(input => {
      if (!input.checkValidity()) {
        input.reportValidity();
        isValid = false;
      }
    });
    return isValid;
  }

  qsa('.btn-next').forEach(btn => {
    btn.addEventListener('click', () => {
      if (validateStep(currentStep)) {
        currentStep++;
        showStep(currentStep);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  });

  qsa('.btn-prev').forEach(btn => {
    btn.addEventListener('click', () => {
      currentStep--;
      showStep(currentStep);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  });

  showStep(currentStep);
  // --- End Multi-step Logic ---

  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!validateStep(totalSteps)) return; // Validate last step just in case

    const buttonTop = qs('#offerCreateSubmitTop');
    const buttonBottom = qs('#offerCreateSubmitBottom');

    try {
      if (buttonTop) setLoading(buttonTop, true, 'Publication...');
      if (buttonBottom) setLoading(buttonBottom, true, 'Publication...');

      const created = await createRecruiterOffer({
        ...collectOfferFormData(),
        status: 'published',
      });
      appToast('Offre publiée', 'success');
      qs('#offerCreateSuccessLink')?.setAttribute('href', `/recruiter/rec-offre-detail.html?offer=${encodeURIComponent(created.id)}`);
      openModal('offerCreateSuccessModal');
      form.reset();
      currentStep = 1;
      showStep(currentStep);
    } catch (error) {
      appToast(error.message || 'Impossible de publier l’offre.', 'error');
    } finally {
      if (buttonTop) setLoading(buttonTop, false);
      if (buttonBottom) setLoading(buttonBottom, false);
    }
  });

  qs('#offerCreateDraft')?.addEventListener('click', async () => {
    const button = qs('#offerCreateDraft');
    try {
      setLoading(button, true, 'Brouillon...');
      await createRecruiterOffer({ ...collectOfferFormData(), status: 'draft' });
      appToast('Brouillon enregistré', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible d’enregistrer le brouillon.', 'error');
    } finally {
      setLoading(button, false, 'Brouillon...');
    }
  });
}

async function initOfferEdit() {
  const params = new URLSearchParams(window.location.search);
  const offerId = params.get('offer');
  if (!offerId) {
    appToast('Offre introuvable.', 'error');
    return;
  }

  let data = null;
  try {
    data = await getRecruiterOffer(offerId);
  } catch (error) {
    appToast(error.message || 'Impossible de charger l’offre.', 'error');
    return;
  }

  fillOfferForm(data);
  const companyInfo = qs('#offerEditCompanyBanner');
  if (companyInfo) {
    companyInfo.innerHTML = `
      <strong>${escapeHtml(data.companies?.name || 'Entreprise UNIBOX')}</strong>
      <p style="margin:8px 0 0;">${escapeHtml(formatEmploymentType(data.contract_type))} · ${escapeHtml(formatLocation(data))}</p>
    `;
  }

  qs('#recruiterOfferEditForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = qs('#offerEditSubmit');
    try {
      setLoading(button, true, 'Enregistrement...');
      await updateRecruiterOffer(offerId, collectOfferFormData());
      appToast('Offre mise à jour', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible de modifier l’offre.', 'error');
    } finally {
      setLoading(button, false);
    }
  });

  qs('#offerEditPublish')?.addEventListener('click', async () => {
    const button = qs('#offerEditPublish');
    try {
      setLoading(button, true, 'Publication...');
      await updateRecruiterOffer(offerId, {
        ...collectOfferFormData(),
        status: 'published',
      });
      appToast('Offre publiée', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible de publier l’offre.', 'error');
    } finally {
      setLoading(button, false);
    }
  });
}

async function initOfferDetail() {
  const params = new URLSearchParams(window.location.search);
  const offerId = params.get('offer');
  if (!offerId) {
    appToast('Offre introuvable.', 'error');
    return;
  }

  let data = null;
  try {
    data = await getRecruiterOffer(offerId);
  } catch (error) {
    appToast(error.message || 'Impossible de charger cette offre.', 'error');
    return;
  }

  const mount = qs('#recruiterOfferDetailMount');
  const statusClassHero = `status-${data.status || 'draft'}`;
  mount.innerHTML = `
    <section class="recruiter-section recruiter-offer-hero">
      <a class="offer-breadcrumb" href="/recruiter/rec-sdbar+offre.html">
        <span class="material-symbols-outlined">arrow_back</span> Mes offres
      </a>
      <div class="offer-meta-bar">
        <span class="pill">${escapeHtml(data.companies?.name || 'Entreprise')}</span>
        <span class="pill soft"><span class="material-symbols-outlined">work</span>${escapeHtml(formatEmploymentType(data.contract_type))}</span>
        <span class="pill soft"><span class="material-symbols-outlined">schedule</span>${escapeHtml(data.work_mode || 'À définir')}</span>
        <span class="offer-hero-status ${statusClassHero}">${escapeHtml(formatOfferStatus(data.status))}</span>
      </div>
      <h2 class="card-title">${escapeHtml(data.title)}</h2>
      <p class="card-subtitle">${escapeHtml(data.summary || data.description || 'Offre UNIBOX gérée depuis ton espace recruteur.')}</p>
      <div class="offer-insight-grid">
        <article class="insight-card insight-card-violet">
          <div class="insight-icon"><span class="material-symbols-outlined">location_on</span></div>
          <span class="insight-card-label">Localisation</span>
          <span class="insight-card-value">${escapeHtml(formatLocation(data) || 'À compléter')}</span>
        </article>
        <article class="insight-card insight-card-blue">
          <div class="insight-icon"><span class="material-symbols-outlined">home_work</span></div>
          <span class="insight-card-label">Mode</span>
          <span class="insight-card-value">${escapeHtml(data.work_mode || 'À définir')}</span>
        </article>
        <article class="insight-card insight-card-green">
          <div class="insight-icon"><span class="material-symbols-outlined">payments</span></div>
          <span class="insight-card-label">Rémunération</span>
          <span class="insight-card-value">${escapeHtml(data.salary_label || 'À définir')}</span>
        </article>
        <article class="insight-card insight-card-amber">
          <div class="insight-icon"><span class="material-symbols-outlined">event</span></div>
          <span class="insight-card-label">Date limite</span>
          <span class="insight-card-value">${escapeHtml(formatDate(data.application_deadline))}</span>
        </article>
      </div>
      <div class="offer-actions-bar">
        <a class="btn btn-secondary" href="/recruiter/rec-offre-edit.html?offer=${encodeURIComponent(data.id)}">
          <span class="material-symbols-outlined" style="font-size:18px;">edit</span> Modifier
        </a>
        ${data.status !== 'published' ? '<button class="btn btn-primary" type="button" data-open-modal="publishOfferModal"><span class="material-symbols-outlined" style="font-size:18px;">publish</span> Publier</button>' : '<button class="btn btn-secondary" type="button" data-open-modal="pauseOfferModal"><span class="material-symbols-outlined" style="font-size:18px;">pause</span> Mettre en pause</button>'}
        <button class="btn btn-secondary" type="button" data-open-modal="closeOfferModal"><span class="material-symbols-outlined" style="font-size:18px;">close</span> Clôturer</button>
        <button class="btn btn-secondary" type="button" data-open-modal="duplicateOfferModal"><span class="material-symbols-outlined" style="font-size:18px;">content_copy</span> Dupliquer</button>
      </div>
    </section>

    <section class="recruiter-section recruiter-detail-grid" style="margin-top:20px;">
      <div class="recruiter-grid two" style="gap:20px;">
        <div class="detail-section">
          <h3><span class="material-symbols-outlined">business_center</span> Détails métier</h3>
          <div class="detail-list">
            <div class="detail-row">
              <div class="detail-row-icon"><span class="material-symbols-outlined">place</span></div>
              <div class="detail-row-body"><span class="detail-row-label">Adresse</span><span class="detail-row-value">${escapeHtml(data.address_text || '—')}</span></div>
            </div>
            <div class="detail-row">
              <div class="detail-row-icon"><span class="material-symbols-outlined">map</span></div>
              <div class="detail-row-body"><span class="detail-row-label">Ville / pays</span><span class="detail-row-value">${escapeHtml([data.city, data.country].filter(Boolean).join(' · ') || '—')}</span></div>
            </div>
            <div class="detail-row">
              <div class="detail-row-icon"><span class="material-symbols-outlined">psychology</span></div>
              <div class="detail-row-body"><span class="detail-row-label">Compétences</span><span class="detail-row-value">${escapeHtml((data.skills || []).join(', ') || '—')}</span></div>
            </div>
            <div class="detail-row">
              <div class="detail-row-icon"><span class="material-symbols-outlined">redeem</span></div>
              <div class="detail-row-body"><span class="detail-row-label">Avantages</span><span class="detail-row-value">${escapeHtml((data.benefits || []).join(', ') || '—')}</span></div>
            </div>
          </div>
        </div>
        <div class="detail-section">
          <h3><span class="material-symbols-outlined">settings</span> Publication</h3>
          <div class="detail-list">
            <div class="detail-row">
              <div class="detail-row-icon"><span class="material-symbols-outlined">apartment</span></div>
              <div class="detail-row-body"><span class="detail-row-label">Entreprise</span><span class="detail-row-value">${escapeHtml(data.companies?.name || '—')}</span></div>
            </div>
            <div class="detail-row">
              <div class="detail-row-icon"><span class="material-symbols-outlined">verified</span></div>
              <div class="detail-row-body"><span class="detail-row-label">Statut société</span><span class="detail-row-value">${escapeHtml(formatCompanyStatus(data.companies?.status))}</span></div>
            </div>
            <div class="detail-row">
              <div class="detail-row-icon"><span class="material-symbols-outlined">calendar_month</span></div>
              <div class="detail-row-body"><span class="detail-row-label">Publiée le</span><span class="detail-row-value">${escapeHtml(formatDate(data.published_at))}</span></div>
            </div>
            <div class="detail-row">
              <div class="detail-row-icon"><span class="material-symbols-outlined">group</span></div>
              <div class="detail-row-body"><span class="detail-row-label">Postes ouverts</span><span class="detail-row-value">${escapeHtml(data.spots_count || 1)}</span></div>
            </div>
          </div>
        </div>
      </div>
    </section>

    ${data.description ? `
    <section class="content-block" style="margin-top:20px;">
      <h3><span class="material-symbols-outlined">description</span> Description</h3>
      <p>${escapeHtml(data.description)}</p>
    </section>
    ` : ''}
    ${data.requirements ? `
    <section class="content-block" style="margin-top:20px;">
      <h3><span class="material-symbols-outlined">checklist</span> Pré-requis</h3>
      <p>${escapeHtml(data.requirements)}</p>
    </section>
    ` : ''}
    ${data.responsibilities ? `
    <section class="content-block" style="margin-top:20px;">
      <h3><span class="material-symbols-outlined">task_alt</span> Missions</h3>
      <p>${escapeHtml(data.responsibilities)}</p>
    </section>
    ` : ''}
  `;

  qs('#pauseOfferConfirm')?.addEventListener('click', async () => {
    try {
      await pauseRecruiterOffer(data.id);
      appToast('Offre mise en pause', 'success');
      closeModal(qs('#pauseOfferModal'));
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible de mettre l’offre en pause.', 'error');
    }
  });

  qs('#publishOfferConfirm')?.addEventListener('click', async () => {
    try {
      await publishRecruiterOffer(data.id);
      appToast('Offre publiée', 'success');
      closeModal(qs('#publishOfferModal'));
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible de publier l’offre.', 'error');
    }
  });

  qs('#closeOfferConfirm')?.addEventListener('click', async () => {
    try {
      await closeRecruiterOffer(data.id);
      appToast('Offre clôturée', 'success');
      closeModal(qs('#closeOfferModal'));
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible de clôturer l’offre.', 'error');
    }
  });

  qs('#duplicateOfferConfirm')?.addEventListener('click', async () => {
    try {
      const duplicate = await duplicateRecruiterOffer(data.id, { status: 'draft' });
      appToast('Offre dupliquée', 'success');
      closeModal(qs('#duplicateOfferModal'));
      window.location.href = `/recruiter/rec-offre-edit.html?offer=${encodeURIComponent(duplicate.id)}`;
    } catch (error) {
      appToast(error.message || 'Impossible de dupliquer l’offre.', 'error');
    }
  });
}

async function initCompany() {
  let company = await getCurrentRecruiterCompany().catch(() => null);
  fillCompanyForm(company || {});
  await refreshCompanyPreview(company);

  const form = qs('#recruiterCompanyForm');
  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = qs('#companySave');
    try {
      setLoading(button, true, 'Enregistrement...');
      let logoPath;
      const logoFile = qs('#companyLogo')?.files?.[0];
      if (logoFile) {
        logoPath = await uploadCompanyLogo(logoFile);
      }
      company = await upsertCurrentRecruiterCompany(collectCompanyFormData(logoPath));
      fillCompanyForm(company);
      await refreshCompanyPreview(company);
      appToast('Entreprise enregistrée', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible d’enregistrer l’entreprise.', 'error');
    } finally {
      setLoading(button, false);
    }
  });
}


async function initApplications() {
  const mount = qs('#recruiterApplicationsList');
  const countDisplay = qs('#recruiterApplicationsCount');
  let allApplications = [];
  let currentFilter = 'all';

  async function loadData() {
    try {
      allApplications = await listRecruiterApplications();
    } catch (error) {
      appToast(error.message || 'Impossible de charger les candidatures.', 'error');
      allApplications = [];
    }
    applyFilterAndRender();
  }

  function applyFilterAndRender() {
    const filtered = currentFilter === 'all'
      ? allApplications
      : allApplications.filter((app) => app.status === currentFilter);

    if (countDisplay) {
      countDisplay.textContent = `${filtered.length} candidature${filtered.length > 1 ? 's' : ''}`;
    }

    renderApplications(mount, filtered);
    bindActions();
  }

  function bindActions() {
    qsa('[data-shortlist-application]').forEach((button) => {
      button.addEventListener('click', async () => {
        try {
          const appId = button.dataset.shortlistApplication;
          await updateRecruiterApplicationStatus(appId, 'shortlisted');
          allApplications = allApplications.map((item) => item.id === appId ? { ...item, status: 'shortlisted' } : item);
          applyFilterAndRender();
          appToast('Candidat shortlisté', 'success');
        } catch (error) {
          appToast(error.message || 'Impossible de mettre à jour la candidature.', 'error');
        }
      });
    });
  }

  // Bind filters
  qsa('[data-app-status-filter]').forEach((btn) => {
    btn.addEventListener('click', () => {
      qsa('[data-app-status-filter]').forEach((b) => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      currentFilter = btn.dataset.appStatusFilter;
      applyFilterAndRender();
    });
  });

  loadData();
}


async function initCandidateDetail() {
  const params = new URLSearchParams(window.location.search);
  const applicationId = params.get('application');
  const mount = qs('#recruiterCandidateDetailMount');
  const actions = qs('#recruiterCandidateActions');

  if (!applicationId) {
    mount.innerHTML = '<section class="recruiter-section"><p class="card-subtitle">Candidature introuvable.</p></section>';
    return;
  }

  let application;
  try {
    application = await getRecruiterCandidateDetail(applicationId);
  } catch (error) {
    mount.innerHTML = `<section class="recruiter-section"><p class="card-subtitle">${escapeHtml(error.message || 'Impossible de charger le dossier candidat.')}</p></section>`;
    return;
  }

  const studentProfile = application.student_profile || {};
  const studentBase = application.profiles || {};
  const listingTitle = application.offers?.title || application.minute_jobs?.title || 'Annonce UNIBOX';
  const statusLabel = formatApplicationStatus(application.status);

  const candidateName = studentBase.full_name || 'Candidat UNIBOX';
  const initials = candidateName.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  const avatarPath = studentBase.avatar_path;
  const avatarStyle = 'width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,#6b38d4,#8a5ff1);color:#fff;display:grid;place-items:center;font-size:28px;font-weight:700;flex-shrink:0;overflow:hidden;box-shadow:0 4px 14px rgba(0,0,0,0.15);';
  const avatarHtml = avatarPath
    ? `<div class="app-candidate-avatar" style="${avatarStyle}" data-avatar-path="${escapeHtml(avatarPath)}">${escapeHtml(initials)}</div>`
    : `<div class="app-candidate-avatar" style="${avatarStyle}">${escapeHtml(initials)}</div>`;

  const docs = application.application_documents || [];
  const hasDocs = docs.length > 0;

  mount.innerHTML = `
    <section class="dash-card" style="padding: 0; overflow: hidden; grid-column: 1 / -1;">
      <!-- Header Banner -->
      <div style="background: linear-gradient(135deg, #6b38d4 0%, #8a5ff1 100%); padding: 28px; position: relative; overflow: hidden;">
        <div style="position: absolute; top: -40px; right: -40px; width: 160px; height: 160px; border-radius: 50%; background: rgba(255,255,255,0.08); pointer-events: none;"></div>
        <div style="position: absolute; bottom: -20px; left: 20%; width: 100px; height: 100px; border-radius: 50%; background: rgba(255,255,255,0.05); pointer-events: none;"></div>
        
        <div style="display: flex; align-items: center; gap: 20px; position: relative; z-index: 1;">
          <div style="flex-shrink: 0; position: relative;">
            ${avatarHtml}
            <div style="position: absolute; bottom: -2px; right: -2px; width: 18px; height: 18px; background: #10b981; border-radius: 50%; border: 3px solid #fff;"></div>
          </div>
          <div style="flex: 1; min-width: 0;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 4px; flex-wrap: wrap;">
              <h2 style="margin: 0; font-size: 22px; font-weight: 700; color: #fff;">${escapeHtml(candidateName)}</h2>
              <span style="background: rgba(255,255,255,0.2); color: #fff; padding: 4px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; border: 1px solid rgba(255,255,255,0.3);">${escapeHtml(statusLabel)}</span>
            </div>
            <p style="margin: 0; color: rgba(255,255,255,0.85); font-size: 14px;">${escapeHtml(studentProfile.headline || 'Étudiant UNIBOX')}</p>
          </div>
        </div>
        
        <div style="display: flex; gap: 16px; margin-top: 16px; flex-wrap: wrap; position: relative; z-index: 1;">
          ${studentProfile.school_name ? `
          <div style="display: flex; align-items: center; gap: 6px; color: rgba(255,255,255,0.9); font-size: 13px;">
            <span class="material-symbols-outlined" style="font-size: 16px;">school</span>
            ${escapeHtml(studentProfile.school_name)}
          </div>` : ''}
          ${studentProfile.study_level ? `
          <div style="display: flex; align-items: center; gap: 6px; color: rgba(255,255,255,0.9); font-size: 13px;">
            <span class="material-symbols-outlined" style="font-size: 16px;">grade</span>
            ${escapeHtml(studentProfile.study_level)}
          </div>` : ''}
          ${studentBase.city ? `
          <div style="display: flex; align-items: center; gap: 6px; color: rgba(255,255,255,0.9); font-size: 13px;">
            <span class="material-symbols-outlined" style="font-size: 16px;">location_on</span>
            ${escapeHtml(studentBase.city)}
          </div>` : ''}
        </div>
      </div>
      
      <!-- Body -->
      <div style="padding: 28px;">
        <!-- Info Grid -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-bottom: 24px;">
          <div style="background: #f8f6ff; border-radius: 10px; padding: 14px; border: 1px solid #ede9f8;">
            <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; font-weight: 600;">Email</span>
            <span style="font-size: 13px; color: #1b1b25; font-weight: 500; word-break: break-all;">${escapeHtml(studentBase.email || 'Non disponible')}</span>
          </div>
          <div style="background: #f8f6ff; border-radius: 10px; padding: 14px; border: 1px solid #ede9f8;">
            <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; font-weight: 600;">Offre</span>
            <span style="font-size: 13px; color: #1b1b25; font-weight: 500;">${escapeHtml(listingTitle)}</span>
          </div>
          <div style="background: #f8f6ff; border-radius: 10px; padding: 14px; border: 1px solid #ede9f8;">
            <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; font-weight: 600;">Candidature</span>
            <span style="font-size: 13px; color: #1b1b25; font-weight: 500;">${escapeHtml(new Date(application.submitted_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' }))}</span>
          </div>
          <div style="background: #f8f6ff; border-radius: 10px; padding: 14px; border: 1px solid #ede9f8;">
            <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; font-weight: 600;">Documents</span>
            <span style="font-size: 13px; color: #1b1b25; font-weight: 500;">${hasDocs ? `${docs.length} document${docs.length > 1 ? 's' : ''}` : 'Aucun'}</span>
          </div>
        </div>

        ${application.message_body ? `
        <div style="background: #f0f9ff; border-radius: 10px; padding: 16px; border-left: 3px solid #0ea5e9; margin-bottom: 24px;">
          <span style="display: block; font-size: 11px; color: #0ea5e9; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 6px; font-weight: 600;">Message de l'étudiant</span>
          <p style="margin: 0; color: #334155; font-size: 14px; line-height: 1.6;">${escapeHtml(application.message_body)}</p>
        </div>
        ` : ''}

        ${studentProfile.bio ? `
        <div style="margin-bottom: 24px;">
          <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 6px; font-weight: 600;">À propos</span>
          <p style="margin: 0; color: #334155; font-size: 13px; line-height: 1.6;">${escapeHtml(studentProfile.bio)}</p>
        </div>
        ` : ''}

        ${hasDocs ? `
        <div style="margin-bottom: 24px;">
          <h3 style="font-size: 13px; font-weight: 700; color: #1b1b25; margin: 0 0 14px; display: flex; align-items: center; gap: 8px;">
            <span class="material-symbols-outlined" style="font-size: 18px; color: #6b38d4;">description</span>
            Documents joints
          </h3>
          ${renderCandidateDocuments(docs)}
        </div>
        ` : ''}

        ${(application.application_status_events || []).length > 0 ? `
        <div>
          <h3 style="font-size: 13px; font-weight: 700; color: #1b1b25; margin: 0 0 14px; display: flex; align-items: center; gap: 8px;">
            <span class="material-symbols-outlined" style="font-size: 18px; color: #6b38d4;">timeline</span>
            Historique de la candidature
          </h3>
          ${renderCandidateTimeline(application.application_status_events || [])}
        </div>
        ` : ''}

        <!-- Actions rapides -->
        <div style="margin-top: 28px; padding-top: 24px; border-top: 1px solid #f0edf7; display: flex; flex-wrap: wrap; gap: 10px;">
          ${application.status === 'accepted' ? '' : `<button type="button" class="btn btn-secondary" id="candidateShortlist">
            <span class="material-symbols-outlined" style="font-size:18px;">playlist_add</span>
            Shortlist
          </button>`}
          ${application.status === 'accepted' ? '' : `<button type="button" class="btn btn-primary" id="candidateAccept">
            <span class="material-symbols-outlined" style="font-size:18px;">check_circle</span>
            Accepter
          </button>`}
          <button type="button" class="btn btn-secondary" data-open-modal="candidateInterviewModal">
            <span class="material-symbols-outlined" style="font-size:18px;">event</span>
            Planifier entretien
          </button>
          <button type="button" class="btn btn-secondary" id="candidateMessage">
            <span class="material-symbols-outlined" style="font-size:18px;">chat</span>
            Message
          </button>
          ${application.status === 'rejected' ? '' : `<button type="button" class="btn btn-secondary" id="candidateReject" style="color: #dc2626; border-color: #dc2626;">
            <span class="material-symbols-outlined" style="font-size:18px;">cancel</span>
            Refuser
          </button>`}
        </div>
      </div>
    </section>
  `;

  // Hydrate avatar
  qsa('[data-avatar-path]', mount).forEach(async (el) => {
    try {
      const url = await getSafeAssetUrl(STORAGE_BUCKETS.avatars, el.dataset.avatarPath);
      el.innerHTML = `<img src="${url}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    } catch (_) { }
  });

  initModals();

  // Mise à jour du lien "Signaler" avec les params du profil candidat
  const reportBtn = qs('#recruiterReportCandidateBtn');
  if (reportBtn && studentBase.id) {
    reportBtn.href = `/recruiter/rec-signalement.html?targetType=profile&targetId=${encodeURIComponent(studentBase.id)}`;
  }

  qs('#candidateShortlist')?.addEventListener('click', async () => {
    try {
      await updateRecruiterApplicationStatus(applicationId, 'shortlisted');
      appToast('Candidat shortlisté', 'success');
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible de mettre à jour la candidature.', 'error');
    }
  });

  qs('#candidateAccept')?.addEventListener('click', async () => {
    try {
      await acceptRecruiterApplication(application);
      appToast('Candidature acceptée et offre clôturée pour les autres étudiants.', 'success');
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible daccepter la candidature.', 'error');
    }
  });

  qs('#candidateReject')?.addEventListener('click', async () => {
    try {
      await updateRecruiterApplicationStatus(applicationId, 'rejected', { rejected_at: new Date().toISOString() });
      appToast('Candidature refusée', 'success');
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible de refuser la candidature.', 'error');
    }
  });

  qs('#candidateMessage')?.addEventListener('click', async () => {
    try {
      const conversation = await getOrCreateRecruiterApplicationConversation(applicationId);
      window.location.href = `/recruiter/rec-message.html?application=${encodeURIComponent(applicationId)}&conversation=${encodeURIComponent(conversation.id)}`;
    } catch (error) {
      appToast(error.message || 'Impossible d’ouvrir la conversation.', 'error');
    }
  });

  qs('#candidateInterviewSend')?.addEventListener('click', async () => {
    const scheduledAt = qs('#candidateInterviewDate')?.value;
    const locationLabel = qs('#candidateInterviewLocation')?.value || null;
    if (!scheduledAt) {
      appToast('Choisis un créneau pour l’entretien.', 'error');
      return;
    }
    try {
      await scheduleRecruiterInterview(applicationId, {
        scheduled_at: new Date(scheduledAt).toISOString(),
        duration_minutes: 45,
        location_type: locationLabel && locationLabel.startsWith('http') ? 'meet' : 'other',
        meeting_url: locationLabel && locationLabel.startsWith('http') ? locationLabel : null,
        location_label: locationLabel,
        status: 'proposed',
      });
      appToast('Entretien planifié', 'success');
      closeModal(qs('#candidateInterviewModal'));
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible de planifier l’entretien.', 'error');
    }
  });
}

async function initMessages() {
  const list = qs('#recruiterConversationList');
  const thread = qs('#recruiterMessageThread');
  const form = qs('#recruiterMessageSendForm');
  const input = qs('#recruiterMessageInput');
  const params = new URLSearchParams(window.location.search);
  const applicationId = params.get('application');
  const requestedConversationId = params.get('conversation');
  const currentProfile = await getCurrentProfile().catch(() => null);
  let selectedConversationId = null;

  async function fetchInbox() {
    const data = await listRecruiterConversations().catch(() => []);
    if (!applicationId) return data;

    const ensured = await getOrCreateRecruiterApplicationConversation(applicationId);
    if (ensured?.id && !data.some((row) => row.conversation_id === ensured.id)) {
      return await listRecruiterConversations();
    }
    return data;
  }

  let conversations = [];
  try {
    conversations = await fetchInbox();
  } catch (error) {
    renderEmptyState(list, 'Messagerie indisponible', error.message || 'Impossible de charger les conversations.');
    renderEmptyState(thread, 'Aucun message', 'La conversation UNIBOX sera visible ici dès qu’elle sera disponible.');
    return;
  }

  if (!conversations.length) {
    renderEmptyState(list, 'Aucune conversation pour le moment', 'Les conversations liées aux candidatures apparaîtront ici.');
    renderEmptyState(thread, 'Aucun message', 'Quand une conversation sera ouverte, tu la verras ici.');
    return;
  }

  // Tabs and search
  let activeTab = 'all';
  let searchQuery = '';
  const searchInput = qs('.msg-search input');
  const tabs = qsa('.msg-tab');

  function updateTabs() {
    tabs.forEach(tab => {
      const isActive = (activeTab === 'all' && tab.textContent.toLowerCase().includes('tous')) ||
        (activeTab === 'unread' && tab.textContent.toLowerCase().includes('non lus'));
      tab.classList.toggle('active', isActive);
    });
  }

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      activeTab = tab.textContent.toLowerCase().includes('tous') ? 'all' : 'unread';
      updateTabs();
      renderConversationList(selectedConversationId);
    });
  });

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.toLowerCase().trim();
      renderConversationList(selectedConversationId);
    });
  }

  async function renderConversationList(activeConversationId) {
    // Fetch participants for all conversations to get profile data
    const conversationIds = conversations.map(c => c.conversation_id).filter(Boolean);
    let allParticipants = [];
    try {
      const { data } = await supabase
        .from('conversation_participants')
        .select(`
          conversation_id,
          user_id,
          profiles:user_id(
            id,
            full_name,
            email,
            avatar_path
          )
        `)
        .in('conversation_id', conversationIds);
      allParticipants = data || [];
    } catch (e) {
      console.warn('Could not fetch participants:', e);
    }

    const participantsByConv = new Map();
    for (const p of allParticipants) {
      const bucket = participantsByConv.get(p.conversation_id) || [];
      bucket.push(p);
      participantsByConv.set(p.conversation_id, bucket);
    }

    // Filter conversations based on tab and search
    let filteredConversations = conversations;

    // Filter by tab (unread = has unread messages)
    if (activeTab === 'unread') {
      filteredConversations = filteredConversations.filter(row => {
        const convParticipants = participantsByConv.get(row.conversation_id) || [];
        const myParticipant = convParticipants.find(p => p.user_id === currentProfile?.id);
        const lastReadAt = myParticipant?.last_read_at;
        const lastMessageAt = row.last_message_at || row.sent_at;
        return lastReadAt && lastMessageAt && new Date(lastMessageAt) > new Date(lastReadAt);
      });
    }

    // Filter by search
    if (searchQuery) {
      filteredConversations = filteredConversations.filter(row => {
        const title = (row.title || '').toLowerCase();
        const subtitle = (row.subtitle || '').toLowerCase();
        return title.includes(searchQuery) || subtitle.includes(searchQuery);
      });
    }

    if (!filteredConversations.length) {
      list.innerHTML = `<div class="msg-loading">${activeTab === 'unread' ? 'Aucune conversation non lue' : 'Aucune résultat pour "${escapeHtml(searchQuery)}"'}</div>`;
      qsa('[data-recruiter-conversation]').forEach((button) => {
        button.addEventListener('click', () => loadThread(button.dataset.recruiterConversation));
      });
      return;
    }

    list.innerHTML = filteredConversations.map((row) => {
      const isActive = row.conversation_id === activeConversationId;
      const title = row.title || 'Conversation';
      const subtitle = (row.subtitle || 'Aucun message').replace(/^Avec\s*/i, '');

      // Get participant profile data from fetched data
      const convParticipants = participantsByConv.get(row.conversation_id) || [];
      const otherParticipants = convParticipants.filter(p => p.user_id !== currentProfile?.id);
      const firstOther = otherParticipants[0];
      const avatarPath = firstOther?.profiles?.avatar_path || null;
      const avatarDataAttr = avatarPath ? `data-avatar-path="${escapeHtml(avatarPath)}"` : '';

      const time = row.last_message_at
        ? new Date(row.last_message_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
        : '';

      return `
        <button type="button" class="msg-conv-item ${isActive ? 'active' : ''}" data-recruiter-conversation="${escapeHtml(row.conversation_id)}">
          <div class="msg-conv-avatar msg-lazy-avatar" ${avatarDataAttr}></div>
          <div class="msg-conv-info">
            <p class="msg-conv-name">${escapeHtml(subtitle)}</p>
            <p class="msg-conv-snippet">${escapeHtml(title)}</p>
          </div>
          <div class="msg-conv-meta">
            ${time ? `<span class="msg-conv-time">${escapeHtml(time)}</span>` : ''}
          </div>
        </button>
      `;
    }).join('');

    qsa('[data-recruiter-conversation]').forEach((button) => {
      button.addEventListener('click', () => loadThread(button.dataset.recruiterConversation));
    });

    // Lazy load avatars
    const lazyAvatars = qsa('.msg-lazy-avatar[data-avatar-path]');
    if (lazyAvatars.length) {
      try {
        const { getSafeAssetUrl } = await import('/assets/supabase/unibox-storage.js');
        for (const avatar of lazyAvatars) {
          const path = avatar.dataset.avatarPath;
          if (path) {
            const url = await getSafeAssetUrl('avatars', path);
            avatar.style.backgroundImage = `url('${escapeHtml(url)}')`;
            avatar.style.backgroundSize = 'cover';
            avatar.style.backgroundPosition = 'center';
          }
        }
      } catch (_) { }
    }
  }

  async function loadThread(conversationId) {
    selectedConversationId = conversationId;
    await renderConversationList(conversationId);

    // Mise à jour du bouton Signaler conversation
    const reportBtn = qs('#recruiterReportConversationBtn');
    if (reportBtn && conversationId) {
      reportBtn.href = `/recruiter/rec-signalement.html?targetType=conversation&targetId=${encodeURIComponent(conversationId)}`;
      reportBtn.style.display = '';
    }

    const [messages, participants] = await Promise.all([
      listRecruiterMessages(conversationId).catch(() => []),
      listRecruiterConversationParticipants(conversationId).catch(() => []),
    ]);

    const otherParticipants = participants.filter((entry) => entry.user_id !== currentProfile?.id);
    const firstOther = otherParticipants[0];
    const participantNames = otherParticipants
      .map((entry) => entry.profiles?.full_name || entry.profiles?.email)
      .filter(Boolean);
    const participantAvatarPath = firstOther?.profiles?.avatar_path || null;
    const headerAvatarDataAttr = participantAvatarPath ? `data-avatar-path="${escapeHtml(participantAvatarPath)}"` : '';

    // Met à jour le header du fil
    const headerName = qs('#msgHeaderName');
    const headerStatus = qs('#msgHeaderStatus');
    const headerAvatar = qs('#msgHeaderAvatar');
    if (participantNames.length) {
      const name = participantNames.join(', ');
      if (headerName) headerName.textContent = name;
      if (headerStatus) headerStatus.textContent = 'En ligne';
      if (headerAvatar && participantAvatarPath) {
        headerAvatar.classList.add('msg-lazy-avatar');
        headerAvatar.setAttribute('data-avatar-path', participantAvatarPath);
        headerAvatar.textContent = name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();

        // Load header avatar immediately
        try {
          const { getSafeAssetUrl } = await import('/assets/supabase/unibox-storage.js');
          const url = await getSafeAssetUrl('avatars', participantAvatarPath);
          headerAvatar.style.backgroundImage = `url('${escapeHtml(url)}')`;
          headerAvatar.style.backgroundSize = 'cover';
          headerAvatar.style.backgroundPosition = 'center';
          headerAvatar.textContent = '';
        } catch (_) { }
      } else if (headerAvatar) {
        headerAvatar.textContent = name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
      }
    }

    if (!messages.length) {
      thread.innerHTML = `<div class="msg-empty"><span class="material-symbols-outlined" style="font-size:48px;color:#555770;">chat</span><p>Démarre la conversation avec un premier message.</p></div>`;
      await markRecruiterConversationRead(conversationId).catch(() => null);
      return;
    }

    thread.innerHTML = messages.map((message) => {
      const isMine = message.sender_user_id === currentProfile?.id;
      const senderName = escapeHtml(message.profiles?.full_name || message.profiles?.email || 'UNIBOX');
      const initials = senderName.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase() || 'UN';
      const time = escapeHtml(formatDateTime(message.sent_at));
      return `
        <div class="msg-row ${isMine ? 'me' : ''}">
          <div class="msg-bubble ${isMine ? 'msg-bubble-sent' : 'msg-bubble-received'}">
            <div class="msg-meta"><strong>${senderName}</strong><span>${time}</span></div>
            ${message.body ? `<div>${escapeHtml(message.body)}</div>` : ''}
            ${message.attachment_url ? `<a class="msg-bubble-attachment" href="${escapeHtml(message.attachment_url)}" target="_blank" rel="noopener"><span class="material-symbols-outlined" style="font-size:14px;">description</span> Pièce jointe</a>` : ''}
          </div>
        </div>
      `;
    }).join('');

    // Scroll au dernier message
    thread.scrollTop = thread.scrollHeight;

    await markRecruiterConversationRead(conversationId).catch(() => null);
  }

  await renderConversationList(null);
  const initialConversationId = requestedConversationId
    || (applicationId ? conversations.find((row) => row.conversations?.application_id === applicationId)?.conversation_id : null)
    || conversations[0]?.conversation_id;

  if (initialConversationId) await loadThread(initialConversationId);

  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const value = input?.value.trim();
    if (!value || !selectedConversationId) return;
    try {
      await sendRecruiterMessage({ conversationId: selectedConversationId, body: value });
      input.value = '';
      await loadThread(selectedConversationId);
      appToast('Message envoyé', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible d’envoyer le message.', 'error');
    }
  });
}

async function initNotifications() {
  const mount = qs('#recruiterNotificationsList');
  if (!mount) return;

  const notifications = await listRecruiterNotifications().catch(() => []);
  if (!notifications.length) {
    mount.innerHTML = `
      <div style="text-align: center; padding: 48px 24px;">
        <span class="material-symbols-outlined" style="font-size: 56px; color: #ddd6ea; margin-bottom: 16px; display: block;">notifications_off</span>
        <h3 style="margin: 0 0 8px; font-size: 18px; font-weight: 600; color: #1b1b25;">Aucune notification</h3>
        <p style="margin: 0; color: #a09ab8; font-size: 14px; line-height: 1.5;">Les nouvelles candidatures, messages et mises à jour d'offres apparaîtront ici.</p>
      </div>
    `;
    return;
  }

  renderNotifications(mount, notifications);

  qsa('[data-recruiter-read-notification]').forEach((button) => {
    button.addEventListener('click', async () => {
      try {
        await markRecruiterNotificationRead(button.dataset.recruiterReadNotification);
        const card = button.closest('.notification-card');
        if (card) {
          card.style.borderLeft = 'none';
          card.style.background = '';
          const dot = card.querySelector('[style*="border-radius: 50%"]');
          if (dot) dot.remove();
        }
        button.remove();
        appToast('Notification lue', 'success');
      } catch (error) {
        appToast(error.message || 'Impossible de mettre la notification à jour.', 'error');
      }
    });
  });

  qs('#recruiterNotificationsMarkAll')?.addEventListener('click', async () => {
    try {
      await markAllRecruiterNotificationsRead();
      qsa('[data-recruiter-read-notification]').forEach((button) => button.remove());
      qsa('#recruiterNotificationsList .notification-card').forEach((card) => {
        card.style.borderLeft = 'none';
        card.style.background = '';
        const dot = card.querySelector('[style*="border-radius: 50%"]');
        if (dot) dot.remove();
      });
      appToast('Toutes les notifications sont à jour', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible de marquer les notifications comme lues.', 'error');
    }
  });
}

async function initHistory() {
  const mount = qs('#recruiterHistoryMount');
  if (!mount) return;

  let offers = [];
  let applications = [];
  try {
    const [offersData, appsData] = await Promise.all([
      listRecruiterOffers(),
      listRecruiterApplications()
    ]);
    offers = offersData || [];
    applications = appsData || [];
  } catch (error) {
    renderEmptyState(mount, 'Impossible de charger ton historique', error.message || 'Réessaie dans un instant.');
    return;
  }

  // Combiner offres et candidatures en événements
  const events = [
    ...offers.map(o => ({ type: 'offer', item: o, date: o.created_at })),
    ...applications.map(a => ({ type: 'application', item: a, date: a.submitted_at }))
  ].sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));

  if (!events.length) {
    renderEmptyState(mount, 'Aucun historique', 'Tes actions de recrutement apparaîtront ici.');
    return;
  }

  mount.innerHTML = `
    <div style="position: relative; padding-left: 24px;">
      <div style="position: absolute; left: 11px; top: 8px; bottom: 8px; width: 2px; background: linear-gradient(to bottom, #ddd6ea, #ede9f8); border-radius: 1px;"></div>
      ${events.map((event) => {
        const isOffer = event.type === 'offer';
        const item = event.item;
        const title = isOffer ? item.title : (item.profiles?.full_name || 'Candidat');
        const subtitle = isOffer 
          ? `Offre ${item.status === 'published' ? 'publiée' : item.status}` 
          : `Candidature ${item.status || 'reçue'}`;
        const icon = isOffer ? 'work' : 'person';
        const color = isOffer ? '#6b38d4' : '#d97706';
        const when = formatDateTime(event.date);

        return `
          <div style="position: relative; margin-bottom: 20px;">
            <div style="position: absolute; left: -19px; top: 2px; width: 16px; height: 16px; border-radius: 50%; background: ${color}; border: 3px solid #fff; box-shadow: 0 0 0 2px ${color}33; z-index: 1;"></div>
            <div style="background: #f8f6ff; border-radius: 12px; padding: 18px 20px; border: 1px solid #ede9f8; display: flex; gap: 16px; align-items: flex-start;">
              <div style="width: 42px; height: 42px; border-radius: 10px; background: linear-gradient(135deg, ${color}, ${color}cc); display: grid; place-items: center; flex-shrink: 0;">
                <span class="material-symbols-outlined" style="font-size: 20px; color: #fff;">${icon}</span>
              </div>
              <div style="flex: 1; min-width: 0;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 4px;">
                  <h4 style="margin: 0; font-size: 15px; font-weight: 600; color: #1b1b25;">${escapeHtml(subtitle)} · ${escapeHtml(title)}</h4>
                  <span style="font-size: 11px; color: #a09ab8; white-space: nowrap;">${escapeHtml(when)}</span>
                </div>
                <p style="margin: 0; color: #5d576c; font-size: 13px; line-height: 1.5;">${isOffer ? (item.city || 'Ville non spécifiée') : (item.offers?.title || 'Offre')}</p>
              </div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function getReportIcon(targetType) {
  const type = (targetType || '').toLowerCase();
  if (type === 'offer') return 'work';
  if (type === 'minute_job') return 'timer';
  if (type === 'profile') return 'person';
  if (type === 'conversation') return 'chat';
  if (type === 'message') return 'message';
  if (type === 'company') return 'business';
  return 'flag';
}

function getReportColor(status) {
  const s = (status || '').toLowerCase();
  if (s === 'open' || s === 'nouveau') return '#dc2626';
  if (s === 'in_review' || s === 'en_cours') return '#f59e0b';
  if (s === 'resolved' || s === 'resolu') return '#10b981';
  if (s === 'dismissed' || s === 'classé') return '#6b7280';
  return '#6b38d4';
}

function getReportStatusLabel(status) {
  const s = (status || '').toLowerCase();
  if (s === 'open') return 'Ouvert';
  if (s === 'in_review') return 'En cours';
  if (s === 'resolved') return 'Résolu';
  if (s === 'dismissed') return 'Classé';
  return status || 'Inconnu';
}

async function initReports() {
  const listMount = qs('#recruiterReportsList');
  if (listMount) {
    try {
      const reports = await listMyReports();
      const items = reports.data || [];
      if (!items.length) {
        listMount.innerHTML = `
          <div style="text-align: center; padding: 48px 24px;">
            <h3 style="margin: 0 0 8px; font-size: 18px; font-weight: 600; color: #1b1b25;">Aucun signalement</h3>
            <p style="margin: 0; color: #a09ab8; font-size: 14px; line-height: 1.5;">Les signalements UNIBOX que tu envoies apparaîtront ici.</p>
          </div>
        `;
      } else {
        listMount.innerHTML = items.map((item) => {
          const icon = getReportIcon(item.target_type);
          const color = getReportColor(item.status);
          const statusLabel = getReportStatusLabel(item.status);

          return `
          <article class="report-card" style="padding: 0; overflow: hidden; border-left: 3px solid ${color};">
            <div style="display: flex; align-items: flex-start; gap: 16px; padding: 18px 20px;">
              <div style="flex-shrink: 0; width: 44px; height: 44px; border-radius: 12px; background: ${color}15; display: grid; place-items: center;">
                <span class="material-symbols-outlined" style="font-size: 22px; color: ${color};">${icon}</span>
              </div>
              <div style="flex: 1; min-width: 0;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 4px;">
                  <h3 style="margin: 0; font-size: 15px; font-weight: 600; color: #1b1b25; line-height: 1.4;">${escapeHtml(getReportTargetDisplay(item))}</h3>
                  <span class="pill" style="background: ${color}15; color: ${color}; border: 1px solid ${color}30; font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 20px; flex-shrink: 0;">${escapeHtml(statusLabel)}</span>
                </div>
                <p style="margin: 0 0 8px; color: #5d576c; font-size: 14px; line-height: 1.5;">${escapeHtml(item.description || item.reason_code || 'Signalement UNIBOX')}</p>
                <div style="display: flex; flex-wrap: wrap; gap: 8px; align-items: center;">
                  <span class="pill soft" style="font-size: 11px;">${escapeHtml(item.target_type)}</span>
                  <span class="pill soft" style="font-size: 11px;">${escapeHtml(item.reason_code)}</span>
                  <span style="font-size: 12px; color: #a09ab8; display: flex; align-items: center; gap: 4px;">
                    <span class="material-symbols-outlined" style="font-size: 14px;">schedule</span>
                    ${escapeHtml(formatDateTime(item.created_at))}
                  </span>
                </div>
              </div>
            </div>
          </article>
        `}).join('');
      }
    } catch (error) {
      listMount.innerHTML = `
        <div style="text-align: center; padding: 48px 24px;">
          <span class="material-symbols-outlined" style="font-size: 56px; color: #ddd6ea; margin-bottom: 16px; display: block;">error</span>
          <h3 style="margin: 0 0 8px; font-size: 18px; font-weight: 600; color: #1b1b25;">Impossible de charger</h3>
          <p style="margin: 0; color: #a09ab8; font-size: 14px; line-height: 1.5;">${escapeHtml(error.message || 'Réessaie dans un instant.')}</p>
        </div>
      `;
    }
  }

  const targetTypeInput = qs('#recruiterReportTargetType');
  const targetIdInput = qs('#recruiterReportTargetId');
  const reasonInput = qs('#recruiterReportReason');
  const textInput = qs('#recruiterReportText');
  const params = new URLSearchParams(window.location.search);

  // Préremplissage + affichage récap si params URL présents
  const recapEl = qs('#recruiterReportRecap');
  const recapTextEl = qs('#recruiterReportRecapText');
  const fieldsEl = qs('#recruiterReportTargetFields');
  const prefillType = params.get('targetType');
  const prefillId = params.get('targetId');

  if (prefillType && prefillId && targetTypeInput && targetIdInput) {
    targetTypeInput.value = prefillType;
    targetIdInput.value = prefillId;
    if (recapEl) recapEl.style.display = 'block';
    if (fieldsEl) fieldsEl.style.display = 'none';
    if (recapTextEl) {
      const typeLabels = {
        profile: 'Profil utilisateur',
        conversation: 'Conversation',
        message: 'Message'
      };
      const label = typeLabels[prefillType] || prefillType;
      const shortId = prefillId.length > 12 ? prefillId.slice(0, 12) + '...' : prefillId;
      recapTextEl.textContent = `${label} · ${shortId}`;
    }
  } else {
    if (recapEl) recapEl.style.display = 'none';
    if (fieldsEl) fieldsEl.style.display = 'block';
  }

  qs('#recruiterReportSend')?.addEventListener('click', async () => {
    const button = qs('#recruiterReportSend');
    try {
      setLoading(button, true, 'Envoi...');
      await createReport({
        targetType: targetTypeInput?.value || '',
        targetId: targetIdInput?.value?.trim() || '',
        reasonCode: reasonInput?.value || '',
        description: textInput?.value?.trim() || '',
      });
      appToast('Signalement envoyé à l’admin UNIBOX.', 'success');
      closeModal(qs('#recruiterReportModal'));
      if (textInput) textInput.value = '';
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible d’envoyer le signalement.', 'error');
    } finally {
      setLoading(button, false);
    }
  });
}

async function initSettings() {
  const profile = await getCurrentProfile().catch(() => null);
  const roleProfile = profile ? await getRoleProfile('recruiter', profile.id).catch(() => null) : null;

  const fullName = profile?.full_name || 'Recruteur UNIBOX';
  const jobTitle = roleProfile?.job_title || 'Rôle non renseigné';

  if (qs('#recruiterFullName') && profile) qs('#recruiterFullName').value = profile.full_name || '';
  if (qs('#recruiterEmail') && profile) qs('#recruiterEmail').value = profile.email || '';
  if (qs('#recruiterCity') && profile) qs('#recruiterCity').value = profile.city || '';
  if (qs('#recruiterJobTitle') && roleProfile) qs('#recruiterJobTitle').value = roleProfile.job_title || '';
  if (qs('#recruiterBio') && roleProfile) qs('#recruiterBio').value = roleProfile.bio || '';

  if (qs('#recruiterAvatarName')) qs('#recruiterAvatarName').textContent = fullName;
  if (qs('#recruiterAvatarRole')) qs('#recruiterAvatarRole').textContent = jobTitle;

  // Avatar preview on file select
  qs('#recruiterAvatarInput')?.addEventListener('change', (event) => {
    const file = event.target.files?.[0];
    const preview = qs('#recruiterAvatarPreview');
    if (file && preview) {
      const reader = new FileReader();
      reader.onload = (e) => { preview.src = e.target.result; };
      reader.readAsDataURL(file);
    }
  });

  // Load current avatar from profile
  if (profile?.avatar_path) {
    const preview = qs('#recruiterAvatarPreview');
    if (preview) {
      try {
        const { getSafeAssetUrl } = await import('/assets/supabase/unibox-storage.js');
        const url = await getSafeAssetUrl('avatars', profile.avatar_path);
        preview.src = url;
      } catch (_) { }
    }
  }

  // Live update avatar hero on input change
  qs('#recruiterFullName')?.addEventListener('input', (e) => {
    const nameEl = qs('#recruiterAvatarName');
    if (nameEl) nameEl.textContent = e.target.value.trim() || 'Recruteur UNIBOX';
  });
  qs('#recruiterJobTitle')?.addEventListener('input', (e) => {
    const roleEl = qs('#recruiterAvatarRole');
    if (roleEl) roleEl.textContent = e.target.value.trim() || 'Rôle non renseigné';
  });

  qs('#recruiterLogoutBtn')?.addEventListener('click', async () => {
    try {
      const { logout } = await import('/assets/js/unibox-auth.js');
      await logout();
      window.location.href = '/index-enhanced.html#signin';
    } catch {
      window.location.href = '/index-enhanced.html#signin';
    }
  });

  qs('#recruiterSettingsForm')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = qs('#recruiterSettingsSave');
    const avatarInput = qs('#recruiterAvatarInput');
    try {
      setLoading(button, true, 'Enregistrement...');

      let avatarPath = null;
      if (avatarInput?.files?.[0]) {
        try {
          const { uploadAvatar } = await import('/assets/supabase/unibox-storage.js');
          avatarPath = await uploadAvatar(avatarInput.files[0]);
          console.log('[Avatar] Upload successful:', avatarPath);
        } catch (uploadError) {
          console.error('[Avatar] Upload failed:', uploadError);
          appToast('Erreur lors de l\'upload de l\'avatar: ' + (uploadError.message || 'Vérifiez le bucket Supabase'), 'error');
          setLoading(button, false);
          return;
        }
      }

      await updateRecruiterProfile({
        full_name: qs('#recruiterFullName')?.value.trim(),
        city: qs('#recruiterCity')?.value.trim(),
        job_title: qs('#recruiterJobTitle')?.value.trim(),
        bio: qs('#recruiterBio')?.value.trim(),
        avatar_path: avatarPath,
      });
      appToast('Paramètres enregistrés', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible d’enregistrer les paramètres', 'error');
    } finally {
      setLoading(button, false);
    }
  });
}

async function initHelp() {
  qsa('[data-recruiter-faq]').forEach((button) => {
    button.addEventListener('click', () => {
      const icon = button.querySelector('.icon');
      const content = qs(`#${button.dataset.recruiterFaq}`);
      if (content && icon) {
        content.classList.toggle('hidden');
        if (content.classList.contains('hidden')) {
          button.classList.remove('active');
          icon.style.transform = 'rotate(0deg)';
        } else {
          button.classList.add('active');
          icon.style.transform = 'rotate(180deg)';
        }
      }
    });
  });

  // Highlight cat-link on click + filter FAQ sections
  function showFaqSection(targetId) {
    qsa('section[id^="faq-"]').forEach((section) => {
      section.style.display = section.id === targetId ? '' : 'none';
    });
  }

  qsa('.cat-link').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      qsa('.cat-link').forEach((l) => l.classList.remove('active'));
      link.classList.add('active');
      const href = link.getAttribute('href');
      if (href) showFaqSection(href.slice(1));
    });
  });

  // Show all sections on load
  qsa('section[id^="faq-"]').forEach((section) => { section.style.display = ''; });

  // Search FAQ
  qs('#faqSearchInput')?.addEventListener('input', (e) => {
    const term = e.target.value.trim().toLowerCase();
    if (!term) {
      // Empty search -> restore active category filter
      const active = qs('.cat-link.active');
      const href = active?.getAttribute('href');
      if (href) showFaqSection(href.slice(1));
      qsa('.faq-item').forEach((item) => { item.style.display = ''; });
      qsa('.faq-section-title').forEach((t) => { t.style.display = ''; });
      return;
    }
    // Searching -> show all sections and filter items
    qsa('section[id^="faq-"]').forEach((s) => { s.style.display = ''; });
    qsa('.faq-item').forEach((item) => {
      const text = item.textContent.toLowerCase();
      item.style.display = text.includes(term) ? '' : 'none';
    });
    qsa('.faq-section-title').forEach((title) => {
      const section = title.closest('section');
      if (section) {
        const visible = section.querySelectorAll('.faq-item:not([style*="none"])').length;
        title.style.display = visible > 0 ? '' : 'none';
        section.style.display = visible > 0 ? '' : 'none';
      }
    });
  });

  qs('#recruiterHelpSend')?.addEventListener('click', () => {
    appToast('Message support envoyé', 'success');
    closeModal(qs('#recruiterHelpModal'));
    qs('#recruiterHelpSubject').value = '';
    qs('#recruiterHelpMessage').value = '';
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  await mountRecruiterShell();
  initModals();

  qsa('[data-status-filter]').forEach((button) => {
    button.addEventListener('click', async () => {
      qsa('[data-status-filter]').forEach((node) => node.classList.remove('is-active'));
      button.classList.add('is-active');
      await initOffersList();
    });
  });

  const page = document.body.dataset.page;
  if (page === 'recruiter-dashboard') await initDashboard();
  if (page === 'recruiter-company') await initCompany();
  if (page === 'recruiter-offers') await initOffersList();
  if (page === 'recruiter-offer-create') await initOfferCreate();
  if (page === 'recruiter-offer-edit') await initOfferEdit();
  if (page === 'recruiter-offer-detail') await initOfferDetail();
  if (page === 'recruiter-applications') await initApplications();
  if (page === 'recruiter-candidate-detail') await initCandidateDetail();
  if (page === 'recruiter-messages') await initMessages();
  if (page === 'recruiter-notifications') await initNotifications();
  if (page === 'recruiter-history') await initHistory();
  if (page === 'recruiter-reports') await initReports();
  if (page === 'recruiter-settings') await initSettings();
  if (page === 'recruiter-help') await initHelp();
});
