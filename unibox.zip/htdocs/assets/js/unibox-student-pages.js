import { qs, qsa, appToast, setLoading } from '/assets/js/unibox-core.js';
import { mountStudentShell } from '/assets/js/unibox-student-shell.js';
import {
  listStudentListings,
  getStudentListingDetail,
  saveStudentListing,
  listStudentApplications,
  getStudentApplicationDetail,
  applyStudentToListing,
  withdrawStudentApplication,
  listStudentSavedListings,
  listStudentNotifications,
  markStudentNotificationRead,
  markAllStudentNotificationsRead,
  updateStudentProfile,
  listStudentPortfolioItems,
  createStudentPortfolioItem,
  updateStudentPortfolioItem,
  deleteStudentPortfolioItem,
  listStudentMessages,
  listConversationMessages,
  sendStudentMessage,
  getOrCreateStudentApplicationConversation,
  listStudentConversationParticipants,
  markStudentConversationRead,
} from '/assets/supabase/unibox-student.js';
import { getCurrentProfile, getRoleProfile } from '/assets/supabase/unibox-profile.js';
import { uploadAvatar, uploadStudentCv, getPublicAssetUrl, getSafeAssetUrl } from '/assets/supabase/unibox-storage.js';
import { SUPABASE_CONFIG } from '/assets/supabase/supabase-config.js';
import { createReport } from '/assets/supabase/unibox-reports.js';
import { supabase } from '/assets/supabase/supabase-client.js';
import { STORAGE_BUCKETS } from '/assets/config/app.config.js';

const STUDENT_LISTING_FILTERS = ['all', 'stage', 'part-time', 'full-time', 'job-minute'];

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function formatDate(value) {
  if (!value) return 'Date non précisée';
  return new Date(value).toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

function labelEmploymentType(value) {
  switch (value) {
    case 'stage':
      return 'Stage';
    case 'part-time':
      return 'Temps partiel';
    case 'full-time':
      return 'Temps plein';
    default:
      return value || 'Offre';
  }
}

function labelWorkMode(value) {
  switch (value) {
    case 'on-site':
      return 'Entreprise';
    case 'remote':
      return 'À distance';
    case 'hybrid':
      return 'Hybride';
    default:
      return value;
  }
}

function labelListingType(value) {
  return value === 'minute_job' ? 'Job minute' : 'Offre entreprise';
}

function labelUrgency(value) {
  switch (value) {
    case 'high':
      return 'Urgent';
    case 'medium':
      return 'Priorité moyenne';
    case 'low':
      return 'Souple';
    default:
      return 'Job minute';
  }
}

const STUDENT_APPLICATION_FILTERS = ['all', 'examination', 'accepted', 'rejected', 'withdrawn'];

function formatDateTime(value) {
  if (!value) return 'Date non précisée';
  return new Date(value).toLocaleString('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function getStudentStatusLabel(status) {
  switch (status) {
    case 'accepted':
      return 'Accepté';
    case 'rejected':
      return 'Refusé';
    case 'withdrawn':
      return 'Retiré';
    case 'cancelled':
      return 'Annulé';
    default:
      return 'En examination';
  }
}

function getNotificationLevelMeta(level) {
  switch (level) {
    case 'success':
      return { label: 'Succès', style: 'background:#e8f7ee;color:#157347;border:1px solid #b7ebc6;' };
    case 'warning':
      return { label: 'Attention', style: 'background:#fff4e5;color:#b26a00;border:1px solid #ffd8a8;' };
    case 'error':
      return { label: 'Alerte', style: 'background:#fdecec;color:#b42318;border:1px solid #f5c2c7;' };
    default:
      return { label: 'Info', style: 'background:#f1ebff;color:#6f42c1;border:1px solid #d8c7ff;' };
  }
}

const APPLICATION_STATUS_ICONS = {
  examination: 'hourglass_empty',
  accepted: 'check_circle',
  rejected: 'cancel',
  withdrawn: 'undo',
  pending: 'schedule',
};

const APP_STATUS_STYLE = {
  submitted: { label: 'En examination', bg: 'rgba(107,56,212,0.12)', color: '#6b38d4' },
  under_review: { label: 'En examination', bg: 'rgba(107,56,212,0.12)', color: '#6b38d4' },
  shortlisted: { label: 'Pré-sélectionnée', bg: 'rgba(245,158,11,0.12)', color: '#d97706' },
  interview_requested: { label: 'Entretien demandé', bg: 'rgba(245,158,11,0.12)', color: '#d97706' },
  accepted: { label: 'Acceptée', bg: 'rgba(5,150,105,0.12)', color: '#059669' },
  completed: { label: 'Terminée', bg: 'rgba(5,150,105,0.12)', color: '#059669' },
  rejected: { label: 'Refusée', bg: 'rgba(220,38,38,0.12)', color: '#dc2626' },
  withdrawn: { label: 'Retirée', bg: 'rgba(107,114,128,0.12)', color: '#4b5563' },
  cancelled: { label: 'Annulée', bg: 'rgba(107,114,128,0.12)', color: '#4b5563' },
};

function matchStudentApplicationFilter(item, filterKey) {
  if (filterKey === 'all') return true;
  if (filterKey === 'accepted') return item.status === 'accepted';
  if (filterKey === 'rejected') return item.status === 'rejected';
  if (filterKey === 'withdrawn') return item.status === 'withdrawn';
  if (filterKey === 'examination') {
    return !['accepted', 'rejected', 'withdrawn', 'cancelled'].includes(item.status);
  }
  return true;
}

function getStudentListingTitleFromApplication(item) {
  return item.offer_title || item.minute_job_title || 'Candidature UNIBOX';
}

function getStudentApplicationLocation(item) {
  return item.offer_city || item.minute_job_city || 'Flexible';
}

function getApplicationCompanyName(application) {
  return application.company_name
    || application.offer_company_name
    || application.recruiter_company_name
    || application.owner_display_name
    || application.offers?.companies?.name
    || application.offers?.company_name
    || application.minute_jobs?.profiles?.full_name
    || 'UNIBOX';
}

function renderApplicationDocuments(documents = []) {
  if (!documents.length) {
    return '<p style="margin:0;font-size:13px;color:#8b85a0;font-style:italic;">Aucun document envoyé pour cette candidature.</p>';
  }

  return `<div style="display:flex;flex-direction:column;gap:8px;">${documents.map((document) => `
    <a href="${escapeHtml(document.signed_url || '#')}" ${document.signed_url ? 'target="_blank" rel="noopener"' : ''} style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:#f8f6ff;border:1px solid #ede9f8;border-radius:8px;text-decoration:none;transition:background 0.15s ease;" onmouseover="this.style.background='#f0ecff'" onmouseout="this.style.background='#f8f6ff'">
      <span class="material-symbols-outlined" style="font-size:20px;color:#6b38d4;flex-shrink:0;">description</span>
      <div style="min-width:0;">
        <div style="font-size:13px;font-weight:600;color:#1b1b25;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(document.file_name || 'Document')}</div>
        <div style="font-size:11px;color:#8b85a0;margin-top:2px;">${escapeHtml(document.mime_type || 'PDF')}</div>
      </div>
      <span class="material-symbols-outlined" style="font-size:16px;color:#8b85a0;flex-shrink:0;margin-left:auto;">open_in_new</span>
    </a>
  `).join('')}</div>`;
}

function renderApplicationTimeline(events = []) {
  if (!events.length) {
    return '<p style="margin:0;font-size:13px;color:#8b85a0;font-style:italic;">Aucun historique disponible pour le moment.</p>';
  }

  const items = events.map((event, index) => {
    const s = APP_STATUS_STYLE[event.to_status || event.status] || { label: event.to_status || event.status || 'Inconnu', color: '#5d576c', bg: 'rgba(107,114,128,0.08)' };
    const isLast = index === events.length - 1;
    return `
      <div style="display:flex;gap:12px;${!isLast ? 'margin-bottom:12px;' : ''}">
        <div style="display:flex;flex-direction:column;align-items:center;flex-shrink:0;">
          <div style="width:10px;height:10px;border-radius:50%;background:${s.color};box-shadow:0 0 0 3px ${s.bg || 'rgba(107,114,128,0.08)'};flex-shrink:0;"></div>
          ${!isLast ? '<div style="width:2px;flex:1;background:linear-gradient(to bottom, #ddd6ea, transparent);margin-top:4px;"></div>' : ''}
        </div>
        <div style="flex:1;min-width:0;padding-bottom:4px;">
          <div style="font-size:13px;font-weight:600;color:${s.color};">${escapeHtml(s.label)}</div>
          <div style="font-size:11px;color:#8b85a0;margin-top:2px;">${escapeHtml(formatDateTime(event.created_at))}</div>
          ${event.notes ? `<div style="font-size:12px;color:#5d576c;margin-top:4px;line-height:1.4;">${escapeHtml(event.notes)}</div>` : ''}
        </div>
      </div>
    `;
  }).join('');

  return `<div style="display:flex;flex-direction:column;">${items}</div>`;
}

function buildListingHref(item) {
  return `/student/etd-offre-detail.html?listing=${encodeURIComponent(item.listing_id || item.id)}&type=${encodeURIComponent(item.listing_type || 'offer')}`;
}

function getListingPrimaryTag(item) {
  if (item.listing_type === 'minute_job') {
    return labelUrgency(item.urgency_level);
  }
  return labelEmploymentType(item.employment_type);
}

function getListingOwnerLabel(item) {
  return item.company_name || item.owner_display_name || 'UNIBOX';
}

function getListingLocationLabel(item) {
  return item.location_label || [item.address_text, item.city, item.country].filter(Boolean).join(', ') || 'Localisation à confirmer';
}

function readOfferFilterState() {
  const params = new URLSearchParams(window.location.search);
  const type = params.get('type');
  const keyword = params.get('q') || '';
  const location = params.get('location') || '';

  return {
    type: STUDENT_LISTING_FILTERS.includes(type) ? type : 'all',
    keyword,
    location,
  };
}

function writeOfferFilterState(state) {
  const params = new URLSearchParams(window.location.search);

  if (state.type && state.type !== 'all') params.set('type', state.type);
  else params.delete('type');

  if (state.keyword?.trim()) params.set('q', state.keyword.trim());
  else params.delete('q');

  if (state.location?.trim()) params.set('location', state.location.trim());
  else params.delete('location');

  const nextQuery = params.toString();
  const nextUrl = `${window.location.pathname}${nextQuery ? `?${nextQuery}` : ''}`;
  window.history.replaceState({}, '', nextUrl);
}

function translateOfferFilterState(state) {
  if (state.type === 'job-minute') {
    return {
      listingType: 'minute_job',
      employmentTypes: [],
      search: state.keyword,
      location: state.location,
    };
  }

  if (['stage', 'part-time', 'full-time'].includes(state.type)) {
    return {
      listingType: null,
      employmentTypes: [state.type],
      search: state.keyword,
      location: state.location,
    };
  }

  return {
    listingType: null,
    employmentTypes: [],
    search: state.keyword,
    location: state.location,
  };
}

function renderEmptyState(target, title, body) {
  if (!target) return;
  target.innerHTML = `
    <article class="empty-state">
      <h3>${escapeHtml(title)}</h3>
      <p>${escapeHtml(body)}</p>
    </article>
  `;
}

async function renderListings(target, items) {
  if (!target) return;

  if (!items.length) {
    renderEmptyState(
      target,
      'Aucune annonce ne correspond à ta recherche',
      'Ajuste les filtres stage / part-time / full-time / job minute ou élargis la localisation.'
    );
    return;
  }

  const itemsWithLogos = await Promise.all(items.map(async (item) => {
    let computedLogoUrl = null;
    const logoPath = item.company_logo_path || item.companies?.logo_path;
    const avatarPath = item.profile_avatar_path || item.profiles?.avatar_path || item.profiles?.avatar_url;

    if (logoPath) {
      computedLogoUrl = await getSafeAssetUrl(STORAGE_BUCKETS.companyLogos, logoPath).catch(() => null);
    } else if (item.listing_type === 'minute_job' && avatarPath) {
      computedLogoUrl = await getSafeAssetUrl(STORAGE_BUCKETS.avatars, avatarPath).catch(() => null);
    }
    return { ...item, computedLogoUrl };
  }));

  target.innerHTML = itemsWithLogos.map((item) => {
    const primaryTag = getListingPrimaryTag(item);
    const owner = getListingOwnerLabel(item);
    const location = getListingLocationLabel(item);
    const listingTypeLabel = labelListingType(item.listing_type);
    const moneyLabel = item.rate_or_salary_label || 'Rémunération à confirmer';
    const publishedLabel = item.published_at ? `Publié le ${formatDate(item.published_at)}` : 'Disponible maintenant';

    const ownerInitial = owner ? owner.charAt(0).toUpperCase() : 'U';
    const roleType = item.listing_type === 'minute_job' ? 'Particulier' : 'Entreprise';

    let logoHtml = `${escapeHtml(ownerInitial)}`;
    if (item.computedLogoUrl) {
      logoHtml = `<img src="${escapeHtml(item.computedLogoUrl)}" alt="Logo" style="width:100%; height:100%; object-fit:cover;" />`;
    } else if (item.listing_type === 'offer') {
      // Fallback Cevital logo for companies
      logoHtml = `<img src="/assets/img/cevital-logo.png" alt="Cevital" style="width:100%; height:100%; object-fit:cover; background:#fff; padding:4px;" />`;
    }

    return `
      <article class="modern-job-card">
        <div class="mj-header">
          <div class="mj-logo">
            ${logoHtml}
          </div>
          <button class="mj-save-btn" type="button" data-save-listing="${escapeHtml(item.listing_id || item.id)}" data-listing-type="${escapeHtml(item.listing_type)}" title="Sauvegarder l'offre">
            Save <span class="material-symbols-outlined" style="font-size: 16px;">bookmark_border</span>
          </button>
        </div>
        
        <div class="mj-company-row">
          <span class="mj-company-name">${escapeHtml(owner)}</span>
          <span class="mj-time-ago">${escapeHtml(publishedLabel)}</span>
        </div>
        
        <h3 class="mj-title">${escapeHtml(item.title)}</h3>
        
        <div class="mj-tags">
          <span class="mj-tag">${escapeHtml(primaryTag)}</span>
          ${item.listing_type === 'offer' && item.employment_type === 'stage'
        ? (item.hours_per_week ? `<span class="mj-tag">${item.hours_per_week >= 35 ? 'Temps plein' : 'Temps partiel'}</span>` : `<span class="mj-tag">Temps plein</span>`)
        : ''}
          ${item.work_mode ? `<span class="mj-tag">${escapeHtml(labelWorkMode(item.work_mode))}</span>` : ''}
        </div>
        
        <div class="mj-footer">
          <div class="mj-price-wrap">
            <span class="mj-price">${escapeHtml(moneyLabel)}</span>
            <span class="mj-location">${escapeHtml(location)}</span>
          </div>
          <a class="mj-apply-btn" href="${buildListingHref(item)}">Voir détails</a>
        </div>
      </article>
    `;
  }).join('');
}


function renderApplications(target, items, filterKey = 'all') {
  const filteredItems = items.filter((item) => matchStudentApplicationFilter(item, filterKey));

  if (!filteredItems.length) {
    target.innerHTML = `
      <div class="empty-state small">
        <strong>Aucune candidature dans ce filtre</strong>
        <span>Tes candidatures UNIBOX apparaîtront ici avec leur état détaillé.</span>
      </div>
    `;
    return;
  }

  target.innerHTML = filteredItems.map((item) => {
    const title = getStudentListingTitleFromApplication(item);
    const company = getApplicationCompanyName(item);
    const city = getStudentApplicationLocation(item);
    const isOffer = !!item.offer_id;
    const statusLabel = getStudentStatusLabel(item.status);
    const docCount = (item.application_documents || []).length;
    const hasInterview = (item.interviews || []).length > 0;
    const s = APP_STATUS_STYLE[item.status] || { label: statusLabel, color: '#6b38d4', bg: 'rgba(107,56,212,0.12)' };

    return `
      <article class="app-card" data-app-status="${escapeHtml(item.status || '')}">
        <div class="app-card-inner">
          <div class="app-card-avatar-col">
            <div style="width:48px;height:48px;border-radius:12px;background:${s.bg};color:${s.color};display:grid;place-items:center;">
              <span class="material-symbols-outlined" style="font-size:24px;">${isOffer ? 'work' : 'timer'}</span>
            </div>
          </div>
          <div class="app-card-body">
            <div class="app-card-top">
              <div>
                <h3 class="app-card-name">${escapeHtml(title)}</h3>
                <p class="app-card-job">${escapeHtml(company)} · ${escapeHtml(city)}</p>
              </div>
            </div>
            <div class="app-card-meta">
              <span class="pill" style="background:${s.bg};color:${s.color};font-weight:600;border:none;">${escapeHtml(s.label)}</span>
              <span class="pill soft">${isOffer ? 'Offre' : 'Job minute'}</span>
              ${hasInterview ? '<span class="pill" style="background:#e0e7ff;color:#4f46e5;font-weight:600;border:none;">Entretien planifié</span>' : ''}
              ${docCount ? `<span class="pill soft">${docCount} doc${docCount > 1 ? 's' : ''}</span>` : ''}
            </div>
            <p class="app-card-date">Soumise le ${escapeHtml(formatDateTime(item.submitted_at))}</p>
          </div>
          <div class="app-card-action-col">
            <a class="btn btn-primary" href="/student/etd-candidature-detail.html?application=${encodeURIComponent(item.id)}" style="padding:8px 14px;font-size:13px;">
              <span class="material-symbols-outlined" style="font-size:16px;">visibility</span>
              Voir
            </a>
            ${['accepted', 'rejected', 'withdrawn', 'cancelled'].includes(item.status) ? '' : `<button class="btn btn-secondary" type="button" data-withdraw-application="${encodeURIComponent(item.id)}" style="padding:8px 14px;font-size:13px;">
              <span class="material-symbols-outlined" style="font-size:16px;">close</span>
              Retirer
            </button>`}
          </div>
        </div>
      </article>
    `;
  }).join('');
}

function getNotificationIcon(title = '', body = '') {
  const text = (title + ' ' + body).toLowerCase();
  if (text.includes('candidat') || text.includes('candidature') || text.includes('offre')) return 'work';
  if (text.includes('message') || text.includes('messag')) return 'chat';
  if (text.includes('entretien') || text.includes('interview')) return 'event';
  if (text.includes('accept') || text.includes('approv')) return 'check_circle';
  if (text.includes('refus') || text.includes('reject')) return 'cancel';
  if (text.includes('shortlist')) return 'star';
  if (text.includes('favori')) return 'favorite';
  return 'notifications';
}

function getNotificationColor(title = '', body = '') {
  const text = (title + ' ' + body).toLowerCase();
  if (text.includes('candidat') || text.includes('candidature') || text.includes('offre')) return '#6b38d4';
  if (text.includes('message')) return '#0ea5e9';
  if (text.includes('entretien') || text.includes('interview')) return '#f59e0b';
  if (text.includes('accept') || text.includes('approv')) return '#10b981';
  if (text.includes('refus') || text.includes('reject')) return '#dc2626';
  if (text.includes('shortlist')) return '#8b5cf6';
  if (text.includes('favori')) return '#ec4899';
  return '#6b7280';
}

function renderNotifications(target, items) {
  target.innerHTML = items.map((item) => {
    const icon = getNotificationIcon(item.title, item.body);
    const color = getNotificationColor(item.title, item.body);
    const isNew = !item.is_read;
    const timeAgo = formatDateTime(item.created_at);

    return `
    <article class="notification-card" style="${isNew ? 'border-left: 3px solid ' + color + '; background: linear-gradient(135deg, #f8f6ff 0%, #ffffff 100%);' : ''} padding: 0; overflow: hidden;">
      <div style="display: flex; align-items: flex-start; gap: 16px; padding: 18px 20px;">
        <div style="flex-shrink: 0; width: 44px; height: 44px; border-radius: 12px; background: ${isNew ? color + '15' : '#f5f2ff'}; display: grid; place-items: center;">
          <span class="material-symbols-outlined" style="font-size: 22px; color: ${color};">${icon}</span>
        </div>
        <div style="flex: 1; min-width: 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 4px;">
            <h3 style="margin: 0; font-size: 15px; font-weight: 600; color: #1b1b25; line-height: 1.4;">${escapeHtml(item.title)}</h3>
            ${isNew ? `<span style="flex-shrink: 0; width: 8px; height: 8px; border-radius: 50%; background: ${color}; margin-top: 6px;"></span>` : ''}
          </div>
          <p style="margin: 0 0 8px; color: #5d576c; font-size: 14px; line-height: 1.5;">${escapeHtml(item.body)}</p>
          <span style="font-size: 12px; color: #a09ab8; display: flex; align-items: center; gap: 4px;">
            <span class="material-symbols-outlined" style="font-size: 14px;">schedule</span>
            ${escapeHtml(timeAgo)}
          </span>
        </div>
      </div>
      <div style="display: flex; gap: 8px; padding: 0 20px 14px 80px;">
        ${item.action_url ? `<a class="btn btn-primary" href="${escapeHtml(item.action_url)}" style="padding: 6px 14px; font-size: 13px;">Ouvrir</a>` : ''}
        ${isNew ? `<button class="btn btn-secondary" type="button" data-read-notification="${encodeURIComponent(item.id)}" style="padding: 6px 14px; font-size: 13px;">Marquer comme lu</button>` : ''}
      </div>
    </article>`;
  }).join('');
}

function openModal(id) {
  qs(`#${id}`)?.classList.add('is-open');
}

function closeModal(modal) {
  modal?.classList.remove('is-open');
}

function initModals() {
  qsa('[data-open-modal]').forEach((button) => {
    button.addEventListener('click', () => openModal(button.dataset.openModal));
  });

  qsa('[data-modal]').forEach((modal) => {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeModal(modal);
    });
  });

  qsa('[data-close-modal]').forEach((button) => {
    button.addEventListener('click', () => {
      const modal = button.closest('[data-modal]');
      if (modal) closeModal(modal);
    });
  });
}

async function hydrateSidebarName() {
  try {
    const profile = await getCurrentProfile();
    const node = qs('[data-student-profile-inline]');
    if (node && profile) node.textContent = profile.full_name;
  } catch (_err) { }
}

async function bindSaveButtons() {
  qsa('[data-save-listing]').forEach((button) => {
    button.addEventListener('click', async () => {
      const listingId = button.dataset.saveListing;
      const listingType = button.dataset.listingType;
      try {
        await saveStudentListing({
          listingType,
          offerId: listingType === 'offer' ? listingId : null,
          minuteJobId: listingType === 'minute_job' ? listingId : null,
        });
        appToast('Ajouté aux favoris', 'success');
      } catch (error) {
        appToast(error.message || 'Impossible de sauvegarder', 'error');
      }
    }, { once: true });
  });
}

async function initDashboard() {
  const mount = qs('#dashboardListings');
  const countNode = qs('#dashboardListingsCount');

  try {
    const { data, count } = await listStudentListings({ pageSize: 3 });
    await renderListings(mount, data);
    if (countNode) countNode.textContent = `${count} annonce${count > 1 ? 's' : ''} active${count > 1 ? 's' : ''}`;

    const applications = await listStudentApplications().catch(() => []);
    const favorites = await listStudentSavedListings().catch(() => []);

    const map = {
      applications: applications.length,
      interviews: applications.filter((item) => item.status?.includes('interview') || (item.interviews || []).length).length,
      accepted: applications.filter((item) => item.status === 'accepted').length,
      favorites: favorites.length,
    };

    Object.entries(map).forEach(([key, value]) => {
      const node = qs(`[data-kpi="${key}"]`);
      if (node) node.textContent = String(value);
    });
  } catch (error) {
    renderEmptyState(mount, 'Impossible de charger les annonces', error.message || 'Réessaie dans un instant.');
    if (countNode) countNode.textContent = '0 annonce active';
  }

  await bindSaveButtons();
}

function syncOfferFilterUi(state) {
  qsa('[data-filter-type]').forEach((button) => {
    button.classList.toggle('is-active', button.dataset.filterType === state.type);
  });

  const keyword = qs('#studentListingSearch');
  const location = qs('#studentListingLocation');
  if (keyword) keyword.value = state.keyword || '';
  if (location) location.value = state.location || '';
}

async function renderOffersFromState(state) {
  const mount = qs('#studentOffersList');
  const countNode = qs('#studentOffersCount');
  const activeNode = qs('#studentOffersActiveFilter');

  syncOfferFilterUi(state);
  writeOfferFilterState(state);

  try {
    const result = await listStudentListings({
      ...translateOfferFilterState(state),
      pageSize: 24,
    });

    await renderListings(mount, result.data);
    if (countNode) {
      countNode.textContent = `${result.count} résultat${result.count > 1 ? 's' : ''} trouvé${result.count > 1 ? 's' : ''}`;
    }
    if (activeNode) {
      const label = state.type === 'all' ? 'Tous les formats' : (state.type === 'job-minute' ? 'Job minute' : labelEmploymentType(state.type));
      activeNode.textContent = label;
    }
  } catch (error) {
    renderEmptyState(mount, 'Impossible de charger les annonces', error.message || 'Réessaie dans un instant.');
    if (countNode) countNode.textContent = 'Chargement impossible';
    if (activeNode) activeNode.textContent = 'Erreur';
  }

  await bindSaveButtons();
}

async function initOffers() {
  const form = qs('#studentListingsFilters');
  const resetButton = qs('#studentListingReset');
  let state = readOfferFilterState();

  await renderOffersFromState(state);

  form?.addEventListener('submit', async (event) => {
    event.preventDefault();
    state = {
      ...state,
      keyword: qs('#studentListingSearch')?.value || '',
      location: qs('#studentListingLocation')?.value || '',
    };
    await renderOffersFromState(state);
  });

  qsa('[data-filter-type]').forEach((button) => {
    button.addEventListener('click', async () => {
      state = {
        ...state,
        type: button.dataset.filterType || 'all',
      };
      await renderOffersFromState(state);
    });
  });

  resetButton?.addEventListener('click', async () => {
    state = { type: 'all', keyword: '', location: '' };
    await renderOffersFromState(state);
  });
}


async function initOfferDetail() {
  const params = new URLSearchParams(window.location.search);
  const listingId = params.get('listing') || params.get('offer');
  const listingType = params.get('type') || 'offer';
  const mount = qs('#offerDetailMount');
  const form = qs('#offerApplyForm');

  if (!listingId) {
    renderEmptyState(mount, 'Annonce introuvable', 'Le lien d’annonce est incomplet ou invalide.');
    if (form) form.remove();
    return;
  }

  try {
    const item = await getStudentListingDetail({ listingId, listingType });
    const owner = getListingOwnerLabel(item);
    const location = getListingLocationLabel(item);
    const compensation = item.rate_or_salary_label || 'Rémunération à confirmer';
    const primaryTag = getListingPrimaryTag(item);
    const details = [
      item.work_mode ? `<div class="mini-stat"><span>Mode</span><strong>${escapeHtml(item.work_mode)}</strong></div>` : '',
      `<div class="mini-stat"><span>Localisation</span><strong>${escapeHtml(item.city || item.country || 'À préciser')}</strong></div>`,
      `<div class="mini-stat"><span>Rémunération</span><strong>${escapeHtml(compensation)}</strong></div>`,
      `<div class="mini-stat"><span>Publication</span><strong>${escapeHtml(formatDate(item.published_at || item.created_at))}</strong></div>`,
    ].filter(Boolean).join('');

    mount.innerHTML = `
      <section class="student-section">
        <div class="card-meta" style="margin-bottom: 14px;">
          <span class="pill">${escapeHtml(labelListingType(item.listing_type))}</span>
          <span class="pill soft">${escapeHtml(primaryTag)}</span>
          <span class="pill soft">${escapeHtml(location)}</span>
        </div>
        <h2 class="card-title" style="font-size: 34px;">${escapeHtml(item.title)}</h2>
        <p class="card-subtitle">${escapeHtml(item.description || item.summary || 'Annonce UNIBOX')}</p>
        <div class="card-meta" style="margin-top: 16px;">
          <span class="pill"><span class="material-symbols-outlined">apartment</span>${escapeHtml(owner)}</span>
          <span class="pill soft">${escapeHtml(compensation)}</span>
          ${item.address_text ? `<span class="pill soft">${escapeHtml(item.address_text)}</span>` : ''}
        </div>
        <div class="mini-stat-grid" style="margin-top: 18px;">${details}</div>
        ${(item.skills || []).length ? `
          <div class="card-meta" style="margin-top: 18px;">
            ${item.skills.map((skill) => `<span class="pill soft">${escapeHtml(skill)}</span>`).join('')}
          </div>
        ` : ''}
        <div class="card-actions">
          <button class="btn btn-secondary" type="button" data-save-listing="${escapeHtml(item.listing_id || item.id)}" data-listing-type="${escapeHtml(item.listing_type)}">
            Sauvegarder
          </button>
          <button class="btn btn-secondary" type="button" data-open-modal="reportOfferModal">Signaler</button>
        </div>
      </section>
    `;

    await bindSaveButtons();
  } catch (error) {
    renderEmptyState(mount, 'Annonce indisponible', error.message || 'Impossible de charger cette annonce.');
    if (form) form.remove();
    return;
  }

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const button = qs('#offerApplySubmit');
    const cvFile = qs('#offerApplyCv')?.files?.[0] || null;
    const messageBody = qs('#offerApplyMessage')?.value || '';

    try {
      setLoading(button, true, 'Envoi...');
      const application = await applyStudentToListing({
        listingType,
        listingId,
        messageBody,
        cvFile,
      });
      appToast('Candidature envoyée sur UNIBOX.', 'success');
      const successLink = qs('#applySuccessLink');
      if (successLink) {
        successLink.href = `/student/etd-candidature-detail.html?application=${encodeURIComponent(application.id)}`;
      }
      openModal('applySuccessModal');
      form.reset();
    } catch (error) {
      appToast(error.message || 'Impossible d’envoyer la candidature.', 'error');
    } finally {
      setLoading(button, false);
    }
  });

  qs('#reportOfferSend')?.addEventListener('click', async () => {
    const reasonCode = qs('#reportOfferReason')?.value || '';
    const description = qs('#reportOfferDescription')?.value?.trim() || '';
    const button = qs('#reportOfferSend');
    try {
      setLoading(button, true, 'Envoi...');
      await createReport({
        targetType: listingType,
        targetId: listingId,
        reasonCode,
        description,
      });
      appToast('Signalement envoyé à l’admin UNIBOX.', 'success');
      closeModal(qs('#reportOfferModal'));
      qs('#reportOfferDescription').value = '';
    } catch (error) {
      appToast(error.message || 'Impossible d’envoyer le signalement.', 'error');
    } finally {
      setLoading(button, false);
    }
  });
}


async function initApplications() {
  const mount = qs('#applicationsList');
  const countNode = qs('#studentApplicationsCount');
  if (!mount) return;

  let filterKey = 'all';
  let applications = [];

  try {
    applications = await listStudentApplications();
  } catch (error) {
    renderEmptyState(mount, 'Impossible de charger tes candidatures', error.message || 'Réessaie dans un instant.');
    if (countNode) countNode.textContent = 'Chargement impossible';
    return;
  }

  const refresh = () => {
    renderApplications(mount, applications, filterKey);
    const visible = applications.filter((item) => matchStudentApplicationFilter(item, filterKey));
    if (countNode) {
      countNode.textContent = `${visible.length} candidature${visible.length > 1 ? 's' : ''}`;
    }
    qsa('[data-withdraw-application]').forEach((button) => {
      button.addEventListener('click', async () => {
        const id = button.dataset.withdrawApplication;
        try {
          await withdrawStudentApplication(id);
          applications = applications.map((item) => item.id === id ? { ...item, status: 'withdrawn' } : item);
          refresh();
          appToast('Candidature retirée', 'success');
        } catch (error) {
          appToast(error.message || 'Impossible de retirer la candidature', 'error');
        }
      });
    });
  };

  qsa('[data-app-status-filter]').forEach((button) => {
    button.addEventListener('click', () => {
      filterKey = button.dataset.appStatusFilter || 'all';
      qsa('[data-app-status-filter]').forEach((item) => item.classList.toggle('is-active', item === button));
      refresh();
    });
  });

  if (!applications.length) {
    renderEmptyState(mount, 'Aucune candidature pour le moment', 'Tes candidatures apparaîtront ici dès que tu postuleras à une annonce UNIBOX.');
    if (countNode) countNode.textContent = '0 candidature';
    return;
  }

  refresh();
}


async function initApplicationDetail() {
  const params = new URLSearchParams(window.location.search);
  const applicationId = params.get('application');
  const mount = qs('#studentApplicationDetailMount');

  if (!applicationId) {
    renderEmptyState(mount, 'Candidature introuvable', 'Le lien de suivi est invalide ou incomplet.');
    return;
  }

  let application;
  try {
    application = await getStudentApplicationDetail(applicationId);
  } catch (error) {
    renderEmptyState(mount, 'Impossible de charger la candidature', error.message || 'Réessaie dans un instant.');
    return;
  }

  const title = getStudentListingTitleFromApplication(application);
  const location = [application.offers?.city || application.minute_jobs?.city, application.offers?.country || application.minute_jobs?.country].filter(Boolean).join(', ') || 'Flexible';
  const statusLabel = getStudentStatusLabel(application.status);
  const interviews = application.interviews || [];
  const nextInterview = interviews[0] || null;

  const statusClass = application.status === 'examination' ? 'examination' : (application.status === 'accepted' ? 'accepted' : (application.status === 'rejected' ? 'rejected' : (application.status === 'withdrawn' ? 'withdrawn' : 'pending')));
  const statusIcon = APPLICATION_STATUS_ICONS[application.status] || 'schedule';
  const docCount = (application.application_documents || []).length;

  mount.innerHTML = `
    <div class="dash-card" style="padding:32px;min-height:500px;">
      <!-- Header -->
      <div style="display:flex;align-items:flex-start;gap:18px;padding:0 0 20px;border-bottom:1px solid #ede9f8;">
        <div style="width:56px;height:56px;border-radius:14px;background:rgba(107,56,212,0.12);color:var(--primary);display:grid;place-items:center;flex-shrink:0;">
          <span class="material-symbols-outlined" style="font-size:28px;">work</span>
        </div>
        <div style="flex:1;min-width:0;">
          <h4 style="margin:0 0 4px;font-size:18px;font-weight:700;color:#1b1b25;">${escapeHtml(title)}</h4>
          <p style="margin:0;font-size:13px;color:#5d576c;">${escapeHtml(location)}</p>
          <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:10px;">
            <span class="application-card-status ${statusClass}">
              <span class="material-symbols-outlined" style="font-size:14px;">${statusIcon}</span>
              ${escapeHtml(statusLabel)}
            </span>
            <span class="pill soft">Soumis le ${escapeHtml(formatDateTime(application.submitted_at))}</span>
            ${docCount ? `<span class="pill soft">${docCount} document${docCount > 1 ? 's' : ''}</span>` : ''}
          </div>
        </div>
      </div>

      <!-- Message -->
      ${application.message_body ? `
      <div style="padding:20px 0;border-bottom:1px solid #ede9f8;">
        <p style="margin:0;font-size:14px;color:#5d576c;font-style:italic;border-left:3px solid #6b38d4;padding-left:12px;line-height:1.5;">${escapeHtml(application.message_body)}</p>
      </div>` : ''}

      <!-- Entretien -->
      ${nextInterview ? `
      <div style="padding:20px 0;border-bottom:1px solid #ede9f8;">
        <p style="margin:0 0 6px;font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Prochain entretien</p>
        <div style="display:flex;align-items:center;gap:12px;">
          <div style="width:40px;height:40px;border-radius:10px;background:#fef3c7;color:#d97706;display:grid;place-items:center;">
            <span class="material-symbols-outlined" style="font-size:20px;">event</span>
          </div>
          <div>
            <div style="font-size:14px;font-weight:600;color:#1b1b25;">${escapeHtml(formatDateTime(nextInterview.scheduled_at))}</div>
            <div style="font-size:13px;color:#5d576c;">${escapeHtml(nextInterview.meeting_url || nextInterview.location_label || 'Lieu à confirmer')}</div>
          </div>
        </div>
      </div>` : ''}

      <!-- Documents & Historique -->
      <div style="display:flex;flex-direction:column;gap:24px;padding:20px 0;border-bottom:1px solid #ede9f8;">
        <div>
          <h4 style="margin:0 0 14px;font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Documents soumis</h4>
          ${renderApplicationDocuments(application.application_documents || [])}
        </div>
        <div>
          <h4 style="margin:0 0 14px;font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Historique des statuts</h4>
          ${renderApplicationTimeline(application.application_status_events || [])}
        </div>
      </div>

      <!-- Actions rapides -->
      <div style="padding-top:20px;display:flex;flex-wrap:wrap;gap:10px;">
        <button type="button" class="btn btn-primary" id="applicationConfirmInterview" style="flex:1;min-width:140px;justify-content:center;">
          <span class="material-symbols-outlined" style="font-size:16px;">event_available</span>
          ${nextInterview ? 'Confirmer ma présence' : 'Aucun entretien'}
        </button>
        <button type="button" class="btn btn-secondary" data-open-modal="rescheduleModal" style="flex:1;min-width:140px;justify-content:center;">
          <span class="material-symbols-outlined" style="font-size:16px;">schedule_send</span>
          Replanifier
        </button>
        <button type="button" class="btn btn-secondary" id="applicationOpenMessage" style="flex:1;min-width:140px;justify-content:center;">
          <span class="material-symbols-outlined" style="font-size:16px;">chat</span>
          Conversation
        </button>
        ${['accepted', 'rejected', 'withdrawn', 'cancelled'].includes(application.status) ? '' : `
        <button type="button" class="btn btn-secondary" id="applicationWithdraw" style="flex:1;min-width:140px;justify-content:center;color:#dc2626;border-color:#fca5a5;">
          <span class="material-symbols-outlined" style="font-size:16px;">cancel</span>
          Retirer
        </button>`}
      </div>
    </div>
  `;

  initModals();

  qs('#applicationConfirmInterview')?.addEventListener('click', () => {
    if (!nextInterview) {
      appToast('Aucun entretien à confirmer pour le moment.', 'info');
      return;
    }
    appToast('Présence confirmée côté étudiant.', 'success');
  });

  qs('#applicationRescheduleSend')?.addEventListener('click', () => {
    appToast('Demande de replanification envoyée', 'success');
    closeModal(qs('#rescheduleModal'));
  });

  qs('#applicationWithdraw')?.addEventListener('click', async () => {
    try {
      await withdrawStudentApplication(applicationId);
      appToast('Candidature retirée', 'success');
      openModal('withdrawSuccessModal');
    } catch (error) {
      appToast(error.message || 'Impossible de retirer la candidature.', 'error');
    }
  });

  qs('#applicationOpenMessage')?.addEventListener('click', async () => {
    try {
      const conversation = await getOrCreateStudentApplicationConversation(applicationId);
      window.location.href = `/student/etd-messagerie.html?application=${encodeURIComponent(applicationId)}&conversation=${encodeURIComponent(conversation.id)}`;
    } catch (error) {
      appToast(error.message || 'Impossible d’ouvrir la conversation.', 'error');
    }
  });
}

async function initFavorites() {
  const mount = qs('#favoritesList');
  if (!mount) return;
  const saved = await listStudentSavedListings().catch(() => []);

  if (!saved.length) {
    renderEmptyState(mount, 'Aucun favori pour le moment', 'Sauvegarde une annonce pour la retrouver plus vite dans ton espace étudiant.');
    return;
  }

  // Dédoublonner par ID unique
  const uniqueSaved = saved.filter((item, index, self) => 
    index === self.findIndex((t) => t.id === item.id)
  );

  mount.innerHTML = uniqueSaved.map((row) => {
    const isOffer = !!row.offers;
    const title = row.offers?.title || row.minute_jobs?.title || 'Favori UNIBOX';
    const city = row.offers?.city || row.minute_jobs?.city || 'Flexible';
    const company = row.offers?.companies?.name || row.minute_jobs?.profiles?.full_name || 'UNIBOX';
    const listingId = row.offers?.id || row.minute_jobs?.id;
    const listingType = isOffer ? 'offer' : 'minute_job';
    const typeLabel = isOffer ? 'Offre' : 'Job minute';
    const typeColor = isOffer ? '#6b38d4' : '#d97706';
    const typeBg = isOffer ? 'rgba(107,56,212,0.12)' : 'rgba(245,158,11,0.12)';

    return `
      <div style="display:flex;align-items:center;gap:16px;padding:18px 20px;background:#fff;border:1px solid #ede9f8;border-radius:12px;margin-bottom:12px;transition:all .2s ease;" onmouseover="this.style.boxShadow='0 4px 12px rgba(107,56,212,0.08)'" onmouseout="this.style.boxShadow='none'">
        <div style="width:48px;height:48px;border-radius:12px;background:${typeBg};color:${typeColor};display:grid;place-items:center;flex-shrink:0;">
          <span class="material-symbols-outlined" style="font-size:24px;">${isOffer ? 'work' : 'timer'}</span>
        </div>
        <div style="flex:1;min-width:0;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
            <span style="font-size:11px;font-weight:700;padding:2px 8px;background:${typeBg};color:${typeColor};border-radius:4px;">${typeLabel}</span>
          </div>
          <h4 style="margin:0 0 4px;font-size:15px;font-weight:700;color:#1b1b25;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(title)}</h4>
          <div style="font-size:13px;color:#5d576c;display:flex;align-items:center;gap:6px;">
            <span class="material-symbols-outlined" style="font-size:14px;">business</span>
            ${escapeHtml(company)}
            <span style="color:#ddd6ea;">|</span>
            <span class="material-symbols-outlined" style="font-size:14px;">location_on</span>
            ${escapeHtml(city)}
          </div>
        </div>
        <div style="display:flex;gap:8px;flex-shrink:0;">
          <a href="/student/etd-offre-detail.html?listing=${encodeURIComponent(listingId)}&type=${encodeURIComponent(listingType)}" class="btn btn-primary" style="padding:8px 16px;font-size:13px;">
            <span class="material-symbols-outlined" style="font-size:16px;">visibility</span>
            Voir
          </a>
          <button type="button" class="btn btn-secondary" data-remove-favorite="${encodeURIComponent(row.id)}" style="padding:8px 12px;color:#dc2626;border-color:#fca5a5;">
            <span class="material-symbols-outlined" style="font-size:16px;">close</span>
          </button>
        </div>
      </div>
    `;
  }).join('');

  qsa('[data-remove-favorite]').forEach((button) => {
    button.addEventListener('click', () => {
      button.closest('[style*="border-radius"]')?.remove();
      appToast('Favori retiré', 'success');
    });
  });
}

function initInterviewCalendar(interviewRows) {
  const monthLabel = qs('#calendarMonthLabel');
  const grid = qs('#interviewCalendarGrid');
  const upcomingMount = qs('#studentUpcomingInterviews');
  const detailModal = qs('#interviewDetailModal');
  const detailTitle = qs('#interviewDetailTitle');
  const detailBody = qs('#interviewDetailBody');

  let currentDate = new Date();
  let currentView = 'month';

  const MONTH_NAMES = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];

  function getInterviewKey(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function getEventsForDate(date) {
    const key = getInterviewKey(date);
    return interviewRows.filter(({ interview }) => {
      if (!interview.scheduled_at) return false;
      const d = new Date(interview.scheduled_at);
      return getInterviewKey(d) === key;
    });
  }

  function renderSidebar() {
    const now = new Date();
    const upcoming = interviewRows
      .filter(({ interview }) => interview.scheduled_at && new Date(interview.scheduled_at) >= now)
      .sort((a, b) => new Date(a.interview.scheduled_at) - new Date(b.interview.scheduled_at))
      .slice(0, 5);

    if (!upcoming.length) {
      upcomingMount.innerHTML = '<p style="margin:0;font-size:13px;color:#8b85a0;font-style:italic;">Aucun entretien à venir.</p>';
      return;
    }

    upcomingMount.innerHTML = upcoming.map(({ application, interview }) => {
      const title = getStudentListingTitleFromApplication(application);
      const company = getApplicationCompanyName(application);
      const when = formatDateTime(interview.scheduled_at);
      const status = interview.status === 'confirmed' ? 'confirmed' : 'proposed';
      const statusLabel = interview.status === 'confirmed' ? 'Confirmé' : 'Proposé';
      const statusColor = interview.status === 'confirmed' ? '#059669' : '#d97706';
      const bg = interview.status === 'confirmed' ? '#d1fae5' : '#fef3c7';
      return `
        <div class="sidebar-event-item" data-interview-id="${escapeHtml(interview.id || '')}">
          <div class="sidebar-event-dot" style="background:${statusColor};"></div>
          <div class="sidebar-event-content">
            <div class="sidebar-event-title">${escapeHtml(title)}</div>
            <div class="sidebar-event-meta">${escapeHtml(company)} · ${escapeHtml(when)}</div>
            <span class="sidebar-event-status" style="background:${bg};color:${statusColor};">${escapeHtml(statusLabel)}</span>
          </div>
        </div>
      `;
    }).join('');
  }

  function renderMonth() {
    if (!monthLabel || !grid) return;
    const y = currentDate.getFullYear();
    const m = currentDate.getMonth();
    monthLabel.textContent = `${MONTH_NAMES[m]} ${y}`;

    const firstDay = new Date(y, m, 1);
    const startOffset = firstDay.getDay();
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const daysInPrevMonth = new Date(y, m, 0).getDate();

    const today = new Date();
    const todayKey = getInterviewKey(today);

    let html = '';

    // Previous month padding
    for (let i = startOffset - 1; i >= 0; i--) {
      const d = daysInPrevMonth - i;
      html += `<div class="calendar-cell other-month"><div class="calendar-cell-header"><span class="calendar-cell-number">${d}</span></div></div>`;
    }

    // Current month
    for (let d = 1; d <= daysInMonth; d++) {
      const cellDate = new Date(y, m, d);
      const isToday = getInterviewKey(cellDate) === todayKey;
      const events = getEventsForDate(cellDate);
      const eventsHtml = events.map(({ application, interview }) => {
        const statusClass = interview.status === 'confirmed' ? 'confirmed' : (interview.status === 'cancelled' ? 'cancelled' : 'proposed');
        const title = getStudentListingTitleFromApplication(application);
        const company = getApplicationCompanyName(application);
        return `<div class="calendar-event-badge ${statusClass}" data-interview-id="${escapeHtml(interview.id || '')}"><div style="font-weight:600;">${escapeHtml(title)}</div><div style="font-size:9px;opacity:.85;margin-top:1px;">${escapeHtml(company)}</div></div>`;
      }).join('');
      html += `<div class="calendar-cell ${isToday ? 'today' : ''}"><div class="calendar-cell-header"><span class="calendar-cell-number">${d}</span></div>${eventsHtml}</div>`;
    }

    // Next month padding
    const totalCells = startOffset + daysInMonth;
    const remaining = (7 - (totalCells % 7)) % 7;
    for (let d = 1; d <= remaining; d++) {
      html += `<div class="calendar-cell other-month"><div class="calendar-cell-header"><span class="calendar-cell-number">${d}</span></div></div>`;
    }

    grid.innerHTML = html;
    bindEventClicks();
  }

  function renderWeek() {
    if (!monthLabel || !grid) return;
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    const opts = { day: 'numeric', month: 'short' };
    monthLabel.textContent = `${startOfWeek.toLocaleDateString('fr-FR', opts)} – ${endOfWeek.toLocaleDateString('fr-FR', opts)} ${currentDate.getFullYear()}`;

    grid.classList.add('calendar-week-view');
    grid.style.gridTemplateColumns = 'repeat(7, 1fr)';

    let html = '';
    for (let i = 0; i < 7; i++) {
      const cellDate = new Date(startOfWeek);
      cellDate.setDate(startOfWeek.getDate() + i);
      const isToday = getInterviewKey(cellDate) === getInterviewKey(new Date());
      const events = getEventsForDate(cellDate);
      const dayName = cellDate.toLocaleDateString('fr-FR', { weekday: 'short' });
      const eventsHtml = events.map(({ application, interview }) => {
        const statusClass = interview.status === 'confirmed' ? 'confirmed' : (interview.status === 'cancelled' ? 'cancelled' : 'proposed');
        const title = getStudentListingTitleFromApplication(application);
        const company = getApplicationCompanyName(application);
        const time = interview.scheduled_at ? new Date(interview.scheduled_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '';
        return `<div class="calendar-event-badge ${statusClass}" data-interview-id="${escapeHtml(interview.id || '')}"><strong>${time}</strong> <span style="font-weight:600;">${escapeHtml(title)}</span><div style="font-size:9px;opacity:.85;margin-top:1px;">${escapeHtml(company)}</div></div>`;
      }).join('');
      html += `<div class="calendar-cell ${isToday ? 'today' : ''}"><div class="calendar-cell-header"><span class="calendar-cell-number">${dayName} ${cellDate.getDate()}</span></div>${eventsHtml}</div>`;
    }
    grid.innerHTML = html;
    bindEventClicks();
  }

  function renderDay() {
    if (!monthLabel || !grid) return;
    const opts = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
    monthLabel.textContent = currentDate.toLocaleDateString('fr-FR', opts);
    grid.style.gridTemplateColumns = '1fr';

    const events = getEventsForDate(currentDate);
    if (!events.length) {
      grid.innerHTML = '<div class="calendar-cell"><p style="margin:0;font-size:14px;color:#8b85a0;padding:20px 0;text-align:center;">Aucun entretien ce jour.</p></div>';
      return;
    }
    grid.innerHTML = events.map(({ application, interview }) => {
      const statusClass = interview.status === 'confirmed' ? 'confirmed' : (interview.status === 'cancelled' ? 'cancelled' : 'proposed');
      const title = getStudentListingTitleFromApplication(application);
      const company = getApplicationCompanyName(application);
      const time = interview.scheduled_at ? new Date(interview.scheduled_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '';
      const place = interview.meeting_url || interview.location_label || 'Lieu à confirmer';
      return `
        <div class="calendar-cell">
          <div class="calendar-event-badge ${statusClass}" data-interview-id="${escapeHtml(interview.id || '')}" style="padding:10px 14px;font-size:13px;">
            <div style="font-weight:700;margin-bottom:2px;">${escapeHtml(title)}</div>
            <div style="font-size:11px;font-weight:400;opacity:.9;margin-bottom:2px;">${escapeHtml(company)}</div>
            <div style="font-size:11px;font-weight:400;opacity:.75;">${time} · ${escapeHtml(place)}</div>
          </div>
        </div>
      `;
    }).join('');
    bindEventClicks();
  }

  function render() {
    if (currentView === 'month') renderMonth();
    else if (currentView === 'week') renderWeek();
    else renderDay();
  }

  function bindEventClicks() {
    qsa('.calendar-event-badge').forEach((badge) => {
      badge.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = badge.dataset.interviewId;
        const row = interviewRows.find((r) => r.interview.id === id);
        if (!row) return;
        const { application, interview } = row;
        const title = getStudentListingTitleFromApplication(application);
        const company = getApplicationCompanyName(application);
        const when = formatDateTime(interview.scheduled_at);
        const place = interview.meeting_url || interview.location_label || 'Lieu à confirmer';
        const statusLabel = interview.status === 'confirmed' ? 'Confirmé' : 'Proposé';
        const statusColor = interview.status === 'confirmed' ? '#059669' : '#d97706';
        const statusBg = interview.status === 'confirmed' ? '#d1fae5' : '#fef3c7';

        if (detailTitle) detailTitle.textContent = title;
        if (detailBody) {
          detailBody.innerHTML = `
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
              <div style="width:48px;height:48px;border-radius:10px;background:rgba(107,56,212,0.1);color:#6b38d4;display:grid;place-items:center;">
                <span class="material-symbols-outlined" style="font-size:24px;">event</span>
              </div>
              <div>
                <div style="font-size:13px;font-weight:600;color:#6b38d4;margin-bottom:2px;">${escapeHtml(company)}</div>
                <div style="font-size:14px;font-weight:600;color:#1b1b25;">${escapeHtml(when)}</div>
                <div style="font-size:13px;color:#5d576c;margin-top:2px;">${escapeHtml(place)}</div>
              </div>
            </div>
            <span class="pill" style="background:${statusBg};color:${statusColor};font-weight:600;border:none;">${escapeHtml(statusLabel)}</span>
            <div style="margin-top:16px;display:flex;gap:10px;flex-wrap:wrap;">
              <a href="/student/etd-candidature-detail.html?application=${encodeURIComponent(application.id)}" class="btn btn-primary" style="flex:1;justify-content:center;min-width:140px;"><span class="material-symbols-outlined">visibility</span>Voir candidature</a>
              <button type="button" class="btn btn-secondary" data-open-reschedule-from-detail style="flex:1;justify-content:center;min-width:140px;"><span class="material-symbols-outlined">event_repeat</span>Replanifier</button>
            </div>
          `;
        }
        if (detailModal) openModal('interviewDetailModal');

        qs('[data-open-reschedule-from-detail]')?.addEventListener('click', () => {
          closeModal(qs('#interviewDetailModal'));
          openModal('interviewRescheduleModal');
        });
      });
    });
  }

  // Nav events
  qs('#calendarPrev')?.addEventListener('click', () => {
    if (currentView === 'month') currentDate.setMonth(currentDate.getMonth() - 1);
    else if (currentView === 'week') currentDate.setDate(currentDate.getDate() - 7);
    else currentDate.setDate(currentDate.getDate() - 1);
    render();
  });
  qs('#calendarNext')?.addEventListener('click', () => {
    if (currentView === 'month') currentDate.setMonth(currentDate.getMonth() + 1);
    else if (currentView === 'week') currentDate.setDate(currentDate.getDate() + 7);
    else currentDate.setDate(currentDate.getDate() + 1);
    render();
  });
  qs('#calendarToday')?.addEventListener('click', () => {
    currentDate = new Date();
    render();
  });
  qsa('[data-cal-view]').forEach((btn) => {
    btn.addEventListener('click', () => {
      qsa('[data-cal-view]').forEach((b) => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      currentView = btn.dataset.calView;
      if (currentView === 'month') {
        grid.style.gridTemplateColumns = 'repeat(7, 1fr)';
        grid.classList.remove('calendar-week-view');
      }
      render();
    });
  });

  renderSidebar();
  render();
}

async function initInterviews() {
  const grid = qs('#interviewCalendarGrid');
  if (!grid) return;

  let applications = [];
  try {
    applications = await listStudentApplications();
  } catch (error) {
    const upcoming = qs('#studentUpcomingInterviews');
    if (upcoming) renderEmptyState(upcoming, 'Impossible de charger tes entretiens', error.message || 'Réessaie dans un instant.');
    return;
  }

  const interviewRows = applications
    .flatMap((application) => (application.interviews || []).map((interview) => ({ application, interview })))
    .sort((a, b) => new Date(a.interview.scheduled_at || 0) - new Date(b.interview.scheduled_at || 0));

  // DEBUG: voir si les noms d'entreprise arrivent
  if (applications.length > 0) {
    console.log('[DEBUG] Première application:', {
      offer_company_name: applications[0].offer_company_name,
      owner_display_name: applications[0].owner_display_name,
      offer_title: applications[0].offer_title,
      minute_job_title: applications[0].minute_job_title,
      company_name: applications[0].company_name,
    });
  }

  if (!interviewRows.length) {
    const upcoming = qs('#studentUpcomingInterviews');
    if (upcoming) upcoming.innerHTML = '<p style="margin:0;font-size:13px;color:#8b85a0;font-style:italic;">Aucun entretien planifié pour le moment. Dès qu\'un recruteur t\'invite, ton entretien apparaîtra ici.</p>';
  }

  initInterviewCalendar(interviewRows);

  // Checklist from detail modal
  qs('[data-open-checklist-modal]')?.addEventListener('click', () => {
    closeModal(qs('#interviewDetailModal'));
    openModal('interviewChecklistModal');
  });

  qs('#interviewRescheduleSend')?.addEventListener('click', () => {
    appToast('Demande envoyée', 'success');
    closeModal(qs('#interviewRescheduleModal'));
  });
}

async function initMessages() {
  const list = qs('#messagesConversationList');
  const thread = qs('#messagesThread');
  const form = qs('#messageSendForm');
  const input = qs('#messageInput');
  const params = new URLSearchParams(window.location.search);
  const applicationId = params.get('application');
  const requestedConversationId = params.get('conversation');

  const currentProfile = await getCurrentProfile().catch(() => null);
  let selectedConversationId = null;

  async function fetchInbox() {
    const data = await listStudentMessages().catch(() => []);
    if (!applicationId) return data;

    const ensured = await getOrCreateStudentApplicationConversation(applicationId);
    if (ensured?.id && !data.some((row) => row.conversation_id === ensured.id)) {
      return await listStudentMessages();
    }
    return data;
  }

  let conversations = [];
  try {
    conversations = await fetchInbox();
  } catch (error) {
    list.innerHTML = `<div class="msg-loading">Messagerie indisponible</div>`;
    if (thread) thread.innerHTML = `<div class="msg-empty"><span class="material-symbols-outlined" style="font-size:48px;color:#555770;">chat</span><p>La conversation UNIBOX sera visible ici dès qu'elle sera disponible.</p></div>`;
    return;
  }

  if (!conversations.length) {
    list.innerHTML = `<div class="msg-loading">Aucune conversation pour le moment</div>`;
    if (thread) thread.innerHTML = `<div class="msg-empty"><span class="material-symbols-outlined" style="font-size:48px;color:#555770;">chat</span><p>Sélectionne une conversation pour commencer</p></div>`;
    return;
  }

  // Tabs and search
  let activeTab = 'all';
  let searchQuery = '';
  const searchInput = qs('.msg-search input');
  const tabs = qsa('.msg-tab');

  function updateTabs() {
    tabs.forEach(tab => {
      const isActive = (activeTab === 'all' && tab.textContent.toLowerCase().includes('tous')) ||
        (activeTab === 'unread' && tab.textContent.toLowerCase().includes('non lus'));
      tab.classList.toggle('active', isActive);
    });
  }

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      activeTab = tab.textContent.toLowerCase().includes('tous') ? 'all' : 'unread';
      updateTabs();
      renderConversationList(selectedConversationId);
    });
  });

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.toLowerCase().trim();
      renderConversationList(selectedConversationId);
    });
  }

  async function renderConversationList(activeConversationId) {
    // Fetch participants for all conversations
    const conversationIds = conversations.map(c => c.conversation_id).filter(Boolean);
    let allParticipants = [];
    try {
      const { data } = await supabase
        .from('conversation_participants')
        .select(`conversation_id, user_id, profiles:user_id(id, full_name, email, avatar_path)`)
        .in('conversation_id', conversationIds);
      allParticipants = data || [];
    } catch (e) {
      console.warn('Could not fetch participants:', e);
    }

    const participantsByConv = new Map();
    for (const p of allParticipants) {
      const bucket = participantsByConv.get(p.conversation_id) || [];
      bucket.push(p);
      participantsByConv.set(p.conversation_id, bucket);
    }

    // Filter conversations
    let filteredConversations = conversations;

    if (activeTab === 'unread') {
      filteredConversations = filteredConversations.filter(row => {
        const convParticipants = participantsByConv.get(row.conversation_id) || [];
        const myParticipant = convParticipants.find(p => p.user_id === currentProfile?.id);
        const lastReadAt = myParticipant?.last_read_at;
        const lastMessageAt = row.last_message_at || row.sent_at;
        return lastReadAt && lastMessageAt && new Date(lastMessageAt) > new Date(lastReadAt);
      });
    }

    if (searchQuery) {
      filteredConversations = filteredConversations.filter(row => {
        const title = (row.title || '').toLowerCase();
        const subtitle = (row.subtitle || '').toLowerCase();
        return title.includes(searchQuery) || subtitle.includes(searchQuery);
      });
    }

    if (!filteredConversations.length) {
      list.innerHTML = `<div class="msg-loading">${activeTab === 'unread' ? 'Aucune conversation non lue' : 'Aucun résultat pour "' + escapeHtml(searchQuery) + '"'}</div>`;
      qsa('[data-conversation-id]').forEach((button) => {
        button.addEventListener('click', () => loadThread(button.dataset.conversationId));
      });
      return;
    }

    list.innerHTML = filteredConversations.map((row) => {
      const isActive = row.conversation_id === activeConversationId;
      const title = row.title || 'Conversation';
      const subtitle = (row.subtitle || 'Aucun message').replace(/^Avec\s*/i, '');

      const convParticipants = participantsByConv.get(row.conversation_id) || [];
      const otherParticipants = convParticipants.filter(p => p.user_id !== currentProfile?.id);
      const firstOther = otherParticipants[0];
      const avatarPath = firstOther?.profiles?.avatar_path || null;
      const avatarDataAttr = avatarPath ? `data-avatar-path="${escapeHtml(avatarPath)}"` : '';

      const time = row.last_message_at
        ? new Date(row.last_message_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
        : '';

      return `
        <button type="button" class="msg-conv-item ${isActive ? 'active' : ''}" data-conversation-id="${escapeHtml(row.conversation_id)}">
          <div class="msg-conv-avatar msg-lazy-avatar" ${avatarDataAttr}></div>
          <div class="msg-conv-info">
            <p class="msg-conv-name">${escapeHtml(subtitle)}</p>
            <p class="msg-conv-snippet">${escapeHtml(title)}</p>
          </div>
          <div class="msg-conv-meta">
            ${time ? `<span class="msg-conv-time">${escapeHtml(time)}</span>` : ''}
          </div>
        </button>
      `;
    }).join('');

    qsa('[data-conversation-id]').forEach((button) => {
      button.addEventListener('click', () => loadThread(button.dataset.conversationId));
    });

    // Lazy load avatars
    const lazyAvatars = qsa('.msg-lazy-avatar[data-avatar-path]');
    if (lazyAvatars.length) {
      try {
        for (const avatar of lazyAvatars) {
          const path = avatar.dataset.avatarPath;
          if (path) {
            const url = await getSafeAssetUrl('avatars', path);
            avatar.style.backgroundImage = `url('${escapeHtml(url)}')`;
            avatar.style.backgroundSize = 'cover';
            avatar.style.backgroundPosition = 'center';
          }
        }
      } catch (_) { }
    }
  }

  async function loadThread(conversationId) {
    selectedConversationId = conversationId;
    await renderConversationList(conversationId);

    const [messages, participants] = await Promise.all([
      listConversationMessages(conversationId).catch(() => []),
      listStudentConversationParticipants(conversationId).catch(() => []),
    ]);

    const otherParticipants = participants.filter((entry) => entry.user_id !== currentProfile?.id);
    const firstOther = otherParticipants[0];
    const participantNames = otherParticipants
      .map((entry) => entry.profiles?.full_name || entry.profiles?.email)
      .filter(Boolean);
    const participantAvatarPath = firstOther?.profiles?.avatar_path || null;

    const headerName = qs('#chatActiveTitle');
    const headerStatus = qs('#chatActiveStatus');
    const headerAvatar = qs('#chatHeaderAvatar');
    if (participantNames.length) {
      const name = participantNames.join(', ');
      if (headerName) headerName.textContent = name;
      if (headerStatus) headerStatus.textContent = 'En ligne';
      if (headerAvatar && participantAvatarPath) {
        headerAvatar.classList.add('msg-lazy-avatar');
        headerAvatar.setAttribute('data-avatar-path', participantAvatarPath);

        try {
          const url = await getSafeAssetUrl('avatars', participantAvatarPath);
          headerAvatar.style.backgroundImage = `url('${escapeHtml(url)}')`;
          headerAvatar.style.backgroundSize = 'cover';
          headerAvatar.style.backgroundPosition = 'center';
          headerAvatar.textContent = '';
        } catch (_) { }
      } else if (headerAvatar) {
        headerAvatar.textContent = name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
      }
    }

    if (!messages.length) {
      thread.innerHTML = `<div class="msg-empty"><span class="material-symbols-outlined" style="font-size:48px;color:#555770;">chat</span><p>Démarre la conversation avec un premier message.</p></div>`;
      await markStudentConversationRead(conversationId).catch(() => null);
      return;
    }

    thread.innerHTML = messages.map((message) => {
      const isMine = message.sender_user_id === currentProfile?.id;
      const senderName = escapeHtml(message.profiles?.full_name || message.profiles?.email || 'UNIBOX');
      const time = escapeHtml(formatDateTime(message.sent_at));
      return `
        <div class="msg-row ${isMine ? 'me' : ''}">
          <div class="msg-bubble ${isMine ? 'msg-bubble-sent' : 'msg-bubble-received'}">
            <div class="msg-meta"><strong>${senderName}</strong><span>${time}</span></div>
            ${message.body ? `<div>${escapeHtml(message.body)}</div>` : ''}
            ${message.attachment_url ? `<a class="msg-bubble-attachment" href="${escapeHtml(message.attachment_url)}" target="_blank" rel="noopener"><span class="material-symbols-outlined" style="font-size:14px;">description</span> Pièce jointe</a>` : ''}
          </div>
        </div>
      `;
    }).join('');

    thread.scrollTop = thread.scrollHeight;
    await markStudentConversationRead(conversationId).catch(() => null);
  }

  await renderConversationList(null);

  const initialId = requestedConversationId
    || (applicationId ? conversations.find((row) => row.conversations?.application_id === applicationId)?.conversation_id : null)
    || conversations[0]?.conversation_id;

  if (initialId) await loadThread(initialId);

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const value = input?.value.trim();
    if (!value || !selectedConversationId) return;
    try {
      await sendStudentMessage({ conversationId: selectedConversationId, body: value });
      input.value = '';
      await loadThread(selectedConversationId);
      appToast('Message envoyé', 'success');
    } catch (error) {
      appToast(error.message || 'Erreur lors de l\'envoi.', 'error');
    }
  });
}

async function initNotifications() {
  const mount = qs('#notificationsList');
  if (!mount) return;

  const notifications = await listStudentNotifications().catch(() => []);
  if (!notifications.length) {
    mount.innerHTML = `
      <div style="text-align: center; padding: 48px 24px;">
        <span class="material-symbols-outlined" style="font-size: 56px; color: #ddd6ea; margin-bottom: 16px; display: block;">notifications_off</span>
        <h3 style="margin: 0 0 8px; font-size: 18px; font-weight: 600; color: #1b1b25;">Aucune notification</h3>
        <p style="margin: 0; color: #a09ab8; font-size: 14px; line-height: 1.5;">Les mises à jour liées à tes candidatures, entretiens et messages apparaîtront ici.</p>
      </div>
    `;
    return;
  }

  renderNotifications(mount, notifications);

  qsa('[data-read-notification]').forEach((button) => {
    button.addEventListener('click', async () => {
      const id = button.dataset.readNotification;
      try {
        await markStudentNotificationRead(id);
        const card = button.closest('.notification-card');
        if (card) {
          card.style.borderLeft = 'none';
          card.style.background = '';
          const dot = card.querySelector('[style*="border-radius: 50%"]');
          if (dot) dot.remove();
        }
        button.remove();
        appToast('Notification marquée comme lue', 'success');
      } catch (error) {
        appToast(error.message || 'Impossible de mettre la notification à jour.', 'error');
      }
    });
  });

  qs('#notificationsMarkAll')?.addEventListener('click', async () => {
    try {
      await markAllStudentNotificationsRead();
      qsa('[data-read-notification]').forEach((button) => button.remove());
      qsa('#notificationsList .notification-card').forEach((card) => {
        card.style.borderLeft = 'none';
        card.style.background = '';
        const dot = card.querySelector('[style*="border-radius: 50%"]');
        if (dot) dot.remove();
      });
      appToast('Toutes les notifications sont à jour', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible de marquer les notifications comme lues.', 'error');
    }
  });
}

async function initHistory() {
  const mount = qs('#studentHistoryMount');
  if (!mount) return;

  let applications = [];
  try {
    applications = await listStudentApplications();
  } catch (error) {
    renderEmptyState(mount, 'Impossible de charger ton historique', error.message || 'Réessaie dans un instant.');
    return;
  }

  // Afficher toutes les candidatures (offres + jobs minute)
  const items = (applications || [])
    .sort((a, b) => new Date(b.submitted_at || 0) - new Date(a.submitted_at || 0));

  if (!items.length) {
    renderEmptyState(mount, 'Aucune candidature dans ton historique', 'Tes candidatures passées apparaîtront ici.');
    return;
  }

  mount.innerHTML = `
    <div style="position: relative; padding-left: 24px;">
      <div style="position: absolute; left: 11px; top: 8px; bottom: 8px; width: 2px; background: linear-gradient(to bottom, #ddd6ea, #ede9f8); border-radius: 1px;"></div>
      ${items.map((app, index) => {
        const title = getStudentListingTitleFromApplication(app);
        const company = getApplicationCompanyName(app);
        const location = getStudentApplicationLocation(app);
        const s = APP_STATUS_STYLE[app.status] || { label: getStudentStatusLabel(app.status), color: '#6b38d4', bg: 'rgba(107,56,212,0.12)' };
        const when = formatDateTime(app.submitted_at);
        const icon = app.status === 'accepted' || app.status === 'completed' ? 'check_circle' : (app.status === 'rejected' ? 'cancel' : 'schedule');

        return `
          <div style="position: relative; margin-bottom: 20px;">
            <div style="position: absolute; left: -19px; top: 2px; width: 16px; height: 16px; border-radius: 50%; background: ${s.color}; border: 3px solid #fff; box-shadow: 0 0 0 2px ${s.color}33; z-index: 1;"></div>
            <div style="background: #f8f6ff; border-radius: 12px; padding: 18px 20px; border: 1px solid #ede9f8; display: flex; gap: 16px; align-items: flex-start;">
              <div style="width: 42px; height: 42px; border-radius: 10px; background: linear-gradient(135deg, ${s.color}, ${s.color}cc); display: grid; place-items: center; flex-shrink: 0;">
                <span class="material-symbols-outlined" style="font-size: 20px; color: #fff;">${icon}</span>
              </div>
              <div style="flex: 1; min-width: 0;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 4px;">
                  <h4 style="margin: 0; font-size: 15px; font-weight: 600; color: #1b1b25;">${escapeHtml(s.label)} · ${escapeHtml(title)}</h4>
                  <span style="font-size: 11px; color: #a09ab8; white-space: nowrap;">${escapeHtml(when)}</span>
                </div>
                <p style="margin: 0; color: #5d576c; font-size: 13px; line-height: 1.5;">${escapeHtml(company)} · ${escapeHtml(location)}</p>
              </div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

async function initHelp() {
  // Accordion FAQ
  qsa('[data-student-faq]').forEach((button) => {
    button.addEventListener('click', () => {
      const icon = button.querySelector('.icon');
      const content = qs(`#${button.dataset.studentFaq}`);
      if (content && icon) {
        content.classList.toggle('hidden');
        if (content.classList.contains('hidden')) {
          button.classList.remove('active');
          icon.style.transform = 'rotate(0deg)';
        } else {
          button.classList.add('active');
          icon.style.transform = 'rotate(180deg)';
        }
      }
    });
  });

  // Highlight cat-link on click + filter FAQ sections
  function showFaqSection(targetId) {
    qsa('section[id^="faq-"]').forEach((section) => {
      section.style.display = section.id === targetId ? '' : 'none';
    });
  }

  qsa('.cat-link').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      qsa('.cat-link').forEach((l) => l.classList.remove('active'));
      link.classList.add('active');
      const href = link.getAttribute('href');
      if (href) showFaqSection(href.slice(1));
    });
  });

  // Show all sections on load
  qsa('section[id^="faq-"]').forEach((section) => { section.style.display = ''; });

  // Search FAQ
  qs('#faqSearchInput')?.addEventListener('input', (e) => {
    const term = e.target.value.trim().toLowerCase();
    if (!term) {
      const active = qs('.cat-link.active');
      const href = active?.getAttribute('href');
      if (href) showFaqSection(href.slice(1));
      qsa('.faq-item').forEach((item) => { item.style.display = ''; });
      qsa('.faq-section-title').forEach((t) => { t.style.display = ''; });
      return;
    }
    qsa('section[id^="faq-"]').forEach((s) => { s.style.display = ''; });
    qsa('.faq-item').forEach((item) => {
      const text = item.textContent.toLowerCase();
      item.style.display = text.includes(term) ? '' : 'none';
    });
    qsa('.faq-section-title').forEach((title) => {
      const section = title.closest('section');
      if (section) {
        const visible = section.querySelectorAll('.faq-item:not([style*="none"])').length;
        title.style.display = visible > 0 ? '' : 'none';
        section.style.display = visible > 0 ? '' : 'none';
      }
    });
  });

  qs('#helpSupportSend')?.addEventListener('click', () => {
    appToast('Demande envoyée au support', 'success');
    closeModal(qs('#helpSupportModal'));
    qs('#helpSupportSubject').value = '';
    qs('#helpSupportMessage').value = '';
  });
}

async function initProfile() {
  const profile = await getCurrentProfile().catch(() => null);
  const roleProfile = profile ? await getRoleProfile('student', profile.id).catch(() => null) : null;

  if (profile) {
    if (qs('#profileFullName')) qs('#profileFullName').value = profile.full_name || '';
    if (qs('#profileEmail')) qs('#profileEmail').value = profile.email || '';
    if (qs('#profileCity')) qs('#profileCity').value = profile.city || '';

    if (profile.avatar_path) {
      const url = await getSafeAssetUrl(SUPABASE_CONFIG.buckets.avatars, profile.avatar_path);
      if (qs('#profileAvatarPreview')) qs('#profileAvatarPreview').src = url;
    }
  }

  if (roleProfile) {
    if (qs('#profileSchool')) qs('#profileSchool').value = roleProfile.school_name || '';
    if (qs('#profileStudyLevel')) qs('#profileStudyLevel').value = roleProfile.study_level || '';
    if (qs('#profileHeadline')) qs('#profileHeadline').value = roleProfile.headline || '';
    if (qs('#profileBio')) qs('#profileBio').value = roleProfile.bio || '';

    if (roleProfile.cv_path) {
      const url = getPublicAssetUrl(SUPABASE_CONFIG.buckets.studentCvs, roleProfile.cv_path);
      if (qs('#cvPreviewContainer')) qs('#cvPreviewContainer').style.display = 'block';
      if (qs('#cvPreviewLink')) qs('#cvPreviewLink').href = url;
    }
  }

  qs('#studentProfileForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const button = qs('#profileSaveButton');
    try {
      setLoading(button, true, 'Enregistrement...');
      await updateStudentProfile({
        full_name: qs('#profileFullName')?.value.trim(),
        city: qs('#profileCity')?.value.trim(),
        school_name: qs('#profileSchool')?.value.trim(),
        study_level: qs('#profileStudyLevel')?.value.trim(),
        headline: qs('#profileHeadline')?.value.trim(),
        bio: qs('#profileBio')?.value.trim(),
      });
      appToast('Profil mis à jour', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible de mettre à jour le profil', 'error');
    } finally {
      setLoading(button, false);
    }
  });

  qs('#profileAvatarInput')?.addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const path = await uploadAvatar(file);
      await updateStudentProfile({ avatar_path: path });

      const url = await getSafeAssetUrl(SUPABASE_CONFIG.buckets.avatars, path);
      if (qs('#profileAvatarPreview')) qs('#profileAvatarPreview').src = url;

      // Update shell avatars dynamically if present
      document.querySelectorAll('[data-student-user-avatar]').forEach(container => {
        const img = container.querySelector('img');
        if (img) {
          img.src = url;
        } else {
          container.innerHTML = `<img src="${url}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
        }
      });

      appToast('Avatar mis à jour', 'success');
    } catch (error) {
      appToast(error.message || 'Upload avatar impossible', 'error');
    }
  });

  qs('#profileCvInput')?.addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const path = await uploadStudentCv(file);
      await updateStudentProfile({ cv_path: path });

      const url = getPublicAssetUrl(SUPABASE_CONFIG.buckets.studentCvs, path);
      if (qs('#cvPreviewContainer')) qs('#cvPreviewContainer').style.display = 'block';
      if (qs('#cvPreviewLink')) qs('#cvPreviewLink').href = url;

      appToast('CV envoyé', 'success');
    } catch (error) {
      appToast(error.message || 'Upload CV impossible', 'error');
    }
  });
}

async function initPortfolio() {
  const list = qs('#portfolioList');
  const form = qs('#portfolioForm');
  const gridCard = qs('#portfolioGridCard');
  const toggleBtn = qs('#portfolioToggleBtn');
  const items = await listStudentPortfolioItems().catch(() => []);

  const TYPE_LABELS = {
    project: 'Projet académique',
    internship: 'Stage',
    freelance: 'Freelance',
    personal: 'Personnel',
    other: 'Autre',
  };

  let isGridVisible = false;

  function render(itemsToRender) {
    if (!itemsToRender.length) {
      list.innerHTML = `
        <div class="portfolio-empty">
          <div class="portfolio-empty-icon">
            <span class="material-symbols-outlined" style="font-size: 32px;">work</span>
          </div>
          <h4>Aucune expérience enregistrée</h4>
          <p>Ajoute un projet, une réalisation ou une expérience pour enrichir ton profil étudiant.</p>
        </div>
      `;
      return;
    }

    list.innerHTML = itemsToRender.map((item) => {
      const year = item.starts_on
        ? new Date(item.starts_on).getFullYear()
        : (item.created_at ? new Date(item.created_at).getFullYear() : '');
      const org = item.organization_name;
      const typeLabel = TYPE_LABELS[item.item_type] || '';
      const url = item.external_url;
      const metaParts = [org, typeLabel].filter(Boolean);

      return `
      <article class="portfolio-project-card" data-portfolio-id="${item.id}">
        <div class="portfolio-project-header">
          <div class="portfolio-project-header-top">
            <div class="portfolio-project-icon">
              <span class="material-symbols-outlined" style="font-size: 22px;">work</span>
            </div>
          </div>
          <h3 class="portfolio-project-title">${escapeHtml(item.title)}</h3>
          ${metaParts.length ? `<p class="portfolio-project-meta">${escapeHtml(metaParts.join(' · '))}${year ? ` · ${escapeHtml(year)}` : ''}</p>` : ''}
        </div>
        <div class="portfolio-project-body">
          <p class="portfolio-project-desc">${escapeHtml(item.description || 'Aucune description fournie.')}</p>
          <div class="portfolio-project-skills">
            ${(item.skills || []).map((skill) => `<span class="portfolio-skill-tag">${escapeHtml(skill)}</span>`).join('')}
          </div>
          <div class="portfolio-project-actions">
            <button type="button" class="portfolio-project-btn" data-edit-portfolio="${item.id}">
              <span class="material-symbols-outlined" style="font-size:16px;">edit</span>
              Modifier
            </button>
            <button type="button" class="portfolio-project-btn danger" data-delete-portfolio="${item.id}">
              <span class="material-symbols-outlined" style="font-size:16px;">delete</span>
              Supprimer
            </button>
          </div>
        </div>
      </article>
    `;
    }).join('');

    bindProjectActions();
  }

  function bindProjectActions() {
    // Edit
    qsa('[data-edit-portfolio]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.editPortfolio;
        const item = items.find((i) => i.id == id);
        if (!item) return;
        qs('#editPortfolioId').value = item.id;
        qs('#editPortfolioTitle').value = item.title || '';
        qs('#editPortfolioType').value = item.item_type || 'project';
        qs('#editPortfolioOrganization').value = item.organization_name || '';
        qs('#editPortfolioYear').value = item.starts_on ? new Date(item.starts_on).getFullYear() : '';
        qs('#editPortfolioUrl').value = item.external_url || '';
        qs('#editPortfolioDescription').value = item.description || '';
        qs('#editPortfolioSkills').value = (item.skills || []).join(', ');
        openModal('portfolioEditModal');
      });
    });

    // Delete
    qsa('[data-delete-portfolio]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.deletePortfolio;
        if (!confirm('Supprimer cette expérience ?')) return;
        await deleteStudentPortfolioItem(id).catch(() => null);
        const idx = items.findIndex((i) => i.id == id);
        if (idx >= 0) items.splice(idx, 1);
        render(items);
        appToast('Expérience supprimée', 'success');
      });
    });
  }

  // Toggle grid visibility
  toggleBtn?.addEventListener('click', () => {
    isGridVisible = !isGridVisible;
    gridCard.style.display = isGridVisible ? 'block' : 'none';
    toggleBtn.classList.toggle('is-open', isGridVisible);
    toggleBtn.innerHTML = isGridVisible
      ? '<span class="material-symbols-outlined">expand_less</span>Masquer mes projets'
      : '<span class="material-symbols-outlined">expand_more</span>Voir mes projets';
    if (isGridVisible) render(items);
  });

  // Add form
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = qs('#portfolioTitle')?.value.trim();
    const description = qs('#portfolioDescription')?.value.trim();
    const skills = (qs('#portfolioSkills')?.value || '').split(',').map((item) => item.trim()).filter(Boolean);
    const itemType = qs('#portfolioType')?.value || 'project';
    const organization = qs('#portfolioOrganization')?.value.trim();
    const year = qs('#portfolioYear')?.value;
    const externalUrl = qs('#portfolioUrl')?.value.trim();
    if (!title) return;

    const payload = {
      title,
      description,
      skills,
      item_type: itemType,
      organization_name: organization || undefined,
      starts_on: year ? `${year}-01-01` : undefined,
      external_url: externalUrl || undefined,
      sort_order: items.length + 1,
      is_visible: true,
    };
    const result = await createStudentPortfolioItem(payload).catch(() => null);
    if (result?.data?.[0]) {
      items.unshift(result.data[0]);
    } else {
      items.unshift({ ...payload, id: Date.now(), created_at: new Date().toISOString() });
    }
    if (isGridVisible) render(items);
    form.reset();
    appToast('Expérience ajoutée au portfolio', 'success');
  });

  // Edit form
  qs('#portfolioEditForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = qs('#editPortfolioId')?.value;
    if (!id) return;
    const payload = {
      title: qs('#editPortfolioTitle')?.value.trim(),
      description: qs('#editPortfolioDescription')?.value.trim(),
      skills: (qs('#editPortfolioSkills')?.value || '').split(',').map((s) => s.trim()).filter(Boolean),
      item_type: qs('#editPortfolioType')?.value || 'project',
      organization_name: qs('#editPortfolioOrganization')?.value.trim() || undefined,
      starts_on: qs('#editPortfolioYear')?.value ? `${qs('#editPortfolioYear').value}-01-01` : undefined,
      external_url: qs('#editPortfolioUrl')?.value.trim() || undefined,
    };
    await updateStudentPortfolioItem(id, payload).catch(() => null);
    const idx = items.findIndex((i) => i.id == id);
    if (idx >= 0) {
      items[idx] = { ...items[idx], ...payload };
    }
    if (isGridVisible) render(items);
    closeModal(qs('#portfolioEditModal'));
    appToast('Expérience mise à jour', 'success');
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  await mountStudentShell();
  await hydrateSidebarName();
  initModals();

  const page = document.body.dataset.page;
  if (page === 'student-dashboard') await initDashboard();
  if (page === 'student-offers') await initOffers();
  if (page === 'student-offer-detail') await initOfferDetail();
  if (page === 'student-applications') await initApplications();
  if (page === 'student-application-detail') await initApplicationDetail();
  if (page === 'student-favorites') await initFavorites();
  if (page === 'student-interviews') await initInterviews();
  if (page === 'student-messages') await initMessages();
  if (page === 'student-notifications') await initNotifications();
  if (page === 'student-history') await initHistory();
  if (page === 'student-help') await initHelp();
  if (page === 'student-profile') await initProfile();
  if (page === 'student-portfolio') await initPortfolio();
});
