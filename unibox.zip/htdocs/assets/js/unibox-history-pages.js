import { qs, appToast } from '/assets/js/unibox-core.js';
import {
  listStudentApplications,
  getStudentApplicationDetail,
  listStudentNotifications,
} from '/assets/supabase/unibox-student.js';
import {
  listRecruiterOffers,
  listRecruiterApplications,
  getRecruiterCandidateDetail,
  listRecruiterNotifications,
} from '/assets/supabase/unibox-recruiter.js';
import {
  listParticularJobs,
  listParticularApplications,
  getParticularApplicationDetail,
  listParticularNotifications,
} from '/assets/supabase/unibox-particular.js';
import {
  listAdminApplications,
  listAdminReports,
  listAdminModerationCases,
  listAdminNotifications,
  listAdminAuditLogs,
} from '/assets/supabase/unibox-admin.js';

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function formatDateTime(value) {
  if (!value) return 'Date non précisée';
  return new Date(value).toLocaleString('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function applicationStatusLabel(status) {
  switch (status) {
    case 'accepted': return 'Accepté';
    case 'rejected': return 'Refusé';
    case 'withdrawn': return 'Retiré';
    case 'cancelled': return 'Annulé';
    case 'shortlisted': return 'Pré-sélectionné';
    case 'interview_requested': return 'Entretien demandé';
    case 'interview_scheduled': return 'Entretien planifié';
    default: return 'En examination';
  }
}

function notificationLevelLabel(level) {
  switch (level) {
    case 'success': return 'Succès';
    case 'warning': return 'Attention';
    case 'error': return 'Alerte';
    default: return 'Info';
  }
}

function listingTitleFromApplication(item) {
  return item?.offers?.title || item?.minute_jobs?.title || 'Annonce UNIBOX';
}

function renderEmptyState(target, title, body) {
  if (!target) return;
  target.innerHTML = `
    <article class="empty-state">
      <h3>${escapeHtml(title)}</h3>
      <p>${escapeHtml(body)}</p>
    </article>
  `;
}

function renderHistoryItems(target, items) {
  if (!target) return;
  if (!items.length) {
    renderEmptyState(target, 'Historique vide', 'Les actions réelles de la plateforme apparaîtront ici dès qu’elles auront été enregistrées.');
    return;
  }

  target.innerHTML = items.map((item) => `
    <article class="history-card">
      <strong>${escapeHtml(item.title)}</strong>
      <p class="card-subtitle">${escapeHtml(item.subtitle || '')}</p>
      ${item.pills?.length ? `
        <div class="card-meta">
          ${item.pills.map((pill) => `<span class="pill soft">${escapeHtml(pill)}</span>`).join('')}
        </div>
      ` : ''}
      <span class="inline-note">${escapeHtml(formatDateTime(item.date))}</span>
    </article>
  `).join('');
}

function sortHistory(items = []) {
  return [...items].sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
}

function downloadHistory(filename, items) {
  const payload = JSON.stringify(items, null, 2);
  const blob = new Blob([payload], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

async function buildStudentHistory() {
  const applications = await listStudentApplications().catch(() => []);
  const notifications = await listStudentNotifications().catch(() => []);
  const details = await Promise.all(
    (applications || []).slice(0, 24).map((item) => getStudentApplicationDetail(item.id).catch(() => item))
  );

  const items = [];

  details.forEach((detail) => {
    const listingTitle = listingTitleFromApplication(detail);

    (detail.application_status_events || []).forEach((event) => {
      items.push({
        date: event.created_at,
        title: `${applicationStatusLabel(event.to_status || detail.status)} · ${listingTitle}`,
        subtitle: event.note || 'Statut de candidature mis à jour.',
        pills: ['Candidature'],
      });
    });

    (detail.interviews || []).forEach((interview) => {
      const place = interview.location_label || interview.meeting_url || 'Lieu à confirmer';
      items.push({
        date: interview.created_at || interview.scheduled_at,
        title: `Entretien planifié · ${listingTitle}`,
        subtitle: `${formatDateTime(interview.scheduled_at)} · ${place}`,
        pills: ['Entretien'],
      });
    });
  });

  notifications.forEach((notification) => {
    items.push({
      date: notification.created_at,
      title: notification.title || 'Notification UNIBOX',
      subtitle: notification.body || 'Mise à jour liée à ton activité.',
      pills: [notificationLevelLabel(notification.level), notification.notification_type || 'notification'],
    });
  });

  return sortHistory(items).slice(0, 80);
}

async function buildRecruiterHistory() {
  const [offers, applications, notifications] = await Promise.all([
    listRecruiterOffers().catch(() => []),
    listRecruiterApplications().catch(() => []),
    listRecruiterNotifications().catch(() => []),
  ]);

  const details = await Promise.all(
    (applications || []).slice(0, 24).map((item) => getRecruiterCandidateDetail(item.id).catch(() => item))
  );

  const items = [];

  (offers || []).forEach((offer) => {
    items.push({
      date: offer.created_at,
      title: `Offre créée · ${offer.title || 'Offre UNIBOX'}`,
      subtitle: 'Annonce recruteur ajoutée dans ton espace.',
      pills: ['Offre', offer.status || 'draft'],
    });

    if (offer.published_at) {
      items.push({
        date: offer.published_at,
        title: `Offre publiée · ${offer.title || 'Offre UNIBOX'}`,
        subtitle: 'Visible côté étudiant sur UNIBOX.',
        pills: ['Publication'],
      });
    }

    if (offer.closed_at || offer.status === 'closed') {
      items.push({
        date: offer.closed_at || offer.updated_at || offer.created_at,
        title: `Offre fermée · ${offer.title || 'Offre UNIBOX'}`,
        subtitle: 'Annonce clôturée dans ton pipeline recrutement.',
        pills: ['Clôture'],
      });
    }
  });

  details.forEach((detail) => {
    const listingTitle = listingTitleFromApplication(detail);
    const candidateName = detail.profiles?.full_name || 'Candidat UNIBOX';

    (detail.application_status_events || []).forEach((event) => {
      items.push({
        date: event.created_at,
        title: `${candidateName} · ${applicationStatusLabel(event.to_status || detail.status)}`,
        subtitle: `${event.note || 'Évolution du dossier candidat.'} · ${listingTitle}`,
        pills: ['Candidature'],
      });
    });

    (detail.interviews || []).forEach((interview) => {
      const place = interview.location_label || interview.meeting_url || 'Lieu à confirmer';
      items.push({
        date: interview.created_at || interview.scheduled_at,
        title: `Entretien programmé · ${candidateName}`,
        subtitle: `${listingTitle} · ${formatDateTime(interview.scheduled_at)} · ${place}`,
        pills: ['Entretien'],
      });
    });
  });

  notifications.forEach((notification) => {
    items.push({
      date: notification.created_at,
      title: notification.title || 'Notification UNIBOX',
      subtitle: notification.body || 'Mise à jour liée à ton activité recruteur.',
      pills: [notificationLevelLabel(notification.level), notification.notification_type || 'notification'],
    });
  });

  return sortHistory(items).slice(0, 80);
}

async function buildParticularHistory() {
  const [jobs, applications, notifications] = await Promise.all([
    listParticularJobs().catch(() => []),
    listParticularApplications().catch(() => []),
    listParticularNotifications().catch(() => []),
  ]);

  const details = await Promise.all(
    (applications || []).slice(0, 24).map((item) => getParticularApplicationDetail(item.id).catch(() => item))
  );

  const items = [];

  (jobs || []).forEach((job) => {
    items.push({
      date: job.created_at,
      title: `Mission créée · ${job.title || 'Job minute UNIBOX'}`,
      subtitle: 'Mission ajoutée dans ton espace particulier.',
      pills: ['Job minute', job.status || 'draft'],
    });

    if (job.published_at) {
      items.push({
        date: job.published_at,
        title: `Mission publiée · ${job.title || 'Job minute UNIBOX'}`,
        subtitle: 'Mission visible côté étudiant.',
        pills: ['Publication'],
      });
    }

    if (job.closed_at || ['completed', 'closed', 'archived'].includes(job.status)) {
      items.push({
        date: job.closed_at || job.updated_at || job.created_at,
        title: `Mission clôturée · ${job.title || 'Job minute UNIBOX'}`,
        subtitle: 'Mission archivée dans ton historique particulier.',
        pills: ['Clôture'],
      });
    }
  });

  details.forEach((detail) => {
    const listingTitle = listingTitleFromApplication(detail);
    const candidateName = detail.profiles?.full_name || 'Candidat UNIBOX';

    (detail.application_status_events || []).forEach((event) => {
      items.push({
        date: event.created_at,
        title: `${candidateName} · ${applicationStatusLabel(event.to_status || detail.status)}`,
        subtitle: `${event.note || 'Évolution de candidature.'} · ${listingTitle}`,
        pills: ['Candidature'],
      });
    });

    (detail.interviews || []).forEach((interview) => {
      const place = interview.location_label || interview.meeting_url || 'Lieu à confirmer';
      items.push({
        date: interview.created_at || interview.scheduled_at,
        title: `Entretien proposé · ${candidateName}`,
        subtitle: `${listingTitle} · ${formatDateTime(interview.scheduled_at)} · ${place}`,
        pills: ['Entretien'],
      });
    });
  });

  notifications.forEach((notification) => {
    items.push({
      date: notification.created_at,
      title: notification.title || 'Notification UNIBOX',
      subtitle: notification.body || 'Mise à jour liée à ton activité particulier.',
      pills: [notificationLevelLabel(notification.level), notification.notification_type || 'notification'],
    });
  });

  return sortHistory(items).slice(0, 80);
}

async function buildAdminHistory() {
  const [logs, notifications, reports, cases, applications] = await Promise.all([
    listAdminAuditLogs().catch(() => []),
    listAdminNotifications().catch(() => []),
    listAdminReports().catch(() => []),
    listAdminModerationCases().catch(() => []),
    listAdminApplications().catch(() => []),
  ]);

  const items = [];

  (logs || []).forEach((log) => {
    items.push({
      date: log.created_at,
      title: log.action_type || 'Action admin',
      subtitle: `${log.target_table || 'plateforme'} · ${log.target_id || 'cible non précisée'}`,
      pills: ['Audit'],
    });
  });

  (reports || []).forEach((report) => {
    items.push({
      date: report.created_at,
      title: `Signalement ${report.status || 'ouvert'} · ${report.target_type || 'cible'}`,
      subtitle: report.description || report.reason_code || 'Signalement UNIBOX',
      pills: ['Signalement'],
    });
  });

  (cases || []).forEach((item) => {
    items.push({
      date: item.created_at,
      title: `Modération ${item.status || 'ouverte'}`,
      subtitle: item.decision_note || item.internal_note || item.action_type || 'Dossier de modération UNIBOX',
      pills: ['Modération'],
    });
  });

  (applications || []).forEach((application) => {
    const listingTitle = listingTitleFromApplication(application);
    items.push({
      date: application.updated_at || application.submitted_at,
      title: `Candidature ${applicationStatusLabel(application.status)}`,
      subtitle: `${listingTitle} · ${application.profiles?.full_name || 'Candidat UNIBOX'}`,
      pills: ['Candidature'],
    });
  });

  (notifications || []).forEach((notification) => {
    items.push({
      date: notification.created_at,
      title: notification.title || 'Notification admin',
      subtitle: notification.body || 'Alerte admin UNIBOX',
      pills: [notificationLevelLabel(notification.level), notification.notification_type || 'notification'],
    });
  });

  return sortHistory(items).slice(0, 100);
}

async function initStudentHistoryPage() {
  const target = qs('#studentHistoryList');
  if (!target) return;
  try {
    const items = await buildStudentHistory();
    renderHistoryItems(target, items);
    qs('#historyExportButton')?.addEventListener('click', () => {
      downloadHistory('unibox-historique-etudiant.json', items);
      appToast('Historique exporté', 'success');
    });
  } catch (error) {
    renderEmptyState(target, 'Impossible de charger l’historique', error.message || 'Réessaie dans un instant.');
  }
}

async function initRecruiterHistoryPage() {
  const target = qs('#recruiterHistoryList');
  if (!target) return;
  try {
    const items = await buildRecruiterHistory();
    renderHistoryItems(target, items);
    qs('#recruiterHistoryExport')?.addEventListener('click', () => {
      downloadHistory('unibox-historique-recruteur.json', items);
      appToast('Historique exporté', 'success');
    });
  } catch (error) {
    renderEmptyState(target, 'Impossible de charger l’historique', error.message || 'Réessaie dans un instant.');
  }
}

async function initParticularHistoryPage() {
  const target = qs('#particularHistoryList');
  if (!target) return;
  try {
    const items = await buildParticularHistory();
    renderHistoryItems(target, items);
  } catch (error) {
    renderEmptyState(target, 'Impossible de charger l’historique', error.message || 'Réessaie dans un instant.');
  }
}

async function initAdminHistoryPage() {
  const target = qs('#adminHistoryList');
  if (!target) return;
  try {
    const items = await buildAdminHistory();
    renderHistoryItems(target, items);
  } catch (error) {
    renderEmptyState(target, 'Impossible de charger l’historique admin', error.message || 'Réessaie dans un instant.');
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const page = document.body.dataset.page;
  if (page === 'student-history') await initStudentHistoryPage();
  if (page === 'recruiter-history') await initRecruiterHistoryPage();
  if (page === 'particular-history') await initParticularHistoryPage();
  if (page === 'admin-history') await initAdminHistoryPage();
});
