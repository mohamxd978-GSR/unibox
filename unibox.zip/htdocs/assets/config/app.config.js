export const APP_NAME = 'UNIBOX';

export const ROUTES = {
  landing: '/index-enhanced.html',
  auth: {
    login: '/index-enhanced.html#signin',
    signup: '/index-enhanced.html#signup',
    forgotPassword: '/auth/forgot-password.html',
    resetPassword: '/auth/reset-password.html',
    chooseRole: '/auth/choose-role.html',
  },
  onboarding: {
    student: '/auth/onboarding-student.html',
    recruiter: '/auth/onboarding-recruiter.html',
    particular: '/auth/onboarding-particular.html',
  },
  common: {
    accessDenied: '/common/access-denied.html',
    accountPending: '/common/account-pending.html',
    notFound: '/common/404.html',
  },
  dashboards: {
    student: '/student/etd-sidebar-acceuil.html',
    recruiter: '/recruiter/rec-dashboard.html',
    particular: '/particular/job-dashboard.html',
    admin: '/admin/admin-dashboard.html',
  },
};

export const ROLE_LABELS = {
  student: 'Étudiant',
  recruiter: 'Entreprise / Recruteur',
  particular: 'Particulier / Job minute',
  admin: 'Admin',
};

export const PUBLIC_SIGNUP_ROLES = ['student', 'recruiter', 'particular'];

export const OFFER_EMPLOYMENT_TYPES = ['stage', 'part-time', 'full-time'];

export const STORAGE_BUCKETS = {
  avatars: 'avatars',
  studentCvs: 'student-cvs',
  applicationDocuments: 'application-documents',
  studentPortfolio: 'student-portfolio',
  companyLogos: 'company-logos',
  reportAttachments: 'report-attachments',
  messageAttachments: 'message-attachments',
};
