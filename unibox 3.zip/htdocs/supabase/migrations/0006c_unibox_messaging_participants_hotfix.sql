begin;

drop policy if exists "conversations_select_participant_creator_or_admin" on public.conversations;
create policy "conversations_select_participant_creator_access_or_admin"
on public.conversations
for select
to authenticated
using (
  private.is_admin()
  or created_by_user_id = auth.uid()
  or public.user_participates_in_conversation(id)
  or (
    application_id is not null
    and public.user_can_access_application(application_id)
  )
);

drop policy if exists "conversations_update_participant_creator_or_admin" on public.conversations;
create policy "conversations_update_participant_creator_access_or_admin"
on public.conversations
for update
to authenticated
using (
  private.is_admin()
  or created_by_user_id = auth.uid()
  or public.user_participates_in_conversation(id)
  or (
    application_id is not null
    and public.user_can_access_application(application_id)
  )
)
with check (
  private.is_admin()
  or created_by_user_id = auth.uid()
  or public.user_participates_in_conversation(id)
  or (
    application_id is not null
    and public.user_can_access_application(application_id)
  )
);

drop policy if exists "conversation_participants_insert_creator_or_admin" on public.conversation_participants;
create policy "conversation_participants_insert_access_or_admin"
on public.conversation_participants
for insert
to authenticated
with check (
  private.is_admin()
  or exists (
    select 1
    from public.conversations c
    left join public.applications a on a.id = c.application_id
    left join public.offers o on o.id = a.offer_id
    left join public.minute_jobs j on j.id = a.minute_job_id
    where c.id = conversation_id
      and (
        c.created_by_user_id = auth.uid()
        or (c.application_id is not null and public.user_can_access_application(c.application_id))
      )
      and user_id in (
        coalesce(a.student_user_id, '00000000-0000-0000-0000-000000000000'::uuid),
        coalesce(o.created_by_recruiter_user_id, '00000000-0000-0000-0000-000000000000'::uuid),
        coalesce(j.particular_user_id, '00000000-0000-0000-0000-000000000000'::uuid),
        auth.uid()
      )
  )
);

commit;