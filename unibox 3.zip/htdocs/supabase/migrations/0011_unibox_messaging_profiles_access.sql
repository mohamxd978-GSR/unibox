-- Allow users to see profiles of other participants in their conversations
-- This is needed for the messaging UI to display avatars and names
-- This is ADDITIVE and does not modify existing policies

create policy "profiles_select_for_messaging"
on public.profiles
for select
to authenticated
using (
  -- User can see their own profile (existing behavior)
  id = auth.uid()
  -- User can see profiles of people they have conversations with
  or exists (
    select 1 from public.conversation_participants cp
    where cp.user_id = auth.uid()
    and exists (
      select 1 from public.conversation_participants cp2
      where cp2.conversation_id = cp.conversation_id
      and cp2.user_id = profiles.id
    )
  )
);
