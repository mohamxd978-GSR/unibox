begin;

create or replace function public.validate_minute_job_publish_requirements()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.status = 'published' then
    if coalesce(trim(new.title), '') = '' then
      raise exception 'minute_job_title_required';
    end if;

    if coalesce(trim(new.description), '') = '' then
      raise exception 'minute_job_description_required';
    end if;

    if coalesce(trim(new.address_text), '') = '' then
      raise exception 'minute_job_address_required';
    end if;

    if coalesce(trim(new.city), '') = '' then
      raise exception 'minute_job_city_required';
    end if;

    if coalesce(trim(new.country), '') = '' then
      raise exception 'minute_job_country_required';
    end if;

    if new.published_at is null then
      new.published_at := timezone('utc', now());
    end if;
  end if;

  if new.status = 'closed' and new.closed_at is null then
    new.closed_at := timezone('utc', now());
  end if;

  if new.status = 'completed' and new.completed_at is null then
    new.completed_at := timezone('utc', now());
  end if;

  return new;
end;
$$;

drop trigger if exists trg_minute_jobs_publish_requirements on public.minute_jobs;
create trigger trg_minute_jobs_publish_requirements
before insert or update on public.minute_jobs
for each row
execute function public.validate_minute_job_publish_requirements();

commit;
