-- UNIBOX · Bloc 7
-- Candidatures, statuts, historiques, entretiens, documents CV.

begin;

create extension if not exists pgcrypto;

DO $$
begin
  if not exists (select 1 from pg_type where typname = 'application_status') then
    create type public.application_status as enum (
      'submitted',
      'under_review',
      'shortlisted',
      'interview_requested',
      'interview_scheduled',
      'accepted',
      'rejected',
      'withdrawn',
      'cancelled'
    );
  end if;

  if not exists (select 1 from pg_type where typname = 'interview_status') then
    create type public.interview_status as enum (
      'proposed',
      'confirmed',
      'completed',
      'cancelled',
      'rescheduled',
      'no_show'
    );
  end if;
end $$;

create or replace function public.profile_has_role(target_user_id uuid, expected_role public.user_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1
    from public.profiles
    where id = target_user_id
      and role = expected_role
  )
$$;

create or replace function public.recruiter_can_manage_offer(target_offer_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select
    private.is_admin()
    or exists(
      select 1
      from public.offers o
      left join public.recruiter_profiles rp on rp.user_id = auth.uid()
      where o.id = target_offer_id
        and (
          o.created_by_recruiter_user_id = auth.uid()
          or rp.company_id = o.company_id
        )
    )
$$;

create or replace function public.particular_can_manage_job(target_job_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select
    private.is_admin()
    or exists(
      select 1
      from public.minute_jobs j
      where j.id = target_job_id
        and j.particular_user_id = auth.uid()
    )
$$;

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  student_user_id uuid not null references public.profiles(id) on delete cascade,
  listing_type public.listing_type not null,
  offer_id uuid references public.offers(id) on delete cascade,
  minute_job_id uuid references public.minute_jobs(id) on delete cascade,
  message_body text,
  status public.application_status not null default 'submitted',
  submitted_at timestamptz not null default timezone('utc', now()),
  last_status_at timestamptz not null default timezone('utc', now()),
  shortlisted_at timestamptz,
  interview_requested_at timestamptz,
  accepted_at timestamptz,
  rejected_at timestamptz,
  withdrawn_at timestamptz,
  cancelled_at timestamptz,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  constraint applications_listing_consistency check (
    (
      listing_type = 'offer'
      and offer_id is not null
      and minute_job_id is null
    )
    or
    (
      listing_type = 'minute_job'
      and minute_job_id is not null
      and offer_id is null
    )
  )
);

create index if not exists idx_applications_student_user_id on public.applications(student_user_id);
create index if not exists idx_applications_offer_id on public.applications(offer_id);
create index if not exists idx_applications_minute_job_id on public.applications(minute_job_id);
create index if not exists idx_applications_status on public.applications(status);
create index if not exists idx_applications_submitted_at on public.applications(submitted_at desc);

create unique index if not exists uq_applications_offer_per_student
  on public.applications(student_user_id, offer_id)
  where offer_id is not null;

create unique index if not exists uq_applications_minute_job_per_student
  on public.applications(student_user_id, minute_job_id)
  where minute_job_id is not null;

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'minute_jobs_selected_application_fkey'
  ) then
    alter table public.minute_jobs
      add constraint minute_jobs_selected_application_fkey
      foreign key (selected_application_id)
      references public.applications(id)
      on delete set null;
  end if;
end $$;

create or replace function public.validate_application_integrity()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  offer_is_ok boolean;
  minute_job_is_ok boolean;
begin
  if not public.profile_has_role(new.student_user_id, 'student') then
    raise exception 'applications.student_user_id must reference a student profile';
  end if;

  if new.listing_type = 'offer' then
    select exists(
      select 1
      from public.offers o
      join public.companies c on c.id = o.company_id
      where o.id = new.offer_id
        and o.status = 'published'
        and o.hidden_by_admin = false
        and c.status = 'active'
        and c.hidden_by_admin = false
    ) into offer_is_ok;

    if not offer_is_ok then
      raise exception 'application target offer is not available for student application';
    end if;
  end if;

  if new.listing_type = 'minute_job' then
    select exists(
      select 1
      from public.minute_jobs j
      where j.id = new.minute_job_id
        and j.status = 'published'
        and j.hidden_by_admin = false
    ) into minute_job_is_ok;

    if not minute_job_is_ok then
      raise exception 'application target minute job is not available for student application';
    end if;
  end if;

  return new;
end;
$$;

create or replace function public.user_can_access_application(target_application_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select
    private.is_admin()
    or exists(
      select 1
      from public.applications a
      left join public.offers o on o.id = a.offer_id
      left join public.minute_jobs j on j.id = a.minute_job_id
      left join public.recruiter_profiles rp on rp.user_id = auth.uid()
      where a.id = target_application_id
        and (
          a.student_user_id = auth.uid()
          or (
            o.id is not null
            and (
              o.created_by_recruiter_user_id = auth.uid()
              or rp.company_id = o.company_id
            )
          )
          or (
            j.id is not null
            and j.particular_user_id = auth.uid()
          )
        )
    )
$$;

create or replace function public.sync_application_status_metadata()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    new.submitted_at := coalesce(new.submitted_at, timezone('utc', now()));
    new.last_status_at := coalesce(new.last_status_at, timezone('utc', now()));
    return new;
  end if;

  if old.status is distinct from new.status then
    new.last_status_at := timezone('utc', now());

    if new.status = 'shortlisted' and new.shortlisted_at is null then
      new.shortlisted_at := timezone('utc', now());
    elsif new.status = 'interview_requested' and new.interview_requested_at is null then
      new.interview_requested_at := timezone('utc', now());
    elsif new.status = 'accepted' and new.accepted_at is null then
      new.accepted_at := timezone('utc', now());
    elsif new.status = 'rejected' and new.rejected_at is null then
      new.rejected_at := timezone('utc', now());
    elsif new.status = 'withdrawn' and new.withdrawn_at is null then
      new.withdrawn_at := timezone('utc', now());
    elsif new.status = 'cancelled' and new.cancelled_at is null then
      new.cancelled_at := timezone('utc', now());
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_applications_validate_integrity on public.applications;
create trigger trg_applications_validate_integrity
before insert or update on public.applications
for each row execute function public.validate_application_integrity();

drop trigger if exists trg_applications_updated_at on public.applications;
create trigger trg_applications_updated_at
before update on public.applications
for each row execute function public.set_updated_at();

drop trigger if exists trg_applications_sync_status_metadata on public.applications;
create trigger trg_applications_sync_status_metadata
before insert or update on public.applications
for each row execute function public.sync_application_status_metadata();

create table if not exists public.application_status_events (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  actor_user_id uuid references public.profiles(id) on delete set null,
  from_status public.application_status,
  to_status public.application_status not null,
  note text,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create index if not exists idx_application_status_events_application_id on public.application_status_events(application_id, created_at desc);

drop trigger if exists trg_application_status_events_updated_at on public.application_status_events;
create trigger trg_application_status_events_updated_at
before update on public.application_status_events
for each row execute function public.set_updated_at();

create or replace function public.log_application_status_event()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.application_status_events (application_id, actor_user_id, from_status, to_status, note)
    values (new.id, coalesce(auth.uid(), new.student_user_id), null, new.status, 'Application created');
    return new;
  end if;

  if tg_op = 'UPDATE' and old.status is distinct from new.status then
    insert into public.application_status_events (application_id, actor_user_id, from_status, to_status, note)
    values (new.id, coalesce(auth.uid(), new.student_user_id), old.status, new.status, 'Application status changed');
  end if;

  return new;
end;
$$;

drop trigger if exists trg_applications_status_event on public.applications;
create trigger trg_applications_status_event
after insert or update on public.applications
for each row execute function public.log_application_status_event();

create table if not exists public.interviews (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  created_by_user_id uuid not null references public.profiles(id) on delete restrict,
  scheduled_at timestamptz not null,
  duration_minutes integer not null default 30,
  location_type text not null default 'meet',
  meeting_url text,
  location_label text,
  notes text,
  status public.interview_status not null default 'proposed',
  confirmed_at timestamptz,
  cancelled_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  constraint interviews_duration_positive check (duration_minutes > 0),
  constraint interviews_location_type_valid check (location_type in ('meet', 'phone', 'onsite', 'other'))
);

create index if not exists idx_interviews_application_id on public.interviews(application_id);
create index if not exists idx_interviews_status on public.interviews(status);

drop trigger if exists trg_interviews_updated_at on public.interviews;
create trigger trg_interviews_updated_at
before update on public.interviews
for each row execute function public.set_updated_at();

create table if not exists public.application_documents (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  uploaded_by_user_id uuid not null references public.profiles(id) on delete cascade,
  document_type text not null default 'cv',
  storage_bucket text not null default 'application-documents',
  storage_path text not null,
  file_name text not null,
  mime_type text,
  file_size_bytes bigint,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create index if not exists idx_application_documents_application_id on public.application_documents(application_id, created_at desc);

drop trigger if exists trg_application_documents_updated_at on public.application_documents;
create trigger trg_application_documents_updated_at
before update on public.application_documents
for each row execute function public.set_updated_at();

alter table public.applications enable row level security;
alter table public.application_status_events enable row level security;
alter table public.interviews enable row level security;
alter table public.application_documents enable row level security;

drop policy if exists applications_select_authorized_or_admin on public.applications;
create policy applications_select_authorized_or_admin
on public.applications
for select to authenticated
using (private.is_admin() or public.user_can_access_application(id));

drop policy if exists applications_insert_student_self_or_admin on public.applications;
create policy applications_insert_student_self_or_admin
on public.applications
for insert to authenticated
with check (
  private.is_admin()
  or (
    student_user_id = auth.uid()
    and public.profile_has_role(auth.uid(), 'student')
  )
);

drop policy if exists applications_update_authorized_or_admin on public.applications;
create policy applications_update_authorized_or_admin
on public.applications
for update to authenticated
using (private.is_admin() or public.user_can_access_application(id))
with check (private.is_admin() or public.user_can_access_application(id));

drop policy if exists applications_delete_owner_or_admin on public.applications;
create policy applications_delete_owner_or_admin
on public.applications
for delete to authenticated
using (private.is_admin() or student_user_id = auth.uid());

drop policy if exists application_status_events_select_authorized_or_admin on public.application_status_events;
create policy application_status_events_select_authorized_or_admin
on public.application_status_events
for select to authenticated
using (private.is_admin() or public.user_can_access_application(application_id));

drop policy if exists application_status_events_insert_actor_or_admin on public.application_status_events;
create policy application_status_events_insert_actor_or_admin
on public.application_status_events
for insert to authenticated
with check (private.is_admin() or actor_user_id = auth.uid());

drop policy if exists interviews_select_authorized_or_admin on public.interviews;
create policy interviews_select_authorized_or_admin
on public.interviews
for select to authenticated
using (private.is_admin() or public.user_can_access_application(application_id));

drop policy if exists interviews_insert_manager_or_admin on public.interviews;
create policy interviews_insert_manager_or_admin
on public.interviews
for insert to authenticated
with check (
  private.is_admin()
  or exists (
    select 1
    from public.applications a
    left join public.offers o on o.id = a.offer_id
    left join public.minute_jobs j on j.id = a.minute_job_id
    where a.id = application_id
      and (
        public.recruiter_can_manage_offer(o.id)
        or public.particular_can_manage_job(j.id)
      )
  )
);

drop policy if exists interviews_update_manager_or_admin on public.interviews;
create policy interviews_update_manager_or_admin
on public.interviews
for update to authenticated
using (private.is_admin() or public.user_can_access_application(application_id))
with check (private.is_admin() or public.user_can_access_application(application_id));

drop policy if exists application_documents_select_authorized_or_admin on public.application_documents;
create policy application_documents_select_authorized_or_admin
on public.application_documents
for select to authenticated
using (private.is_admin() or public.user_can_access_application(application_id));

drop policy if exists application_documents_insert_student_or_admin on public.application_documents;
create policy application_documents_insert_student_or_admin
on public.application_documents
for insert to authenticated
with check (
  private.is_admin()
  or (
    uploaded_by_user_id = auth.uid()
    and exists (
      select 1
      from public.applications a
      where a.id = application_id
        and a.student_user_id = auth.uid()
    )
  )
);

insert into storage.buckets (id, name, public)
values ('application-documents', 'application-documents', false)
on conflict (id) do nothing;

create or replace function public.extract_application_id_from_storage_path(object_name text)
returns uuid
language plpgsql
stable
security definer
set search_path = public, storage
as $$
declare
  raw_id text;
begin
  raw_id := (storage.foldername(object_name))[3];
  if raw_id is null or raw_id = '' then
    return null;
  end if;
  return raw_id::uuid;
exception when others then
  return null;
end;
$$;

drop policy if exists application_documents_select_authorized on storage.objects;
create policy application_documents_select_authorized
on storage.objects
for select to authenticated
using (
  bucket_id = 'application-documents'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or private.is_admin()
    or public.user_can_access_application(public.extract_application_id_from_storage_path(name))
  )
);

drop policy if exists application_documents_insert_owner on storage.objects;
create policy application_documents_insert_owner
on storage.objects
for insert to authenticated
with check (
  bucket_id = 'application-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
  and (storage.foldername(name))[2] = 'applications'
);

commit;
