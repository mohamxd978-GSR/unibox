begin;

-- =========================
-- DEV HOTFIX: messaging open access for authenticated users
-- This keeps anon out, but removes RLS blocking for logged-in users
-- =========================

-- Conversations
drop policy if exists conversations_dev_select on public.conversations;
create policy conversations_dev_select
on public.conversations
for select
to authenticated
using (true);

drop policy if exists conversations_dev_insert on public.conversations;
create policy conversations_dev_insert
on public.conversations
for insert
to authenticated
with check (true);

drop policy if exists conversations_dev_update on public.conversations;
create policy conversations_dev_update
on public.conversations
for update
to authenticated
using (true)
with check (true);

drop policy if exists conversations_dev_delete on public.conversations;
create policy conversations_dev_delete
on public.conversations
for delete
to authenticated
using (true);

-- Conversation participants
drop policy if exists conversation_participants_dev_select on public.conversation_participants;
create policy conversation_participants_dev_select
on public.conversation_participants
for select
to authenticated
using (true);

drop policy if exists conversation_participants_dev_insert on public.conversation_participants;
create policy conversation_participants_dev_insert
on public.conversation_participants
for insert
to authenticated
with check (true);

drop policy if exists conversation_participants_dev_update on public.conversation_participants;
create policy conversation_participants_dev_update
on public.conversation_participants
for update
to authenticated
using (true)
with check (true);

drop policy if exists conversation_participants_dev_delete on public.conversation_participants;
create policy conversation_participants_dev_delete
on public.conversation_participants
for delete
to authenticated
using (true);

-- Messages
drop policy if exists messages_dev_select on public.messages;
create policy messages_dev_select
on public.messages
for select
to authenticated
using (true);

drop policy if exists messages_dev_insert on public.messages;
create policy messages_dev_insert
on public.messages
for insert
to authenticated
with check (true);

drop policy if exists messages_dev_update on public.messages;
create policy messages_dev_update
on public.messages
for update
to authenticated
using (true)
with check (true);

drop policy if exists messages_dev_delete on public.messages;
create policy messages_dev_delete
on public.messages
for delete
to authenticated
using (true);

-- =========================
-- Backfill missing participants for existing application conversations
-- =========================
insert into public.conversation_participants (conversation_id, user_id, participant_role)
select distinct
  c.id as conversation_id,
  x.user_id,
  'member' as participant_role
from public.conversations c
left join public.applications a on a.id = c.application_id
left join public.offers o on o.id = a.offer_id
left join public.minute_jobs j on j.id = a.minute_job_id
cross join lateral (
  values
    (a.student_user_id),
    (o.created_by_recruiter_user_id),
    (j.particular_user_id),
    (c.created_by_user_id)
) as x(user_id)
where x.user_id is not null
and not exists (
  select 1
  from public.conversation_participants cp
  where cp.conversation_id = c.id
    and cp.user_id = x.user_id
);

commit;