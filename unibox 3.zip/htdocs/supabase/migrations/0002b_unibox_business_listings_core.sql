-- UNIBOX · Bloc 6
-- Tables métier minimales pour entreprises, offres, jobs minute,
-- favoris étudiant et vue unifiée active_listings_view.

begin;

create extension if not exists pgcrypto;

DO $$
begin
  if not exists (select 1 from pg_type where typname = 'company_status') then
    create type public.company_status as enum ('draft', 'active', 'paused', 'suspended', 'archived');
  end if;

  if not exists (select 1 from pg_type where typname = 'offer_status') then
    create type public.offer_status as enum ('draft', 'published', 'paused', 'closed', 'archived');
  end if;

  if not exists (select 1 from pg_type where typname = 'minute_job_status') then
    create type public.minute_job_status as enum ('draft', 'published', 'paused', 'closed', 'completed', 'archived');
  end if;

  if not exists (select 1 from pg_type where typname = 'listing_type') then
    create type public.listing_type as enum ('offer', 'minute_job');
  end if;
end $$;

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null references public.profiles(id) on delete cascade,
  legal_name text,
  name text not null,
  slug text,
  email text,
  phone text,
  website_url text,
  industry text,
  company_size text,
  description text,
  logo_path text,
  city text not null,
  country text not null,
  address_line1 text not null,
  address_line2 text,
  postal_code text,
  status public.company_status not null default 'active',
  hidden_by_admin boolean not null default false,
  approved_by_admin_user_id uuid references public.admin_profiles(user_id) on delete set null,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create unique index if not exists idx_companies_owner_unique on public.companies(owner_user_id);
create unique index if not exists idx_companies_slug_unique on public.companies(lower(slug)) where slug is not null;
create index if not exists idx_companies_status on public.companies(status, hidden_by_admin);

alter table public.recruiter_profiles
  add column if not exists company_id uuid references public.companies(id) on delete set null;

create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  created_by_recruiter_user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  summary text,
  description text not null,
  requirements text,
  responsibilities text,
  contract_type text not null,
  work_mode text,
  city text,
  country text,
  address_text text,
  salary_min numeric(12,2),
  salary_max numeric(12,2),
  salary_currency text not null default 'EUR',
  salary_label text,
  hours_per_week integer,
  start_date date,
  application_deadline date,
  spots_count integer not null default 1,
  skills text[] not null default '{}',
  benefits text[] not null default '{}',
  status public.offer_status not null default 'draft',
  published_at timestamptz,
  closed_at timestamptz,
  hidden_by_admin boolean not null default false,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create index if not exists idx_offers_recruiter on public.offers(created_by_recruiter_user_id, status, created_at desc);
create index if not exists idx_offers_company on public.offers(company_id);
create index if not exists idx_offers_listing_feed on public.offers(status, hidden_by_admin, published_at desc);

create table if not exists public.minute_jobs (
  id uuid primary key default gen_random_uuid(),
  particular_user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  category text,
  summary text,
  description text not null,
  requirements text,
  city text,
  country text,
  address_text text,
  rate_amount numeric(12,2),
  rate_currency text not null default 'EUR',
  rate_label text,
  duration_hours numeric(6,2),
  starts_at timestamptz,
  ends_at timestamptz,
  needed_people_count integer not null default 1,
  urgency_level text not null default 'normal',
  selected_application_id uuid,
  status public.minute_job_status not null default 'draft',
  published_at timestamptz,
  closed_at timestamptz,
  completed_at timestamptz,
  hidden_by_admin boolean not null default false,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create index if not exists idx_minute_jobs_owner on public.minute_jobs(particular_user_id, status, created_at desc);
create index if not exists idx_minute_jobs_listing_feed on public.minute_jobs(status, hidden_by_admin, published_at desc);

create table if not exists public.saved_listings (
  id uuid primary key default gen_random_uuid(),
  student_user_id uuid not null references public.profiles(id) on delete cascade,
  listing_type public.listing_type not null,
  offer_id uuid references public.offers(id) on delete cascade,
  minute_job_id uuid references public.minute_jobs(id) on delete cascade,
  created_at timestamptz not null default timezone('utc', now()),
  constraint saved_listings_target_check check (
    (listing_type = 'offer' and offer_id is not null and minute_job_id is null)
    or (listing_type = 'minute_job' and minute_job_id is not null and offer_id is null)
  )
);

create unique index if not exists idx_saved_listings_student_offer_unique
  on public.saved_listings(student_user_id, offer_id)
  where offer_id is not null;

create unique index if not exists idx_saved_listings_student_minute_job_unique
  on public.saved_listings(student_user_id, minute_job_id)
  where minute_job_id is not null;

create index if not exists idx_saved_listings_student_created on public.saved_listings(student_user_id, created_at desc);

create or replace function public.sync_recruiter_company_from_company_owner()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.recruiter_profiles
  set company_id = new.id,
      updated_at = timezone('utc', now())
  where user_id = new.owner_user_id;

  return new;
end;
$$;

drop trigger if exists trg_companies_updated_at on public.companies;
create trigger trg_companies_updated_at
before update on public.companies
for each row execute function public.set_updated_at();

drop trigger if exists trg_offers_updated_at on public.offers;
create trigger trg_offers_updated_at
before update on public.offers
for each row execute function public.set_updated_at();

drop trigger if exists trg_minute_jobs_updated_at on public.minute_jobs;
create trigger trg_minute_jobs_updated_at
before update on public.minute_jobs
for each row execute function public.set_updated_at();

drop trigger if exists trg_companies_sync_owner_profile on public.companies;
create trigger trg_companies_sync_owner_profile
after insert or update of owner_user_id on public.companies
for each row execute function public.sync_recruiter_company_from_company_owner();

create or replace function public.user_can_manage_company(target_company_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1
    from public.companies c
    left join public.recruiter_profiles rp on rp.user_id = auth.uid()
    where c.id = target_company_id
      and (
        c.owner_user_id = auth.uid()
        or rp.company_id = c.id
        or private.is_admin()
      )
  )
$$;

create or replace function public.validate_offer_company_membership()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.user_can_manage_company(new.company_id) then
    raise exception 'offer_company_access_denied';
  end if;

  if new.created_by_recruiter_user_id is null then
    new.created_by_recruiter_user_id := auth.uid();
  end if;

  return new;
end;
$$;

drop trigger if exists trg_offers_validate_company_membership on public.offers;
create trigger trg_offers_validate_company_membership
before insert or update on public.offers
for each row execute function public.validate_offer_company_membership();

create or replace view public.active_listings_view as
select
  'offer'::public.listing_type as listing_type,
  o.id as listing_id,
  o.title,
  o.summary,
  o.description,
  c.name as company_name,
  c.name as owner_display_name,
  o.city,
  o.country,
  o.address_text,
  concat_ws(', ', o.address_text, o.city, o.country) as location_label,
  o.contract_type as employment_type,
  null::text as urgency_level,
  coalesce(
    o.salary_label,
    case
      when o.salary_min is not null and o.salary_max is not null then concat(o.salary_min::text, ' - ', o.salary_max::text, ' ', o.salary_currency)
      when o.salary_min is not null then concat('À partir de ', o.salary_min::text, ' ', o.salary_currency)
      when o.salary_max is not null then concat('Jusqu''à ', o.salary_max::text, ' ', o.salary_currency)
      else null
    end
  ) as rate_or_salary_label,
  o.work_mode,
  o.published_at,
  o.created_at as source_created_at,
  c.logo_path as company_logo_path,
  null::text as profile_avatar_path,
  o.hours_per_week
from public.offers o
join public.companies c on c.id = o.company_id
where o.status = 'published'
  and o.hidden_by_admin = false
  and c.hidden_by_admin = false
  and c.status = 'active'
union all
select
  'minute_job'::public.listing_type as listing_type,
  m.id as listing_id,
  m.title,
  m.summary,
  m.description,
  null::text as company_name,
  coalesce(p.full_name, 'Particulier UNIBOX') as owner_display_name,
  m.city,
  m.country,
  m.address_text,
  concat_ws(', ', m.address_text, m.city, m.country) as location_label,
  null::text as employment_type,
  m.urgency_level,
  coalesce(
    m.rate_label,
    case
      when m.rate_amount is not null then concat(m.rate_amount::text, ' ', m.rate_currency)
      else null
    end
  ) as rate_or_salary_label,
  null::text as work_mode,
  m.published_at,
  m.created_at as source_created_at,
  null::text as company_logo_path,
  p.avatar_path as profile_avatar_path,
  null::integer as hours_per_week
from public.minute_jobs m
join public.profiles p on p.id = m.particular_user_id
where m.status = 'published'
  and m.hidden_by_admin = false;

alter table public.companies enable row level security;
alter table public.offers enable row level security;
alter table public.minute_jobs enable row level security;
alter table public.saved_listings enable row level security;

drop policy if exists companies_select_visible_or_owner on public.companies;
create policy companies_select_visible_or_owner
on public.companies
for select
using (
  private.is_admin()
  or owner_user_id = auth.uid()
  or (hidden_by_admin = false and status = 'active')
);

drop policy if exists companies_insert_owner on public.companies;
create policy companies_insert_owner
on public.companies
for insert
to authenticated
with check (
  private.current_user_role() = 'recruiter'
  and owner_user_id = auth.uid()
);

drop policy if exists companies_update_owner_or_admin on public.companies;
create policy companies_update_owner_or_admin
on public.companies
for update
to authenticated
using (
  private.is_admin() or owner_user_id = auth.uid()
)
with check (
  private.is_admin() or owner_user_id = auth.uid()
);

drop policy if exists companies_delete_owner_or_admin on public.companies;
create policy companies_delete_owner_or_admin
on public.companies
for delete
to authenticated
using (
  private.is_admin() or owner_user_id = auth.uid()
);

drop policy if exists offers_select_published_or_owner on public.offers;
create policy offers_select_published_or_owner
on public.offers
for select
using (
  private.is_admin()
  or created_by_recruiter_user_id = auth.uid()
  or (
    status = 'published'
    and hidden_by_admin = false
    and exists (
      select 1 from public.companies c
      where c.id = company_id
        and c.hidden_by_admin = false
        and c.status = 'active'
    )
  )
);

drop policy if exists offers_insert_recruiter_or_admin on public.offers;
create policy offers_insert_recruiter_or_admin
on public.offers
for insert
to authenticated
with check (
  private.is_admin()
  or (
    private.current_user_role() = 'recruiter'
    and created_by_recruiter_user_id = auth.uid()
    and public.user_can_manage_company(company_id)
  )
);

drop policy if exists offers_update_recruiter_or_admin on public.offers;
create policy offers_update_recruiter_or_admin
on public.offers
for update
to authenticated
using (
  private.is_admin()
  or (
    private.current_user_role() = 'recruiter'
    and created_by_recruiter_user_id = auth.uid()
    and public.user_can_manage_company(company_id)
  )
)
with check (
  private.is_admin()
  or (
    private.current_user_role() = 'recruiter'
    and created_by_recruiter_user_id = auth.uid()
    and public.user_can_manage_company(company_id)
  )
);

drop policy if exists offers_delete_recruiter_or_admin on public.offers;
create policy offers_delete_recruiter_or_admin
on public.offers
for delete
to authenticated
using (
  private.is_admin()
  or (
    private.current_user_role() = 'recruiter'
    and created_by_recruiter_user_id = auth.uid()
  )
);

drop policy if exists minute_jobs_select_published_or_owner on public.minute_jobs;
create policy minute_jobs_select_published_or_owner
on public.minute_jobs
for select
using (
  private.is_admin()
  or particular_user_id = auth.uid()
  or (status = 'published' and hidden_by_admin = false)
);

drop policy if exists minute_jobs_insert_owner_or_admin on public.minute_jobs;
create policy minute_jobs_insert_owner_or_admin
on public.minute_jobs
for insert
to authenticated
with check (
  private.is_admin()
  or (
    private.current_user_role() = 'particular'
    and particular_user_id = auth.uid()
  )
);

drop policy if exists minute_jobs_update_owner_or_admin on public.minute_jobs;
create policy minute_jobs_update_owner_or_admin
on public.minute_jobs
for update
to authenticated
using (
  private.is_admin()
  or (
    private.current_user_role() = 'particular'
    and particular_user_id = auth.uid()
  )
)
with check (
  private.is_admin()
  or (
    private.current_user_role() = 'particular'
    and particular_user_id = auth.uid()
  )
);

drop policy if exists minute_jobs_delete_owner_or_admin on public.minute_jobs;
create policy minute_jobs_delete_owner_or_admin
on public.minute_jobs
for delete
to authenticated
using (
  private.is_admin()
  or (
    private.current_user_role() = 'particular'
    and particular_user_id = auth.uid()
  )
);

drop policy if exists saved_listings_select_own on public.saved_listings;
create policy saved_listings_select_own
on public.saved_listings
for select
to authenticated
using (student_user_id = auth.uid());

drop policy if exists saved_listings_insert_own on public.saved_listings;
create policy saved_listings_insert_own
on public.saved_listings
for insert
to authenticated
with check (
  private.current_user_role() = 'student'
  and student_user_id = auth.uid()
);

drop policy if exists saved_listings_delete_own on public.saved_listings;
create policy saved_listings_delete_own
on public.saved_listings
for delete
to authenticated
using (student_user_id = auth.uid());

commit;
