-- Migration: Vue candidatures recruteur avec profil étudiant visible
-- Permet au recruteur de voir le nom et l'avatar du candidat malgré le RLS sur profiles

begin;

-- Vue sécurisée qui expose les candidatures avec les infos du profil étudiant
-- pour les recruteurs propriétaires des offres concernées.
create or replace view public.recruiter_applications_view
with (security_invoker = false) as
select
  a.id,
  a.status,
  a.submitted_at,
  a.last_status_at,
  a.message_body,
  a.offer_id,
  a.minute_job_id,
  a.student_user_id,
  -- Infos de l'offre
  o.title as offer_title,
  o.contract_type as offer_contract_type,
  o.city as offer_city,
  o.created_by_recruiter_user_id,
  -- Infos du candidat (profil étudiant)
  student.id as student_id,
  student.full_name as student_full_name,
  student.email as student_email,
  student.city as student_city,
  student.avatar_path as student_avatar_path
from public.applications a
left join public.offers o on o.id = a.offer_id
left join public.profiles student on student.id = a.student_user_id
where a.offer_id is not null;

-- Donner accès en lecture aux utilisateurs authentifiés
-- La sécurité réelle est gérée côté applicatif (on filtre par created_by_recruiter_user_id)
grant select on public.recruiter_applications_view to authenticated;

commit;
