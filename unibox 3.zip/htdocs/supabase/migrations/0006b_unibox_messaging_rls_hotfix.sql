begin;

drop policy if exists "conversations_select_participant_or_admin" on public.conversations;
create policy "conversations_select_participant_creator_or_admin"
on public.conversations
for select
to authenticated
using (
  private.is_admin()
  or created_by_user_id = auth.uid()
  or public.user_participates_in_conversation(id)
);

drop policy if exists "conversations_insert_creator_or_admin" on public.conversations;
create policy "conversations_insert_creator_access_or_admin"
on public.conversations
for insert
to authenticated
with check (
  private.is_admin()
  or (
    created_by_user_id = auth.uid()
    and (
      application_id is null
      or public.user_can_access_application(application_id)
    )
  )
);

drop policy if exists "conversations_update_participant_or_admin" on public.conversations;
create policy "conversations_update_participant_creator_or_admin"
on public.conversations
for update
to authenticated
using (
  private.is_admin()
  or created_by_user_id = auth.uid()
  or public.user_participates_in_conversation(id)
)
with check (
  private.is_admin()
  or created_by_user_id = auth.uid()
  or public.user_participates_in_conversation(id)
);

commit;