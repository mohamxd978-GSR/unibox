begin;

create extension if not exists pgcrypto;

create or replace function private.notification_type_enabled_for_user(target_user_id uuid, target_type public.notification_type)
returns boolean
language plpgsql
stable
security definer
set search_path = public, private
as $$
declare
  prefs public.notification_preferences%rowtype;
  profile_row public.profiles%rowtype;
begin
  select * into profile_row from public.profiles where id = target_user_id;
  if profile_row.id is null then
    return false;
  end if;

  if profile_row.account_status = 'deleted' then
    return false;
  end if;

  select * into prefs from public.notification_preferences where user_id = target_user_id;
  if prefs.user_id is null then
    return true;
  end if;

  if prefs.in_app_enabled = false then
    return false;
  end if;

  if target_type = 'application' then
    return prefs.application_updates_enabled;
  elsif target_type = 'message' then
    return prefs.message_updates_enabled;
  elsif target_type in ('moderation', 'account') then
    return prefs.moderation_updates_enabled;
  end if;

  return true;
end;
$$;

create or replace function public.emit_unibox_notification(
  p_user_id uuid,
  p_notification_type public.notification_type,
  p_level public.notification_level,
  p_title text,
  p_body text,
  p_target_type text default null,
  p_target_id uuid default null,
  p_action_url text default null
)
returns uuid
language plpgsql
security definer
set search_path = public, private
as $$
declare
  inserted_id uuid;
begin
  if p_user_id is null then
    return null;
  end if;

  if coalesce(trim(p_title), '') = '' or coalesce(trim(p_body), '') = '' then
    return null;
  end if;

  if not private.notification_type_enabled_for_user(p_user_id, p_notification_type) then
    return null;
  end if;

  insert into public.notifications (
    user_id,
    notification_type,
    level,
    title,
    body,
    target_type,
    target_id,
    action_url,
    is_read
  )
  values (
    p_user_id,
    p_notification_type,
    p_level,
    trim(p_title),
    trim(p_body),
    nullif(trim(coalesce(p_target_type, '')), ''),
    p_target_id,
    nullif(trim(coalesce(p_action_url, '')), ''),
    false
  )
  returning id into inserted_id;

  return inserted_id;
end;
$$;

create or replace function private.notification_url_for_role(target_role public.user_role, target_kind text, application_id uuid default null, conversation_id uuid default null)
returns text
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if target_kind = 'message' then
    if target_role = 'student' then
      return '/student/etd-messagerie.html?conversation=' || conversation_id::text;
    elsif target_role = 'recruiter' then
      return '/recruiter/rec-message.html?conversation=' || conversation_id::text;
    elsif target_role = 'particular' then
      return '/particular/job-messages.html?conversation=' || conversation_id::text;
    else
      return '/admin/admin-notifications.html';
    end if;
  end if;

  if target_kind = 'application' then
    if target_role = 'student' then
      return '/student/etd-candidature-detail.html?application=' || application_id::text;
    elsif target_role = 'recruiter' then
      return '/recruiter/rec-candidat-detail.html?application=' || application_id::text;
    elsif target_role = 'particular' then
      return '/particular/job-candidate-detail.html?application=' || application_id::text;
    else
      return '/admin/admin-applications.html?application=' || application_id::text;
    end if;
  end if;

  return null;
end;
$$;

create or replace function private.application_status_label(target_status public.application_status)
returns text
language sql
stable
security definer
set search_path = public
as $$
  select case target_status
    when 'submitted' then 'En examination'
    when 'under_review' then 'En examination'
    when 'shortlisted' then 'En examination'
    when 'interview_requested' then 'En examination'
    when 'interview_scheduled' then 'En examination'
    when 'accepted' then 'Accepté'
    when 'rejected' then 'Refusé'
    when 'withdrawn' then 'Retiré'
    when 'cancelled' then 'Annulé'
    else 'En examination'
  end;
$$;

create or replace function public.notify_application_created()
returns trigger
language plpgsql
security definer
set search_path = public, private
as $$
declare
  owner_user_id uuid;
  owner_role public.user_role;
  listing_title text;
  student_name text;
begin
  select p.full_name into student_name from public.profiles p where p.id = new.student_user_id;

  if new.listing_type = 'offer' then
    select o.created_by_recruiter_user_id, 'recruiter'::public.user_role, o.title
      into owner_user_id, owner_role, listing_title
    from public.offers o
    where o.id = new.offer_id;
  else
    select j.particular_user_id, 'particular'::public.user_role, j.title
      into owner_user_id, owner_role, listing_title
    from public.minute_jobs j
    where j.id = new.minute_job_id;
  end if;

  perform public.emit_unibox_notification(
    new.student_user_id,
    'application',
    'success',
    'Candidature envoyée',
    'Ta candidature UNIBOX pour « ' || coalesce(listing_title, 'cette annonce') || ' » a bien été envoyée.',
    'application',
    new.id,
    private.notification_url_for_role('student', 'application', new.id, null)
  );

  if owner_user_id is not null then
    perform public.emit_unibox_notification(
      owner_user_id,
      'application',
      'info',
      'Nouvelle candidature',
      coalesce(student_name, 'Un étudiant') || ' a postulé à « ' || coalesce(listing_title, 'ton annonce') || ' ».',
      'application',
      new.id,
      private.notification_url_for_role(owner_role, 'application', new.id, null)
    );
  end if;

  return new;
end;
$$;

drop trigger if exists trg_notify_application_created on public.applications;
create trigger trg_notify_application_created
after insert on public.applications
for each row execute function public.notify_application_created();

create or replace function public.notify_application_status_changed()
returns trigger
language plpgsql
security definer
set search_path = public, private
as $$
declare
  listing_title text;
  status_label text;
begin
  if old.status is not distinct from new.status then
    return new;
  end if;

  if new.listing_type = 'offer' then
    select title into listing_title from public.offers where id = new.offer_id;
  else
    select title into listing_title from public.minute_jobs where id = new.minute_job_id;
  end if;

  status_label := private.application_status_label(new.status);

  perform public.emit_unibox_notification(
    new.student_user_id,
    'application',
    case when new.status = 'accepted' then 'success' when new.status = 'rejected' then 'warning' else 'info' end,
    'Statut de candidature mis à jour',
    'Ta candidature pour « ' || coalesce(listing_title, 'cette annonce') || ' » est maintenant : ' || status_label || '.',
    'application',
    new.id,
    private.notification_url_for_role('student', 'application', new.id, null)
  );

  return new;
end;
$$;

drop trigger if exists trg_notify_application_status_changed on public.applications;
create trigger trg_notify_application_status_changed
after update on public.applications
for each row execute function public.notify_application_status_changed();

create or replace function public.notify_interview_created()
returns trigger
language plpgsql
security definer
set search_path = public, private
as $$
declare
  application_row public.applications%rowtype;
  listing_title text;
begin
  select * into application_row from public.applications where id = new.application_id;
  if application_row.id is null then
    return new;
  end if;

  if application_row.listing_type = 'offer' then
    select title into listing_title from public.offers where id = application_row.offer_id;
  else
    select title into listing_title from public.minute_jobs where id = application_row.minute_job_id;
  end if;

  perform public.emit_unibox_notification(
    application_row.student_user_id,
    'application',
    'info',
    'Entretien proposé',
    'Un entretien UNIBOX a été planifié pour « ' || coalesce(listing_title, 'cette annonce') || ' » le ' || to_char(new.scheduled_at at time zone 'UTC', 'DD/MM/YYYY HH24:MI') || '.',
    'application',
    application_row.id,
    private.notification_url_for_role('student', 'application', application_row.id, null)
  );

  return new;
end;
$$;

drop trigger if exists trg_notify_interview_created on public.interviews;
create trigger trg_notify_interview_created
after insert on public.interviews
for each row execute function public.notify_interview_created();

create or replace function public.notify_message_created()
returns trigger
language plpgsql
security definer
set search_path = public, private
as $$
declare
  sender_name text;
  participant record;
  conversation_row public.conversations%rowtype;
  participant_role public.user_role;
  message_preview text;
begin
  select * into conversation_row from public.conversations where id = new.conversation_id;
  select full_name into sender_name from public.profiles where id = new.sender_user_id;
  message_preview := coalesce(nullif(trim(coalesce(new.body, '')), ''), 'Tu as reçu un nouveau message sur UNIBOX.');

  for participant in
    select cp.user_id, p.role
    from public.conversation_participants cp
    join public.profiles p on p.id = cp.user_id
    where cp.conversation_id = new.conversation_id
      and cp.user_id <> new.sender_user_id
  loop
    participant_role := participant.role;
    perform public.emit_unibox_notification(
      participant.user_id,
      'message',
      'info',
      'Nouveau message',
      coalesce(sender_name, 'Un utilisateur') || ' t''a envoyé un message : ' || left(message_preview, 140),
      'conversation',
      new.conversation_id,
      private.notification_url_for_role(participant_role, 'message', conversation_row.application_id, new.conversation_id)
    );
  end loop;

  return new;
end;
$$;

drop trigger if exists trg_notify_message_created on public.messages;
create trigger trg_notify_message_created
after insert on public.messages
for each row execute function public.notify_message_created();

do $$
begin
  if exists (
    select 1 from information_schema.tables where table_schema = 'public' and table_name = 'reports'
  ) then
    execute $sql$
      create or replace function public.notify_report_created()
      returns trigger
      language plpgsql
      security definer
      set search_path = public, private
      as $fn$
      declare
        admin_row record;
      begin
        for admin_row in
          select p.id
          from public.profiles p
          where p.role = 'admin'
            and p.account_status = 'active'
        loop
          perform public.emit_unibox_notification(
            admin_row.id,
            'moderation',
            'warning',
            'Nouveau signalement',
            'Un nouveau signalement UNIBOX demande une vérification admin.',
            'report',
            new.id,
            '/admin/admin-reports.html?report=' || new.id::text
          );
        end loop;
        return new;
      end;
      $fn$;
    $sql$;

    execute 'drop trigger if exists trg_notify_report_created on public.reports';
    execute 'create trigger trg_notify_report_created after insert on public.reports for each row execute function public.notify_report_created()';
  end if;
end $$;

commit;
