create or replace function public.normalize_profile_activation()
returns trigger
language plpgsql
as $$
begin
  if new.role in ('student', 'recruiter', 'particular')
     and new.onboarding_completed = true
     and coalesce(old.onboarding_completed, false) = false
     and new.account_status = 'pending' then
    new.account_status = 'active';
  end if;

  return new;
end;
$$;

drop trigger if exists trg_profiles_normalize_activation on public.profiles;
create trigger trg_profiles_normalize_activation
before update on public.profiles
for each row execute function public.normalize_profile_activation();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  meta_role text;
  new_role public.user_role;
  full_name_value text;
begin
  meta_role := coalesce(new.raw_user_meta_data ->> 'role', 'student');
  full_name_value := coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1));

  if meta_role not in ('student', 'recruiter', 'particular') then
    meta_role := 'student';
  end if;

  new_role := meta_role::public.user_role;

  insert into public.profiles (
    id,
    role,
    full_name,
    email,
    account_status,
    onboarding_completed
  )
  values (
    new.id,
    new_role,
    full_name_value,
    new.email,
    'pending',
    false
  );

  if new_role = 'student' then
    insert into public.student_profiles (user_id) values (new.id);
  elsif new_role = 'recruiter' then
    insert into public.recruiter_profiles (user_id) values (new.id);
  elsif new_role = 'particular' then
    insert into public.particular_profiles (user_id) values (new.id);
  end if;

  insert into public.notification_preferences (user_id) values (new.id);

  return new;
end;
$$;
