create extension if not exists pgcrypto;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'report_target_type') THEN
    CREATE TYPE public.report_target_type AS ENUM ('offer', 'minute_job', 'profile', 'message', 'conversation', 'company');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'report_status') THEN
    CREATE TYPE public.report_status AS ENUM ('open', 'in_review', 'resolved', 'dismissed');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'moderation_case_status') THEN
    CREATE TYPE public.moderation_case_status AS ENUM ('open', 'investigating', 'resolved', 'closed');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'moderation_action_type') THEN
    CREATE TYPE public.moderation_action_type AS ENUM ('none', 'review_only', 'warn_user', 'restrict_account', 'suspend_account', 'hide_listing', 'remove_content');
  END IF;
END $$;

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  created_by_user_id uuid not null references public.profiles(id) on delete cascade,
  assigned_admin_user_id uuid references public.admin_profiles(user_id) on delete set null,
  target_type public.report_target_type not null,
  offer_id uuid references public.offers(id) on delete cascade,
  minute_job_id uuid references public.minute_jobs(id) on delete cascade,
  profile_id uuid references public.profiles(id) on delete cascade,
  message_id uuid references public.messages(id) on delete cascade,
  conversation_id uuid references public.conversations(id) on delete cascade,
  company_id uuid references public.companies(id) on delete cascade,
  reason_code text not null,
  description text,
  priority text not null default 'normal',
  status public.report_status not null default 'open',
  resolution_note text,
  resolved_at timestamptz,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  constraint reports_exactly_one_target check (
    ((offer_id is not null)::int +
     (minute_job_id is not null)::int +
     (profile_id is not null)::int +
     (message_id is not null)::int +
     (conversation_id is not null)::int +
     (company_id is not null)::int) = 1
  )
);

create table if not exists public.report_attachments (
  id uuid primary key default gen_random_uuid(),
  report_id uuid not null references public.reports(id) on delete cascade,
  uploaded_by_user_id uuid not null references public.profiles(id) on delete cascade,
  storage_bucket text not null default 'report-attachments',
  storage_path text not null,
  file_name text not null,
  mime_type text,
  file_size_bytes bigint,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.moderation_cases (
  id uuid primary key default gen_random_uuid(),
  report_id uuid not null references public.reports(id) on delete cascade,
  opened_by_admin_user_id uuid not null references public.admin_profiles(user_id) on delete cascade,
  assigned_admin_user_id uuid references public.admin_profiles(user_id) on delete set null,
  status public.moderation_case_status not null default 'open',
  action_type public.moderation_action_type not null default 'none',
  decision_note text,
  internal_note text,
  resolved_at timestamptz,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create index if not exists idx_reports_created_by_user on public.reports(created_by_user_id);
create index if not exists idx_reports_status_created on public.reports(status, created_at desc);
create index if not exists idx_reports_target_type on public.reports(target_type);
create index if not exists idx_moderation_cases_report on public.moderation_cases(report_id);
create index if not exists idx_moderation_cases_status_created on public.moderation_cases(status, created_at desc);
create index if not exists idx_report_attachments_report on public.report_attachments(report_id);

create trigger trg_reports_updated_at
before update on public.reports
for each row execute function public.set_updated_at();

create trigger trg_moderation_cases_updated_at
before update on public.moderation_cases
for each row execute function public.set_updated_at();

create or replace function private.notify_admins_on_report_insert()
returns trigger
language plpgsql
security definer
set search_path = public, private
as $$
declare
  admin_row record;
  title_text text;
  body_text text;
begin
  title_text := 'Nouveau signalement UNIBOX';
  body_text := coalesce('Motif : ' || NEW.reason_code, 'Un nouveau signalement attend une revue admin.');

  for admin_row in
    select id
    from public.profiles
    where role = 'admin'
      and account_status = 'active'
  loop
    insert into public.notifications(user_id, title, body, action_url)
    values (
      admin_row.id,
      title_text,
      body_text,
      '/admin/admin-reports.html'
    );
  end loop;

  return NEW;
end;
$$;

create or replace function private.sync_report_status_from_case()
returns trigger
language plpgsql
security definer
set search_path = public, private
as $$
begin
  if TG_OP = 'INSERT' then
    update public.reports
    set status = 'in_review',
        assigned_admin_user_id = coalesce(NEW.assigned_admin_user_id, opened_by_admin_user_id),
        updated_at = timezone('utc', now())
    where id = NEW.report_id
      and status = 'open';
    return NEW;
  end if;

  if NEW.status in ('resolved', 'closed') then
    update public.reports
    set status = case when NEW.status = 'resolved' then 'resolved' else status end,
        resolved_at = case when NEW.status = 'resolved' then coalesce(NEW.resolved_at, timezone('utc', now())) else resolved_at end,
        updated_at = timezone('utc', now())
    where id = NEW.report_id;
  elsif NEW.status in ('open', 'investigating') then
    update public.reports
    set status = 'in_review',
        updated_at = timezone('utc', now())
    where id = NEW.report_id
      and status in ('open', 'in_review');
  end if;

  return NEW;
end;
$$;

drop trigger if exists trg_reports_notify_admins on public.reports;
create trigger trg_reports_notify_admins
after insert on public.reports
for each row execute function private.notify_admins_on_report_insert();

drop trigger if exists trg_moderation_cases_sync_report_insert on public.moderation_cases;
create trigger trg_moderation_cases_sync_report_insert
after insert on public.moderation_cases
for each row execute function private.sync_report_status_from_case();

drop trigger if exists trg_moderation_cases_sync_report_update on public.moderation_cases;
create trigger trg_moderation_cases_sync_report_update
after update on public.moderation_cases
for each row execute function private.sync_report_status_from_case();

alter table public.reports enable row level security;
alter table public.report_attachments enable row level security;
alter table public.moderation_cases enable row level security;

drop policy if exists "reports_creator_or_admin_select" on public.reports;
create policy "reports_creator_or_admin_select"
on public.reports
for select
to authenticated
using (created_by_user_id = auth.uid() or private.is_admin());

drop policy if exists "reports_creator_insert" on public.reports;
create policy "reports_creator_insert"
on public.reports
for insert
to authenticated
with check (created_by_user_id = auth.uid());

drop policy if exists "reports_admin_update" on public.reports;
create policy "reports_admin_update"
on public.reports
for update
to authenticated
using (private.is_admin())
with check (private.is_admin());

drop policy if exists "report_attachments_creator_or_admin_select" on public.report_attachments;
create policy "report_attachments_creator_or_admin_select"
on public.report_attachments
for select
to authenticated
using (uploaded_by_user_id = auth.uid() or private.is_admin());

drop policy if exists "report_attachments_creator_insert" on public.report_attachments;
create policy "report_attachments_creator_insert"
on public.report_attachments
for insert
to authenticated
with check (uploaded_by_user_id = auth.uid() or private.is_admin());

drop policy if exists "report_attachments_creator_or_admin_delete" on public.report_attachments;
create policy "report_attachments_creator_or_admin_delete"
on public.report_attachments
for delete
to authenticated
using (uploaded_by_user_id = auth.uid() or private.is_admin());

drop policy if exists "moderation_cases_admin_only" on public.moderation_cases;
create policy "moderation_cases_admin_only"
on public.moderation_cases
for all
to authenticated
using (private.is_admin())
with check (private.is_admin());

-- Storage policies for report attachments if the bucket exists.
drop policy if exists "report_attachments_bucket_select" on storage.objects;
create policy "report_attachments_bucket_select"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'report-attachments'
  and (
    private.is_admin()
    or exists (
      select 1
      from public.report_attachments ra
      where ra.storage_bucket = bucket_id
        and ra.storage_path = name
        and ra.uploaded_by_user_id = auth.uid()
    )
  )
);

drop policy if exists "report_attachments_bucket_insert" on storage.objects;
create policy "report_attachments_bucket_insert"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'report-attachments'
  and auth.uid() is not null
);
