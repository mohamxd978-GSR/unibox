begin;

-- Supabase/Postgres may reject `create type if not exists ... as enum (...)`.
-- These blocks are idempotent and preserve the global result:
-- 1) create the enum when it does not exist
-- 2) add any missing enum values when it already exists

do $$
begin
  if not exists (
    select 1
    from pg_type t
    join pg_namespace n on n.oid = t.typnamespace
    where n.nspname = 'public'
      and t.typname = 'conversation_type'
  ) then
    create type public.conversation_type as enum ('application', 'support', 'moderation');
  else
    alter type public.conversation_type add value if not exists 'application';
    alter type public.conversation_type add value if not exists 'support';
    alter type public.conversation_type add value if not exists 'moderation';
  end if;
end
$$;

do $$
begin
  if not exists (
    select 1
    from pg_type t
    join pg_namespace n on n.oid = t.typnamespace
    where n.nspname = 'public'
      and t.typname = 'message_type'
  ) then
    create type public.message_type as enum ('text', 'system', 'attachment');
  else
    alter type public.message_type add value if not exists 'text';
    alter type public.message_type add value if not exists 'system';
    alter type public.message_type add value if not exists 'attachment';
  end if;
end
$$;

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  conversation_type public.conversation_type not null default 'application',
  application_id uuid references public.applications(id) on delete cascade,
  support_subject text,
  created_by_user_id uuid not null references public.profiles(id) on delete restrict,
  is_closed boolean not null default false,
  last_message_at timestamptz,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  constraint conversations_type_consistency check (
    (conversation_type = 'application' and application_id is not null)
    or (conversation_type in ('support', 'moderation'))
  )
);

create unique index if not exists uq_conversations_application_id
on public.conversations(application_id)
where application_id is not null;

create index if not exists idx_conversations_created_by_user_id on public.conversations(created_by_user_id);
create index if not exists idx_conversations_last_message_at on public.conversations(last_message_at desc nulls last);

drop trigger if exists trg_conversations_updated_at on public.conversations;
create trigger trg_conversations_updated_at
before update on public.conversations
for each row execute function public.set_updated_at();

create table if not exists public.conversation_participants (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  participant_role text,
  last_read_at timestamptz,
  is_muted boolean not null default false,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  constraint conversation_participants_unique unique (conversation_id, user_id)
);

create index if not exists idx_conversation_participants_user_id on public.conversation_participants(user_id);
create index if not exists idx_conversation_participants_conversation_id on public.conversation_participants(conversation_id);

drop trigger if exists trg_conversation_participants_updated_at on public.conversation_participants;
create trigger trg_conversation_participants_updated_at
before update on public.conversation_participants
for each row execute function public.set_updated_at();

create or replace function public.user_participates_in_conversation(target_conversation_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public, private
as $$
  select
    private.is_admin()
    or exists(
      select 1
      from public.conversation_participants cp
      where cp.conversation_id = target_conversation_id
        and cp.user_id = auth.uid()
    );
$$;

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_user_id uuid not null references public.profiles(id) on delete restrict,
  message_type public.message_type not null default 'text',
  body text,
  attachment_path text,
  sent_at timestamptz not null default timezone('utc', now()),
  edited_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  constraint messages_body_or_attachment check (
    (body is not null and length(trim(body)) > 0)
    or attachment_path is not null
  )
);

create index if not exists idx_messages_conversation_id on public.messages(conversation_id, sent_at);
create index if not exists idx_messages_sender_user_id on public.messages(sender_user_id);
create index if not exists idx_messages_deleted_at on public.messages(deleted_at);

drop trigger if exists trg_messages_updated_at on public.messages;
create trigger trg_messages_updated_at
before update on public.messages
for each row execute function public.set_updated_at();

create or replace function public.touch_conversation_after_message()
returns trigger
language plpgsql
security definer
set search_path = public, private
as $$
begin
  update public.conversations
  set last_message_at = new.sent_at,
      updated_at = timezone('utc', now())
  where id = new.conversation_id;

  return new;
end;
$$;

drop trigger if exists trg_messages_touch_conversation on public.messages;
create trigger trg_messages_touch_conversation
after insert on public.messages
for each row execute function public.touch_conversation_after_message();

alter table public.conversations enable row level security;
alter table public.conversation_participants enable row level security;
alter table public.messages enable row level security;

drop policy if exists "conversations_select_participant_or_admin" on public.conversations;
create policy "conversations_select_participant_or_admin"
on public.conversations
for select to authenticated
using (private.is_admin() or public.user_participates_in_conversation(id));

drop policy if exists "conversations_insert_creator_or_admin" on public.conversations;
create policy "conversations_insert_creator_or_admin"
on public.conversations
for insert to authenticated
with check (private.is_admin() or created_by_user_id = auth.uid());

drop policy if exists "conversations_update_participant_or_admin" on public.conversations;
create policy "conversations_update_participant_or_admin"
on public.conversations
for update to authenticated
using (private.is_admin() or public.user_participates_in_conversation(id))
with check (private.is_admin() or public.user_participates_in_conversation(id));

drop policy if exists "conversation_participants_select_relevant_or_admin" on public.conversation_participants;
create policy "conversation_participants_select_relevant_or_admin"
on public.conversation_participants
for select to authenticated
using (
  private.is_admin()
  or user_id = auth.uid()
  or public.user_participates_in_conversation(conversation_id)
);

drop policy if exists "conversation_participants_insert_creator_or_admin" on public.conversation_participants;
create policy "conversation_participants_insert_creator_or_admin"
on public.conversation_participants
for insert to authenticated
with check (
  private.is_admin()
  or exists (
    select 1
    from public.conversations c
    where c.id = conversation_id
      and c.created_by_user_id = auth.uid()
  )
);

drop policy if exists "conversation_participants_update_self_or_creator_or_admin" on public.conversation_participants;
create policy "conversation_participants_update_self_or_creator_or_admin"
on public.conversation_participants
for update to authenticated
using (
  private.is_admin()
  or user_id = auth.uid()
  or exists (
    select 1
    from public.conversations c
    where c.id = conversation_id
      and c.created_by_user_id = auth.uid()
  )
)
with check (
  private.is_admin()
  or user_id = auth.uid()
  or exists (
    select 1
    from public.conversations c
    where c.id = conversation_id
      and c.created_by_user_id = auth.uid()
  )
);

drop policy if exists "conversation_participants_delete_creator_or_admin" on public.conversation_participants;
create policy "conversation_participants_delete_creator_or_admin"
on public.conversation_participants
for delete to authenticated
using (
  private.is_admin()
  or exists (
    select 1
    from public.conversations c
    where c.id = conversation_id
      and c.created_by_user_id = auth.uid()
  )
);

drop policy if exists "messages_select_participant_or_admin" on public.messages;
create policy "messages_select_participant_or_admin"
on public.messages
for select to authenticated
using (private.is_admin() or public.user_participates_in_conversation(conversation_id));

drop policy if exists "messages_insert_sender_participant_or_admin" on public.messages;
create policy "messages_insert_sender_participant_or_admin"
on public.messages
for insert to authenticated
with check (
  private.is_admin()
  or (
    sender_user_id = auth.uid()
    and public.user_participates_in_conversation(conversation_id)
  )
);

drop policy if exists "messages_update_sender_or_admin" on public.messages;
create policy "messages_update_sender_or_admin"
on public.messages
for update to authenticated
using (private.is_admin() or sender_user_id = auth.uid())
with check (private.is_admin() or sender_user_id = auth.uid());

insert into storage.buckets (id, name, public)
values ('message-attachments', 'message-attachments', false)
on conflict (id) do nothing;

create or replace function public.extract_conversation_id_from_message_storage_path(object_name text)
returns uuid
language plpgsql
stable
security definer
set search_path = public, storage
as $$
declare
  raw_id text;
begin
  raw_id := (storage.foldername(object_name))[3];
  if raw_id is null or raw_id = '' then
    return null;
  end if;
  return raw_id::uuid;
exception when others then
  return null;
end;
$$;

drop policy if exists "message_attachments_select_authenticated" on storage.objects;
drop policy if exists "message_attachments_insert_authenticated" on storage.objects;

drop policy if exists message_attachments_select_participant_or_admin on storage.objects;
create policy message_attachments_select_participant_or_admin
on storage.objects
for select to authenticated
using (
  bucket_id = 'message-attachments'
  and (
    private.is_admin()
    or public.user_participates_in_conversation(public.extract_conversation_id_from_message_storage_path(name))
  )
);

drop policy if exists message_attachments_insert_participant on storage.objects;
create policy message_attachments_insert_participant
on storage.objects
for insert to authenticated
with check (
  bucket_id = 'message-attachments'
  and (storage.foldername(name))[1] = auth.uid()::text
  and (storage.foldername(name))[2] = 'messages'
  and public.user_participates_in_conversation(public.extract_conversation_id_from_message_storage_path(name))
);

commit;
