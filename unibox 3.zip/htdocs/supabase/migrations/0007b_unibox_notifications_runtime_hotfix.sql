begin;

create schema if not exists private;

create or replace function private.notification_type_enabled_for_user(
  target_user_id uuid,
  target_type public.notification_type
)
returns boolean
language plpgsql
stable
security definer
set search_path = public, private
as $$
declare
  prefs public.notification_preferences%rowtype;
  profile_row public.profiles%rowtype;
begin
  select * into profile_row
  from public.profiles
  where id = target_user_id;

  if profile_row.id is null then
    return false;
  end if;

  if profile_row.account_status = 'deleted' then
    return false;
  end if;

  select * into prefs
  from public.notification_preferences
  where user_id = target_user_id;

  if prefs.user_id is null then
    return true;
  end if;

  if prefs.in_app_enabled = false then
    return false;
  end if;

  if target_type = 'application' then
    return prefs.application_updates_enabled;
  elsif target_type = 'message' then
    return prefs.message_updates_enabled;
  elsif target_type in ('moderation', 'account') then
    return prefs.moderation_updates_enabled;
  end if;

  return true;
end;
$$;

create or replace function private.application_status_label(target_status public.application_status)
returns text
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  return case target_status
    when 'submitted' then 'En examination'
    when 'under_review' then 'En examination'
    when 'shortlisted' then 'En examination'
    when 'interview_requested' then 'En examination'
    when 'interview_scheduled' then 'En examination'
    when 'accepted' then 'Accepté'
    when 'rejected' then 'Refusé'
    when 'withdrawn' then 'Retiré'
    when 'cancelled' then 'Annulé'
    else 'En examination'
  end;
end;
$$;

create or replace function private.notification_url_for_role(
  target_role public.user_role,
  target_kind text,
  application_id uuid default null,
  conversation_id uuid default null
)
returns text
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if target_kind = 'message' then
    if target_role = 'student' then
      return '/student/etd-messagerie.html?conversation=' || conversation_id::text;
    elsif target_role = 'recruiter' then
      return '/recruiter/rec-message.html?conversation=' || conversation_id::text;
    elsif target_role = 'particular' then
      return '/particular/job-messages.html?conversation=' || conversation_id::text;
    else
      return '/admin/admin-notifications.html';
    end if;
  end if;

  if target_kind = 'application' then
    if target_role = 'student' then
      return '/student/etd-candidature-detail.html?application=' || application_id::text;
    elsif target_role = 'recruiter' then
      return '/recruiter/rec-candidat-detail.html?application=' || application_id::text;
    elsif target_role = 'particular' then
      return '/particular/job-candidate-detail.html?application=' || application_id::text;
    else
      return '/admin/admin-applications.html?application=' || application_id::text;
    end if;
  end if;

  return '/admin/admin-notifications.html';
end;
$$;

create or replace function public.emit_unibox_notification(
  p_user_id uuid,
  p_notification_type public.notification_type,
  p_level public.notification_level,
  p_title text,
  p_body text,
  p_target_type text default null,
  p_target_id uuid default null,
  p_action_url text default null
)
returns uuid
language plpgsql
security definer
set search_path = public, private
as $$
declare
  inserted_id uuid;
begin
  if p_user_id is null then
    return null;
  end if;

  if coalesce(trim(p_title), '') = '' or coalesce(trim(p_body), '') = '' then
    return null;
  end if;

  if not private.notification_type_enabled_for_user(p_user_id, p_notification_type) then
    return null;
  end if;

  insert into public.notifications (
    user_id,
    notification_type,
    level,
    title,
    body,
    target_type,
    target_id,
    action_url,
    is_read
  )
  values (
    p_user_id,
    p_notification_type,
    p_level,
    trim(p_title),
    trim(p_body),
    nullif(trim(coalesce(p_target_type, '')), ''),
    p_target_id,
    nullif(trim(coalesce(p_action_url, '')), ''),
    false
  )
  returning id into inserted_id;

  return inserted_id;
end;
$$;

commit;
