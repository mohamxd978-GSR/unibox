begin;

insert into storage.buckets (id, name, public)
values ('application-documents', 'application-documents', false)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('report-attachments', 'report-attachments', false)
on conflict (id) do nothing;

do $$
declare
  offer_has_hidden_reason boolean;
  minute_job_has_hidden_reason boolean;
  listings_view_sql text;
begin
  select exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'offers'
      and column_name = 'hidden_reason'
  ) into offer_has_hidden_reason;

  select exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'minute_jobs'
      and column_name = 'hidden_reason'
  ) into minute_job_has_hidden_reason;

  listings_view_sql := format($view$
    create or replace view public.admin_listings_overview_view as
    select
      'offer'::text as listing_family,
      o.id as listing_id,
      o.status::text as listing_status,
      o.hidden_by_admin,
      %s as hidden_reason,
      o.title,
      o.contract_type as employment_type,
      o.city,
      o.country,
      o.address_text,
      c.id as company_id,
      c.name as company_name,
      p.full_name as owner_name,
      p.email as owner_email,
      o.created_at,
      o.updated_at,
      o.published_at
    from public.offers o
    left join public.companies c on c.id = o.company_id
    left join public.profiles p on p.id = o.created_by_recruiter_user_id

    union all

    select
      'minute_job'::text as listing_family,
      m.id as listing_id,
      m.status::text as listing_status,
      m.hidden_by_admin,
      %s as hidden_reason,
      m.title,
      null::text as employment_type,
      m.city,
      m.country,
      m.address_text,
      null::uuid as company_id,
      null::text as company_name,
      p.full_name as owner_name,
      p.email as owner_email,
      m.created_at,
      m.updated_at,
      m.published_at
    from public.minute_jobs m
    left join public.profiles p on p.id = m.particular_user_id;
  $view$,
    case when offer_has_hidden_reason then 'o.hidden_reason' else 'null::text' end,
    case when minute_job_has_hidden_reason then 'm.hidden_reason' else 'null::text' end
  );

  execute listings_view_sql;
end
$$;

create or replace view public.admin_applications_overview_view as
select
  a.id as application_id,
  a.status::text as application_status,
  a.submitted_at,
  a.last_status_at,
  a.student_user_id,
  student.full_name as student_full_name,
  student.email as student_email,
  case
    when a.offer_id is not null then 'offer'
    when a.minute_job_id is not null then 'minute_job'
    else 'unknown'
  end as target_family,
  coalesce(o.title, m.title) as target_title,
  o.id as offer_id,
  m.id as minute_job_id,
  c.name as company_name,
  recruiter.full_name as recruiter_full_name,
  owner.full_name as particular_full_name
from public.applications a
left join public.profiles student on student.id = a.student_user_id
left join public.offers o on o.id = a.offer_id
left join public.minute_jobs m on m.id = a.minute_job_id
left join public.companies c on c.id = o.company_id
left join public.profiles recruiter on recruiter.id = o.created_by_recruiter_user_id
left join public.profiles owner on owner.id = m.particular_user_id;

comment on view public.admin_listings_overview_view is 'Vue admin UNIBOX consolidée pour toutes les offres et tous les job minutes.';
comment on view public.admin_applications_overview_view is 'Vue admin UNIBOX consolidée pour toutes les candidatures et leur cible.';

commit;
