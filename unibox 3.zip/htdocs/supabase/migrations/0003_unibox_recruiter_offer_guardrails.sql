-- UNIBOX · Bloc 4
-- Renforce la cohérence recruteur/entreprise/offres.

begin;

update public.offers
set contract_type = case lower(trim(contract_type))
  when 'stage' then 'stage'
  when 'internship' then 'stage'
  when 'intern' then 'stage'
  when 'part time' then 'part-time'
  when 'part-time' then 'part-time'
  when 'parttime' then 'part-time'
  when 'temps partiel' then 'part-time'
  when 'mi-temps' then 'part-time'
  when 'full time' then 'full-time'
  when 'full-time' then 'full-time'
  when 'fulltime' then 'full-time'
  when 'temps plein' then 'full-time'
  else null
end
where contract_type is not null;

alter table public.offers
  drop constraint if exists offers_contract_type_allowed;

alter table public.offers
  add constraint offers_contract_type_allowed
  check (contract_type in ('stage', 'part-time', 'full-time'));

create or replace function public.validate_offer_business_requirements()
returns trigger
language plpgsql
security definer
set search_path = public, private
as $$
begin
  if new.contract_type is null or btrim(new.contract_type) = '' then
    raise exception 'offers.contract_type is required and must be stage, part-time or full-time';
  end if;

  if new.contract_type not in ('stage', 'part-time', 'full-time') then
    raise exception 'offers.contract_type must be stage, part-time or full-time';
  end if;

  if new.address_text is null or btrim(new.address_text) = '' then
    raise exception 'offers.address_text is required';
  end if;

  if new.city is null or btrim(new.city) = '' then
    raise exception 'offers.city is required';
  end if;

  if new.country is null or btrim(new.country) = '' then
    raise exception 'offers.country is required';
  end if;

  if new.status = 'published' then
    if not exists (
      select 1
      from public.companies c
      where c.id = new.company_id
        and c.hidden_by_admin = false
        and c.status = 'active'
    ) then
      raise exception 'published offers must belong to an active visible company';
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_offers_validate_business_requirements on public.offers;
create trigger trg_offers_validate_business_requirements
before insert or update on public.offers
for each row execute function public.validate_offer_business_requirements();

drop policy if exists "company_logos_insert_admin_only" on storage.objects;
create policy "company_logos_insert_owner_or_admin"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'company-logos'
  and (
    private.is_admin()
    or (storage.foldername(name))[1] = auth.uid()::text
  )
);

drop policy if exists "company_logos_update_owner_or_admin" on storage.objects;
create policy "company_logos_update_owner_or_admin"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'company-logos'
  and (
    private.is_admin()
    or (storage.foldername(name))[1] = auth.uid()::text
  )
)
with check (
  bucket_id = 'company-logos'
  and (
    private.is_admin()
    or (storage.foldername(name))[1] = auth.uid()::text
  )
);

drop policy if exists "company_logos_delete_owner_or_admin" on storage.objects;
create policy "company_logos_delete_owner_or_admin"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'company-logos'
  and (
    private.is_admin()
    or (storage.foldername(name))[1] = auth.uid()::text
  )
);

commit;
