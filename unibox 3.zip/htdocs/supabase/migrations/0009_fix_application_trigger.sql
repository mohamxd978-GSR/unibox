-- Fix: le trigger ne doit bloquer que les INSERT (création de candidature),
-- pas les UPDATE (acceptation/rejet par le particulier/admin).
-- Avant : trigger on BEFORE INSERT OR UPDATE
-- Après : trigger on BEFORE INSERT ONLY

drop trigger if exists trg_applications_validate_integrity on public.applications;

create trigger trg_applications_validate_integrity
before insert on public.applications
for each row execute function public.validate_application_integrity();
