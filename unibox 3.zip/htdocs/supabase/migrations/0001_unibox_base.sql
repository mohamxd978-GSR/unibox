create extension if not exists pgcrypto;

create schema if not exists private;

do $$
begin
  if not exists (select 1 from pg_type where typname = 'user_role') then
    create type public.user_role as enum ('student', 'recruiter', 'particular', 'admin');
  end if;

  if not exists (select 1 from pg_type where typname = 'account_status') then
    create type public.account_status as enum ('pending', 'active', 'restricted', 'suspended', 'deleted');
  end if;

  if not exists (select 1 from pg_type where typname = 'notification_type') then
    create type public.notification_type as enum ('application', 'message', 'listing', 'system', 'moderation', 'account');
  end if;

  if not exists (select 1 from pg_type where typname = 'notification_level') then
    create type public.notification_level as enum ('info', 'success', 'warning', 'error');
  end if;
end $$;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = timezone('utc', now());
  return new;
end;
$$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.user_role not null,
  full_name text not null,
  email text not null,
  avatar_path text,
  phone text,
  city text,
  country text,
  account_status public.account_status not null default 'pending',
  onboarding_completed boolean not null default false,
  is_verified boolean not null default false,
  last_login_at timestamptz,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.student_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  school_name text,
  study_level text,
  headline text,
  bio text,
  availability_text text,
  skills text[] not null default '{}',
  cv_path text,
  portfolio_visibility boolean not null default true,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.recruiter_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  job_title text,
  bio text,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.particular_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  bio text,
  trust_score numeric(4,2) not null default 0,
  completed_jobs_count integer not null default 0,
  rating_avg numeric(3,2) not null default 0,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.admin_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  access_level text not null default 'ops_admin',
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.notification_preferences (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  email_enabled boolean not null default true,
  in_app_enabled boolean not null default true,
  marketing_enabled boolean not null default false,
  application_updates_enabled boolean not null default true,
  message_updates_enabled boolean not null default true,
  moderation_updates_enabled boolean not null default true,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  notification_type public.notification_type not null,
  level public.notification_level not null default 'info',
  title text not null,
  body text not null,
  target_type text,
  target_id uuid,
  action_url text,
  is_read boolean not null default false,
  read_at timestamptz,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.admin_audit_logs (
  id uuid primary key default gen_random_uuid(),
  admin_user_id uuid not null references public.admin_profiles(user_id) on delete cascade,
  action_type text not null,
  target_table text,
  target_id uuid,
  detail jsonb not null default '{}'::jsonb,
  ip_address inet,
  user_agent text,
  created_at timestamptz not null default timezone('utc', now())
);

create index if not exists idx_profiles_role on public.profiles(role);
create index if not exists idx_profiles_status on public.profiles(account_status);
create index if not exists idx_student_profiles_school on public.student_profiles(school_name);
create index if not exists idx_student_profiles_skills on public.student_profiles using gin(skills);
create index if not exists idx_notifications_user_read_created on public.notifications(user_id, is_read, created_at desc);
create index if not exists idx_admin_audit_logs_created on public.admin_audit_logs(created_at desc);

create trigger trg_profiles_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

create trigger trg_student_profiles_updated_at
before update on public.student_profiles
for each row execute function public.set_updated_at();

create trigger trg_recruiter_profiles_updated_at
before update on public.recruiter_profiles
for each row execute function public.set_updated_at();

create trigger trg_particular_profiles_updated_at
before update on public.particular_profiles
for each row execute function public.set_updated_at();

create trigger trg_notification_preferences_updated_at
before update on public.notification_preferences
for each row execute function public.set_updated_at();

create or replace function private.current_user_role()
returns public.user_role
language sql
stable
security definer
set search_path = public
as $$
  select role
  from public.profiles
  where id = auth.uid()
$$;

create or replace function private.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1
    from public.profiles
    where id = auth.uid()
      and role = 'admin'
      and account_status = 'active'
  )
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  meta_role text;
  new_role public.user_role;
  full_name_value text;
begin
  meta_role := coalesce(new.raw_user_meta_data ->> 'role', 'student');
  full_name_value := coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1));

  if meta_role not in ('student', 'recruiter', 'particular', 'admin') then
    meta_role := 'student';
  end if;

  new_role := meta_role::public.user_role;

  insert into public.profiles (
    id,
    role,
    full_name,
    email,
    account_status,
    onboarding_completed
  )
  values (
    new.id,
    new_role,
    full_name_value,
    new.email,
    case when new_role = 'admin' then 'active' else 'pending' end,
    false
  );

  if new_role = 'student' then
    insert into public.student_profiles (user_id) values (new.id);
  elsif new_role = 'recruiter' then
    insert into public.recruiter_profiles (user_id) values (new.id);
  elsif new_role = 'particular' then
    insert into public.particular_profiles (user_id) values (new.id);
  elsif new_role = 'admin' then
    insert into public.admin_profiles (user_id, access_level) values (new.id, 'ops_admin');
  end if;

  insert into public.notification_preferences (user_id) values (new.id);

  return new;
end;
$$;

drop trigger if exists on_auth_user_created_unibox on auth.users;
create trigger on_auth_user_created_unibox
after insert on auth.users
for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.student_profiles enable row level security;
alter table public.recruiter_profiles enable row level security;
alter table public.particular_profiles enable row level security;
alter table public.admin_profiles enable row level security;
alter table public.notification_preferences enable row level security;
alter table public.notifications enable row level security;
alter table public.admin_audit_logs enable row level security;

drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin"
on public.profiles
for select
to authenticated
using (id = auth.uid() or private.is_admin());

drop policy if exists "profiles_update_own_or_admin" on public.profiles;
create policy "profiles_update_own_or_admin"
on public.profiles
for update
to authenticated
using (id = auth.uid() or private.is_admin())
with check (id = auth.uid() or private.is_admin());

drop policy if exists "student_profiles_select_own_or_admin" on public.student_profiles;
create policy "student_profiles_select_own_or_admin"
on public.student_profiles
for select
to authenticated
using (user_id = auth.uid() or private.is_admin());

drop policy if exists "student_profiles_update_own_or_admin" on public.student_profiles;
create policy "student_profiles_update_own_or_admin"
on public.student_profiles
for update
to authenticated
using (user_id = auth.uid() or private.is_admin())
with check (user_id = auth.uid() or private.is_admin());

drop policy if exists "recruiter_profiles_select_own_or_admin" on public.recruiter_profiles;
create policy "recruiter_profiles_select_own_or_admin"
on public.recruiter_profiles
for select
to authenticated
using (user_id = auth.uid() or private.is_admin());

drop policy if exists "recruiter_profiles_update_own_or_admin" on public.recruiter_profiles;
create policy "recruiter_profiles_update_own_or_admin"
on public.recruiter_profiles
for update
to authenticated
using (user_id = auth.uid() or private.is_admin())
with check (user_id = auth.uid() or private.is_admin());

drop policy if exists "particular_profiles_select_own_or_admin" on public.particular_profiles;
create policy "particular_profiles_select_own_or_admin"
on public.particular_profiles
for select
to authenticated
using (user_id = auth.uid() or private.is_admin());

drop policy if exists "particular_profiles_update_own_or_admin" on public.particular_profiles;
create policy "particular_profiles_update_own_or_admin"
on public.particular_profiles
for update
to authenticated
using (user_id = auth.uid() or private.is_admin())
with check (user_id = auth.uid() or private.is_admin());

drop policy if exists "admin_profiles_admin_only" on public.admin_profiles;
create policy "admin_profiles_admin_only"
on public.admin_profiles
for all
to authenticated
using (private.is_admin())
with check (private.is_admin());

drop policy if exists "notification_preferences_own_or_admin" on public.notification_preferences;
create policy "notification_preferences_own_or_admin"
on public.notification_preferences
for all
to authenticated
using (user_id = auth.uid() or private.is_admin())
with check (user_id = auth.uid() or private.is_admin());

drop policy if exists "notifications_select_own_or_admin" on public.notifications;
create policy "notifications_select_own_or_admin"
on public.notifications
for select
to authenticated
using (user_id = auth.uid() or private.is_admin());

drop policy if exists "notifications_update_own_or_admin" on public.notifications;
create policy "notifications_update_own_or_admin"
on public.notifications
for update
to authenticated
using (user_id = auth.uid() or private.is_admin())
with check (user_id = auth.uid() or private.is_admin());

drop policy if exists "notifications_insert_admin_only" on public.notifications;
create policy "notifications_insert_admin_only"
on public.notifications
for insert
to authenticated
with check (private.is_admin());

drop policy if exists "admin_audit_logs_admin_only" on public.admin_audit_logs;
create policy "admin_audit_logs_admin_only"
on public.admin_audit_logs
for all
to authenticated
using (private.is_admin())
with check (private.is_admin());

insert into storage.buckets (id, name, public)
values
  ('avatars', 'avatars', false),
  ('student-cvs', 'student-cvs', false),
  ('student-portfolio', 'student-portfolio', false),
  ('company-logos', 'company-logos', false),
  ('report-attachments', 'report-attachments', false),
  ('message-attachments', 'message-attachments', false)
on conflict (id) do nothing;

drop policy if exists "avatars_select_own_or_admin" on storage.objects;
create policy "avatars_select_own_or_admin"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'avatars'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or private.is_admin()
  )
);

drop policy if exists "avatars_insert_own_or_admin" on storage.objects;
create policy "avatars_insert_own_or_admin"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'avatars'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or private.is_admin()
  )
);

drop policy if exists "avatars_update_own_or_admin" on storage.objects;
create policy "avatars_update_own_or_admin"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'avatars'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or private.is_admin()
  )
)
with check (
  bucket_id = 'avatars'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or private.is_admin()
  )
);

drop policy if exists "student_cvs_select_own_or_admin" on storage.objects;
create policy "student_cvs_select_own_or_admin"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'student-cvs'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or private.is_admin()
  )
);

drop policy if exists "student_cvs_insert_own_or_admin" on storage.objects;
create policy "student_cvs_insert_own_or_admin"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'student-cvs'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or private.is_admin()
  )
);

drop policy if exists "student_portfolio_select_own_or_admin" on storage.objects;
create policy "student_portfolio_select_own_or_admin"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'student-portfolio'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or private.is_admin()
  )
);

drop policy if exists "student_portfolio_insert_own_or_admin" on storage.objects;
create policy "student_portfolio_insert_own_or_admin"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'student-portfolio'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or private.is_admin()
  )
);

drop policy if exists "company_logos_select_authenticated_or_admin" on storage.objects;
create policy "company_logos_select_authenticated_or_admin"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'company-logos'
);

drop policy if exists "company_logos_insert_admin_only" on storage.objects;
create policy "company_logos_insert_admin_only"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'company-logos'
  and private.is_admin()
);

drop policy if exists "report_attachments_select_admin_only" on storage.objects;
create policy "report_attachments_select_admin_only"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'report-attachments'
  and private.is_admin()
);

drop policy if exists "report_attachments_insert_authenticated" on storage.objects;
create policy "report_attachments_insert_authenticated"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'report-attachments'
);

drop policy if exists "message_attachments_select_authenticated" on storage.objects;
create policy "message_attachments_select_authenticated"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'message-attachments'
);

drop policy if exists "message_attachments_insert_authenticated" on storage.objects;
create policy "message_attachments_insert_authenticated"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'message-attachments'
);
