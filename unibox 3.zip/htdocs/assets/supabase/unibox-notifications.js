import { supabase } from '/assets/supabase/supabase-client.js';
import { requireProfile, getRange } from '/assets/supabase/unibox-service-helpers.js';
import { SUPABASE_CONFIG } from '/assets/supabase/supabase-config.js';

function normalizeNotificationType(value = 'system') {
  const allowed = new Set(['application', 'message', 'listing', 'system', 'moderation', 'account']);
  return allowed.has(value) ? value : 'system';
}

function normalizeNotificationLevel(value = 'info') {
  const allowed = new Set(['info', 'success', 'warning', 'error']);
  return allowed.has(value) ? value : 'info';
}

function cleanNotificationRow(row = {}) {
  return {
    userId: row.userId,
    notificationType: normalizeNotificationType(row.notificationType || 'system'),
    level: normalizeNotificationLevel(row.level || 'info'),
    title: String(row.title || '').trim(),
    body: String(row.body || '').trim(),
    targetType: row.targetType || null,
    targetId: row.targetId || null,
    actionUrl: row.actionUrl || null,
  };
}

export async function listMyNotifications({
  unreadOnly = false,
  page = 1,
  pageSize = SUPABASE_CONFIG.defaults.notificationPageSize,
  notificationTypes = [],
} = {}) {
  const profile = await requireProfile();
  const range = getRange(page, pageSize);

  let query = supabase
    .from('notifications')
    .select('*', { count: 'exact' })
    .eq('user_id', profile.id)
    .order('created_at', { ascending: false });

  if (unreadOnly) query = query.eq('is_read', false);
  if (Array.isArray(notificationTypes) && notificationTypes.length) {
    query = query.in('notification_type', notificationTypes.map((value) => normalizeNotificationType(value)));
  }

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;

  return {
    data: data || [],
    count: count || 0,
    page: range.page,
    pageSize: range.pageSize,
  };
}

export async function getUnreadNotificationCount() {
  const profile = await requireProfile();

  const { count, error } = await supabase
    .from('notifications')
    .select('id', { head: true, count: 'exact' })
    .eq('user_id', profile.id)
    .eq('is_read', false);

  if (error) throw error;
  return count || 0;
}

export async function markNotificationRead(notificationId) {
  const { data, error } = await supabase
    .from('notifications')
    .update({
      is_read: true,
      read_at: new Date().toISOString(),
    })
    .eq('id', notificationId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function markAllMyNotificationsRead() {
  const profile = await requireProfile();

  const { data, error } = await supabase
    .from('notifications')
    .update({
      is_read: true,
      read_at: new Date().toISOString(),
    })
    .eq('user_id', profile.id)
    .eq('is_read', false)
    .select();

  if (error) throw error;
  return data || [];
}

export async function createNotification({
  userId,
  notificationType = 'system',
  level = 'info',
  title,
  body,
  targetType = null,
  targetId = null,
  actionUrl = null,
}) {
  const row = cleanNotificationRow({ userId, notificationType, level, title, body, targetType, targetId, actionUrl });
  if (!row.userId) throw new Error('userId requis.');
  if (!row.title || !row.body) throw new Error('Titre et body sont obligatoires.');

  const { data, error } = await supabase.rpc('emit_unibox_notification', {
    p_user_id: row.userId,
    p_notification_type: row.notificationType,
    p_level: row.level,
    p_title: row.title,
    p_body: row.body,
    p_target_type: row.targetType,
    p_target_id: row.targetId,
    p_action_url: row.actionUrl,
  });

  if (error) throw error;
  return data || null;
}

export async function createBulkNotifications(notificationRows = []) {
  if (!Array.isArray(notificationRows) || !notificationRows.length) return [];

  const results = [];
  for (const rawRow of notificationRows) {
    const row = cleanNotificationRow(rawRow);
    if (!row.userId || !row.title || !row.body) continue;
    const insertedId = await createNotification(row);
    results.push(insertedId);
  }
  return results;
}
