import {
  listParticularJobs as listJobs,
  getParticularJob,
  createParticularJob,
  updateParticularJob,
  publishParticularJob,
  closeParticularJob,
  pauseParticularJob,
  completeParticularJob,
  archiveParticularJob,
  duplicateParticularJob,
  deleteParticularJob,
} from '/assets/supabase/unibox-minute-jobs.js';
import {
  listParticularApplications as listApplications,
  getApplication,
  updateApplicationStatus,
  selectMinuteJobCandidate,
} from '/assets/supabase/unibox-applications.js';
import {
  listMyNotifications,
  markNotificationRead,
  markAllMyNotificationsRead,
} from '/assets/supabase/unibox-notifications.js';
import {
  listConversationInbox,
  listConversationParticipants,
  listMyConversations,
  getOrCreateApplicationConversation,
  markConversationRead,
} from '/assets/supabase/unibox-conversations.js';
import {
  listMessages,
  sendMessage,
  sendMessageWithAttachment,
} from '/assets/supabase/unibox-messages.js';
import {
  updateProfileBase,
  updateCurrentRoleProfile,
  getCurrentProfile,
} from '/assets/supabase/unibox-profile.js';

export async function listParticularJobs(options = {}) {
  const result = await listJobs(options);
  return result.data;
}

export async function listParticularJobsPaginated(options = {}) {
  return listJobs(options);
}

export {
  getParticularJob,
  createParticularJob,
  updateParticularJob,
  publishParticularJob,
  closeParticularJob,
  pauseParticularJob,
  completeParticularJob,
  archiveParticularJob,
  duplicateParticularJob,
  deleteParticularJob,
};

export async function listParticularApplications(options = {}) {
  const result = await listApplications(options);
  return result.data;
}

export async function getParticularApplicationDetail(applicationId) {
  return getApplication(applicationId);
}

export async function updateParticularApplicationStatus(applicationId, status) {
  return updateApplicationStatus(applicationId, status);
}

export async function selectParticularCandidate(jobId, applicationId) {
  return selectMinuteJobCandidate(jobId, applicationId);
}

export async function listParticularNotifications() {
  const result = await listMyNotifications();
  return result.data;
}

export async function markParticularNotificationRead(notificationId) {
  return markNotificationRead(notificationId);
}

export async function markAllParticularNotificationsRead() {
  return markAllMyNotificationsRead();
}

export async function listParticularConversations() {
  const result = await listConversationInbox();
  return result.data;
}

export async function listParticularRawConversations() {
  const result = await listMyConversations();
  return result.data;
}

export async function getOrCreateParticularApplicationConversation(applicationId) {
  return getOrCreateApplicationConversation(applicationId);
}

export async function listParticularConversationParticipants(conversationId) {
  return listConversationParticipants(conversationId);
}

export async function markParticularConversationRead(conversationId) {
  return markConversationRead(conversationId);
}

export async function listParticularMessages(conversationId) {
  const result = await listMessages(conversationId);
  return result.data;
}

export async function sendParticularMessage({ conversationId, body, attachmentPath = null }) {
  return sendMessage({ conversationId, body, attachmentPath });
}

export async function sendParticularMessageWithAttachment({ conversationId, body, file }) {
  return sendMessageWithAttachment({ conversationId, body, file });
}

export async function updateParticularProfile(patch = {}) {
  const basePatch = {
    full_name: patch.full_name,
    phone: patch.phone,
    city: patch.city,
    country: patch.country,
    avatar_path: patch.avatar_path || null,
  };

  const rolePatch = {
    bio: patch.bio,
  };

  const profile = await getCurrentProfile();
  if (!profile) throw new Error('Utilisateur non connecté.');

  await updateProfileBase(basePatch);
  return updateCurrentRoleProfile(rolePatch);
}
