import { supabase } from '/assets/supabase/supabase-client.js';
import { requireProfile, trimToNull, normalizeTextArray, getRange, cleanRecord, toNumberOrNull } from '/assets/supabase/unibox-service-helpers.js';

function buildPortfolioPayload(payload = {}) {
  return cleanRecord({
    item_type: payload.itemType ?? payload.item_type,
    title: trimToNull(payload.title),
    description: trimToNull(payload.description),
    external_url: trimToNull(payload.externalUrl ?? payload.external_url),
    media_path: trimToNull(payload.mediaPath ?? payload.media_path),
    organization_name: trimToNull(payload.organizationName ?? payload.organization_name),
    skills: normalizeTextArray(payload.skills),
    starts_on: payload.startsOn ?? payload.starts_on ?? undefined,
    ends_on: payload.endsOn ?? payload.ends_on ?? undefined,
    is_visible: payload.isVisible ?? payload.is_visible,
    sort_order: toNumberOrNull(payload.sortOrder ?? payload.sort_order),
  });
}

export async function listStudentPortfolioItems({ visibleOnly = false, page = 1, pageSize = 50 } = {}) {
  const profile = await requireProfile(['student']);
  const range = getRange(page, pageSize);

  let query = supabase
    .from('student_portfolio_items')
    .select('*', { count: 'exact' })
    .eq('student_user_id', profile.id)
    .order('sort_order', { ascending: true })
    .order('created_at', { ascending: false });

  if (visibleOnly) query = query.eq('is_visible', true);

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;

  return {
    data: data || [],
    count: count || 0,
    page: range.page,
    pageSize: range.pageSize,
  };
}

export async function createStudentPortfolioItem(payload = {}) {
  const profile = await requireProfile(['student']);
  const record = buildPortfolioPayload(payload);

  if (!record.title) throw new Error('Le titre de l’élément portfolio est obligatoire.');

  const { data, error } = await supabase
    .from('student_portfolio_items')
    .insert({
      student_user_id: profile.id,
      ...record,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateStudentPortfolioItem(itemId, patch = {}) {
  const record = buildPortfolioPayload(patch);

  const { data, error } = await supabase
    .from('student_portfolio_items')
    .update({
      ...record,
      updated_at: new Date().toISOString(),
    })
    .eq('id', itemId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function deleteStudentPortfolioItem(itemId) {
  const { error } = await supabase
    .from('student_portfolio_items')
    .delete()
    .eq('id', itemId);

  if (error) throw error;
}

export async function reorderStudentPortfolioItems(itemIds = []) {
  const profile = await requireProfile(['student']);
  if (!Array.isArray(itemIds) || !itemIds.length) return [];

  const updates = itemIds.map((itemId, index) =>
    supabase
      .from('student_portfolio_items')
      .update({
        sort_order: index,
        updated_at: new Date().toISOString(),
      })
      .eq('id', itemId)
      .eq('student_user_id', profile.id)
  );

  const results = await Promise.all(updates);
  const firstError = results.find((result) => result.error)?.error;
  if (firstError) throw firstError;

  return listStudentPortfolioItems();
}
