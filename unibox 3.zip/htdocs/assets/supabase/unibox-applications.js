import { supabase } from '/assets/supabase/supabase-client.js';
import {
  requireProfile,
  getRange,
  cleanRecord,
  trimToNull,
} from '/assets/supabase/unibox-service-helpers.js';
import { uploadApplicationDocument, createSignedAssetUrl } from '/assets/supabase/unibox-storage.js';
import { STORAGE_BUCKETS } from '/assets/config/app.config.js';

function withPagePayload(data, count, page, pageSize) {
  return {
    data: data || [],
    count: count || 0,
    page,
    pageSize,
  };
}

async function attachSignedUrlsToDocuments(documents = []) {
  return Promise.all((documents || []).map(async (document) => {
    if (!document?.storage_path) return document;
    try {
      const signedUrl = await createSignedAssetUrl(document.storage_bucket || STORAGE_BUCKETS.applicationDocuments, document.storage_path);
      return { ...document, signed_url: signedUrl };
    } catch (_error) {
      return document;
    }
  }));
}

async function cleanupApplicationIfNeeded(applicationId) {
  if (!applicationId) return;
  await supabase.from('applications').delete().eq('id', applicationId).catch(() => null);
}

async function insertApplicationDocument({ applicationId, storagePath, file }) {
  const profile = await requireProfile();
  const { data, error } = await supabase
    .from('application_documents')
    .insert({
      application_id: applicationId,
      uploaded_by_user_id: profile.id,
      document_type: 'cv',
      storage_bucket: STORAGE_BUCKETS.applicationDocuments,
      storage_path: storagePath,
      file_name: file?.name || 'cv',
      mime_type: file?.type || null,
      file_size_bytes: file?.size || null,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

async function findExistingApplication({ studentUserId, offerId = null, minuteJobId = null }) {
  let query = supabase
    .from('applications')
    .select('id')
    .eq('student_user_id', studentUserId)
    .limit(1);

  if (offerId) query = query.eq('offer_id', offerId);
  if (minuteJobId) query = query.eq('minute_job_id', minuteJobId);

  const { data, error } = await query.maybeSingle();
  if (error) throw error;
  return data || null;
}

async function ensureApplicationCvDocument({ applicationId, cvFile, application }) {
  if (!cvFile) return application;

  const existingDocuments = application?.application_documents || [];
  if (existingDocuments.length > 0) return application;

  const storagePath = await uploadApplicationDocument(cvFile, applicationId);
  await insertApplicationDocument({ applicationId, storagePath, file: cvFile });
  return getApplication(applicationId);
}

async function createApplication({ listingType, offerId = null, minuteJobId = null, messageBody = '', cvFile = null }) {
  const profile = await requireProfile(['student']);
  if (!cvFile) throw new Error('Le CV est obligatoire pour postuler sur UNIBOX.');

  const existing = await findExistingApplication({
    studentUserId: profile.id,
    offerId,
    minuteJobId,
  });

  if (existing?.id) {
    const currentApplication = await getApplication(existing.id);
    const hydratedApplication = await ensureApplicationCvDocument({
      applicationId: existing.id,
      cvFile,
      application: currentApplication,
    });

    return {
      ...hydratedApplication,
      already_exists: true,
      reused_existing: true,
    };
  }

  const now = new Date().toISOString();
  let applicationId = null;

  try {
    const { data, error } = await supabase
      .from('applications')
      .insert({
        student_user_id: profile.id,
        listing_type: listingType,
        offer_id: offerId,
        minute_job_id: minuteJobId,
        message_body: trimToNull(messageBody),
        status: 'submitted',
        submitted_at: now,
        last_status_at: now,
      })
      .select()
      .single();

    if (error) {
      const duplicate = error?.code === '23505';
      if (duplicate) {
        const duplicateApplication = await findExistingApplication({
          studentUserId: profile.id,
          offerId,
          minuteJobId,
        });

        if (duplicateApplication?.id) {
          const currentApplication = await getApplication(duplicateApplication.id);
          const hydratedApplication = await ensureApplicationCvDocument({
            applicationId: duplicateApplication.id,
            cvFile,
            application: currentApplication,
          });

          return {
            ...hydratedApplication,
            already_exists: true,
            reused_existing: true,
          };
        }
      }
      throw error;
    }
    applicationId = data.id;

    const storagePath = await uploadApplicationDocument(cvFile, applicationId);
    await insertApplicationDocument({ applicationId, storagePath, file: cvFile });

    return getApplication(applicationId);
  } catch (error) {
    await cleanupApplicationIfNeeded(applicationId);
    throw error;
  }
}

export async function applyToListing({ listingType, listingId, messageBody = '', cvFile = null }) {
  if (listingType === 'offer') {
    return applyToOffer({ offerId: listingId, messageBody, cvFile });
  }
  if (listingType === 'minute_job') {
    return applyToMinuteJob({ minuteJobId: listingId, messageBody, cvFile });
  }
  throw new Error('listingType invalide.');
}

export async function applyToOffer({ offerId, messageBody = '', cvFile = null }) {
  if (!offerId) throw new Error('offerId requis.');
  return createApplication({ listingType: 'offer', offerId, messageBody, cvFile });
}

export async function applyToMinuteJob({ minuteJobId, messageBody = '', cvFile = null }) {
  if (!minuteJobId) throw new Error('minuteJobId requis.');
  return createApplication({ listingType: 'minute_job', minuteJobId, messageBody, cvFile });
}

export async function listStudentApplications({ status = null, page = 1, pageSize = 20 } = {}) {
  const profile = await requireProfile(['student']);
  const range = getRange(page, pageSize);

  let query = supabase
    .from('student_applications_view')
    .select(`
      *,
      interviews(id, scheduled_at, status, meeting_url, location_label),
      application_documents(id, file_name, mime_type, storage_bucket, storage_path)
    `, { count: 'exact' })
    .eq('student_user_id', profile.id)
    .order('submitted_at', { ascending: false });

  if (status) query = query.eq('status', status);

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;
  return withPagePayload(data, count, range.page, range.pageSize);
}

export async function listRecruiterApplications({ offerId = null, status = null, page = 1, pageSize = 20 } = {}) {
  const profile = await requireProfile(['recruiter']);
  const range = getRange(page, pageSize);

  let query = supabase
    .from('applications')
    .select(`
      *,
      offers!inner(id, title, city, created_by_recruiter_user_id, company_id, contract_type),
      interviews(id, scheduled_at, status, meeting_url, location_label),
      application_documents(id, file_name, mime_type, storage_bucket, storage_path)
    `, { count: 'exact' })
    .eq('offers.created_by_recruiter_user_id', profile.id)
    .order('submitted_at', { ascending: false });

  if (offerId) query = query.eq('offer_id', offerId);
  if (status) query = query.eq('status', status);

  const { data: applications, error, count } = await query.range(range.from, range.to);
  if (error) throw error;

  // Fetch student profiles via RPC (bypasses RLS)
  const studentUserIds = [...new Set(applications.map(a => a.student_user_id).filter(Boolean))];
  if (studentUserIds.length > 0) {
    const { data: studentProfiles, error: profileError } = await supabase
      .rpc('get_student_profiles_for_recruiter', { student_ids: studentUserIds });

    if (studentProfiles && studentProfiles.length > 0) {
      const profilesMap = new Map(studentProfiles.map(p => [p.user_id, p]));
      applications.forEach(app => {
        const profile = profilesMap.get(app.student_user_id);
        if (profile) {
          app.profiles = {
            id: profile.user_id,
            full_name: profile.full_name || 'Étudiant UNIBOX',
            email: profile.email,
            city: profile.city,
            avatar_path: profile.avatar_path
          };
        }
      });
    }
  }

  return withPagePayload(applications, count, range.page, range.pageSize);
}

export async function listParticularApplications({ minuteJobId = null, status = null, page = 1, pageSize = 20 } = {}) {
  const profile = await requireProfile(['particular']);
  const range = getRange(page, pageSize);

  let query = supabase
    .from('applications')
    .select(`
      *,
      minute_jobs:minute_jobs!applications_minute_job_id_fkey!inner(id, title, city, particular_user_id),
      profiles:student_user_id(id, full_name, email, city, avatar_path),
      interviews(id, scheduled_at, status, meeting_url, location_label),
      application_documents(id, file_name, mime_type, storage_bucket, storage_path)
    `, { count: 'exact' })
    .eq('minute_jobs.particular_user_id', profile.id)
    .order('submitted_at', { ascending: false });

  if (minuteJobId) query = query.eq('minute_job_id', minuteJobId);
  if (status) query = query.eq('status', status);

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;
  return withPagePayload(data, count, range.page, range.pageSize);
}

export async function listAdminApplications({ status = null, page = 1, pageSize = 30 } = {}) {
  await requireProfile(['admin']);
  const range = getRange(page, pageSize);

  let query = supabase
    .from('applications')
    .select(`
      *,
      offers:offers!applications_offer_id_fkey(id, title, city, company_id, contract_type),
      minute_jobs:minute_jobs!applications_minute_job_id_fkey(id, title, city),
      profiles:student_user_id(id, full_name, email, city, avatar_path),
      application_documents(id, file_name, mime_type, storage_bucket, storage_path)
    `, { count: 'exact' })
    .order('submitted_at', { ascending: false });

  if (status) query = query.eq('status', status);

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;
  return withPagePayload(data, count, range.page, range.pageSize);
}

export async function getApplication(applicationId) {
  const { data, error } = await supabase
    .from('applications')
    .select(`
      *,
      offers:offers!applications_offer_id_fkey(id, title, description, city, country, address_text, company_id, status, contract_type),
      minute_jobs:minute_jobs!applications_minute_job_id_fkey(id, title, description, city, country, address_text, particular_user_id, status),
      profiles:student_user_id(id, full_name, email, city, country, avatar_path),
      interviews(*),
      application_status_events(*),
      application_documents(*)
    `)
    .eq('id', applicationId)
    .single();

  if (error) throw error;

  const studentUserId = data?.student_user_id;
  let studentProfile = null;

  if (studentUserId) {
    const roleProfileResult = await supabase
      .from('student_profiles')
      .select('*')
      .eq('user_id', studentUserId)
      .maybeSingle();

    if (roleProfileResult.error) throw roleProfileResult.error;
    studentProfile = roleProfileResult.data ?? null;

    // Fetch student base profile via RPC (bypasses RLS)
    const { data: rpcProfiles, error: rpcError } = await supabase
      .rpc('get_student_profiles_for_recruiter', { student_ids: [studentUserId] });
    
    console.log('[DEBUG] getApplication RPC result:', rpcProfiles, rpcError);
    
    if (rpcError) {
      console.error('[DEBUG] RPC error:', rpcError.message);
    }
    
    if (rpcProfiles && rpcProfiles.length > 0) {
      data.profiles = {
        id: rpcProfiles[0].user_id,
        full_name: rpcProfiles[0].full_name,
        email: rpcProfiles[0].email,
        city: rpcProfiles[0].city,
        avatar_path: rpcProfiles[0].avatar_path
      };
    }
  }

  const documents = await attachSignedUrlsToDocuments(data?.application_documents || []);
  const statusEvents = [...(data?.application_status_events || [])].sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  const interviews = [...(data?.interviews || [])].sort((a, b) => new Date(a.scheduled_at) - new Date(b.scheduled_at));

  return {
    ...data,
    application_documents: documents,
    application_status_events: statusEvents,
    interviews,
    student_profile: studentProfile,
  };
}

export async function updateApplicationStatus(applicationId, status, extraPatch = {}) {
  const patch = cleanRecord({
    status,
    last_status_at: new Date().toISOString(),
    ...extraPatch,
  });

  const { data, error } = await supabase
    .from('applications')
    .update(patch)
    .eq('id', applicationId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function withdrawApplication(applicationId) {
  return updateApplicationStatus(applicationId, 'withdrawn');
}

export async function shortlistApplication(applicationId) {
  return updateApplicationStatus(applicationId, 'shortlisted');
}

export async function requestInterviewOnApplication(applicationId) {
  return updateApplicationStatus(applicationId, 'interview_requested');
}

export async function acceptApplication(applicationId) {
  return updateApplicationStatus(applicationId, 'accepted');
}

export async function rejectApplication(applicationId) {
  return updateApplicationStatus(applicationId, 'rejected');
}

export async function listApplicationStatusEvents(applicationId) {
  const { data, error } = await supabase
    .from('application_status_events')
    .select('*')
    .eq('application_id', applicationId)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return data || [];
}

export async function scheduleInterview({
  applicationId,
  scheduledAt,
  durationMinutes = 30,
  locationType = 'meet',
  meetingUrl = null,
  locationLabel = null,
  notes = '',
}) {
  const profile = await requireProfile(['recruiter', 'particular', 'admin']);

  const { data, error } = await supabase
    .from('interviews')
    .insert({
      application_id: applicationId,
      created_by_user_id: profile.id,
      scheduled_at: scheduledAt,
      duration_minutes: durationMinutes,
      location_type: locationType,
      meeting_url: meetingUrl,
      location_label: locationLabel,
      notes: trimToNull(notes),
      status: 'proposed',
    })
    .select()
    .single();

  if (error) throw error;

  await updateApplicationStatus(applicationId, 'interview_scheduled');
  return data;
}

export async function selectMinuteJobCandidate(jobId, applicationId) {
  // D'abord mettre à jour la candidature (le job est encore 'published', le trigger passe)
  await updateApplicationStatus(applicationId, 'accepted', {
    accepted_at: new Date().toISOString(),
  });

  // Puis fermer le job
  const { data, error } = await supabase
    .from('minute_jobs')
    .update({
      selected_application_id: applicationId,
      status: 'closed',
      updated_at: new Date().toISOString(),
    })
    .eq('id', jobId)
    .select()
    .single();

  if (error) throw error;

  return data;
}