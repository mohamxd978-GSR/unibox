import {
  listRecruiterOffers as listOffers,
  getRecruiterOffer,
  createRecruiterOffer,
  updateRecruiterOffer,
  publishRecruiterOffer,
  pauseRecruiterOffer,
  closeRecruiterOffer,
  duplicateRecruiterOffer,
} from '/assets/supabase/unibox-offers.js';
import {
  getCurrentRecruiterCompany,
  createRecruiterCompany,
  updateRecruiterCompany,
  upsertCurrentRecruiterCompany,
} from '/assets/supabase/unibox-companies.js';
import {
  listRecruiterApplications as listApplications,
  getApplication,
  updateApplicationStatus,
  scheduleInterview,
} from '/assets/supabase/unibox-applications.js';
import {
  listMyNotifications,
  markNotificationRead,
  markAllMyNotificationsRead,
} from '/assets/supabase/unibox-notifications.js';
import {
  listConversationInbox,
  listConversationParticipants,
  listMyConversations,
  getOrCreateApplicationConversation,
  markConversationRead,
} from '/assets/supabase/unibox-conversations.js';
import {
  listMessages,
  sendMessage,
  sendMessageWithAttachment,
} from '/assets/supabase/unibox-messages.js';
import {
  updateProfileBase,
  updateCurrentRoleProfile,
  getCurrentProfile,
} from '/assets/supabase/unibox-profile.js';

export async function listRecruiterOffers(options = {}) {
  const result = await listOffers(options);
  return result.data;
}

export {
  getRecruiterOffer,
  createRecruiterOffer,
  updateRecruiterOffer,
  publishRecruiterOffer,
  pauseRecruiterOffer,
  closeRecruiterOffer,
  duplicateRecruiterOffer,
  getCurrentRecruiterCompany,
  createRecruiterCompany,
  updateRecruiterCompany,
  upsertCurrentRecruiterCompany,
};

export async function listRecruiterApplications(options = {}) {
  const result = await listApplications(options);
  return result.data;
}

export async function getRecruiterCandidateDetail(applicationId) {
  return getApplication(applicationId);
}

export async function updateRecruiterApplicationStatus(applicationId, status, extraPatch = {}) {
  return updateApplicationStatus(applicationId, status, extraPatch);
}

export async function acceptRecruiterApplication(application) {
  if (!application?.id) throw new Error('applicationId requis.');

  const accepted = await updateApplicationStatus(application.id, 'accepted', {
    accepted_at: new Date().toISOString(),
  });

  if (application.offer_id || application.offers?.id) {
    const offerId = application.offer_id || application.offers?.id;
    await closeRecruiterOffer(offerId);
  }

  return accepted;
}

export async function scheduleRecruiterInterview(applicationId, payload) {
  return scheduleInterview({
    applicationId,
    scheduledAt: payload.scheduled_at || payload.scheduledAt,
    durationMinutes: payload.duration_minutes || payload.durationMinutes || 30,
    locationType: payload.location_type || payload.locationType || 'meet',
    meetingUrl: payload.meeting_url || payload.meetingUrl || null,
    locationLabel: payload.location_label || payload.locationLabel || null,
    notes: payload.notes || '',
  });
}

export async function listRecruiterNotifications() {
  const result = await listMyNotifications();
  return result.data;
}

export async function markRecruiterNotificationRead(notificationId) {
  return markNotificationRead(notificationId);
}

export async function markAllRecruiterNotificationsRead() {
  return markAllMyNotificationsRead();
}

export async function listRecruiterConversations() {
  const result = await listConversationInbox();
  return result.data;
}

export async function listRecruiterRawConversations() {
  const result = await listMyConversations();
  return result.data;
}

export async function getOrCreateRecruiterApplicationConversation(applicationId) {
  return getOrCreateApplicationConversation(applicationId);
}

export async function listRecruiterConversationParticipants(conversationId) {
  return listConversationParticipants(conversationId);
}

export async function markRecruiterConversationRead(conversationId) {
  return markConversationRead(conversationId);
}

export async function listRecruiterMessages(conversationId) {
  const result = await listMessages(conversationId);
  return result.data;
}

export async function sendRecruiterMessage({ conversationId, body, attachmentPath = null }) {
  return sendMessage({ conversationId, body, attachmentPath });
}

export async function sendRecruiterMessageWithAttachment({ conversationId, body, file }) {
  return sendMessageWithAttachment({ conversationId, body, file });
}

export async function updateRecruiterProfile(patch = {}) {
  const basePatch = {
    full_name: patch.full_name,
    phone: patch.phone,
    city: patch.city,
    country: patch.country,
    avatar_path: patch.avatar_path,
  };

  const rolePatch = {
    job_title: patch.job_title,
    bio: patch.bio,
    company_id: patch.company_id,
    company_role: patch.company_role,
  };

  const profile = await getCurrentProfile();
  if (!profile) throw new Error('Utilisateur non connecté.');

  await updateProfileBase(basePatch);
  return updateCurrentRoleProfile(rolePatch);
}
