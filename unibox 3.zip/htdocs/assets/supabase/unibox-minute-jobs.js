import { supabase } from '/assets/supabase/supabase-client.js';
import {
  requireRoleContext,
  buildMinuteJobWritePayload,
  ensureMinuteJobPublicationRequirements,
  getRange,
  trimToNull,
} from '/assets/supabase/unibox-service-helpers.js';

function buildMinuteJobQuery(profileId) {
  return supabase
    .from('minute_jobs')
    .select('*', { count: 'exact' })
    .eq('particular_user_id', profileId)
    .order('created_at', { ascending: false });
}

export async function listParticularJobs({ status = null, search = '', page = 1, pageSize = 20 } = {}) {
  const { profile } = await requireRoleContext('particular');
  const range = getRange(page, pageSize);

  let query = buildMinuteJobQuery(profile.id);

  if (status && status !== 'all') query = query.eq('status', status);
  if (search?.trim()) {
    const safeSearch = trimToNull(search);
    query = query.or(`title.ilike.%${safeSearch}%,summary.ilike.%${safeSearch}%,city.ilike.%${safeSearch}%`);
  }

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;

  return {
    data: data || [],
    count: count || 0,
    page: range.page,
    pageSize: range.pageSize,
  };
}

export async function getParticularJob(jobId) {
  const { profile } = await requireRoleContext('particular');

  const { data, error } = await supabase
    .from('minute_jobs')
    .select('*')
    .eq('id', jobId)
    .eq('particular_user_id', profile.id)
    .single();

  if (error) throw error;
  return data;
}

export async function createParticularJob(payload = {}) {
  const { profile } = await requireRoleContext('particular');
  const record = buildMinuteJobWritePayload(payload, {
    particularUserId: profile.id,
  });

  if (!record.title) throw new Error('Le titre de la mission est obligatoire.');
  if (!record.description) throw new Error('La description de la mission est obligatoire.');

  if (record.status === 'published') {
    ensureMinuteJobPublicationRequirements(record);
    record.published_at = new Date().toISOString();
  }

  const { data, error } = await supabase
    .from('minute_jobs')
    .insert(record)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateParticularJob(jobId, patch = {}) {
  const existing = await getParticularJob(jobId);
  const merged = {
    ...existing,
    ...patch,
  };

  const nextPatch = buildMinuteJobWritePayload(merged);
  const nextStatus = patch.status || existing.status;
  if (nextStatus === 'published') {
    ensureMinuteJobPublicationRequirements({
      ...existing,
      ...nextPatch,
      ...patch,
    });
  }

  const finalPatch = {
    ...nextPatch,
    updated_at: new Date().toISOString(),
  };

  if (nextStatus === 'published' && !existing.published_at) {
    finalPatch.published_at = new Date().toISOString();
  }

  if (nextStatus === 'closed' && !existing.closed_at) {
    finalPatch.closed_at = new Date().toISOString();
  }

  if (nextStatus === 'completed' && !existing.completed_at) {
    finalPatch.completed_at = new Date().toISOString();
  }

  const { data, error } = await supabase
    .from('minute_jobs')
    .update(finalPatch)
    .eq('id', jobId)
    .eq('particular_user_id', existing.particular_user_id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function publishParticularJob(jobId) {
  const existing = await getParticularJob(jobId);
  ensureMinuteJobPublicationRequirements(existing);

  return updateParticularJob(jobId, {
    status: 'published',
    published_at: existing.published_at || new Date().toISOString(),
  });
}

export async function pauseParticularJob(jobId) {
  return updateParticularJob(jobId, { status: 'paused' });
}

export async function closeParticularJob(jobId) {
  return updateParticularJob(jobId, {
    status: 'closed',
    closed_at: new Date().toISOString(),
  });
}

export async function completeParticularJob(jobId) {
  return updateParticularJob(jobId, {
    status: 'completed',
    completed_at: new Date().toISOString(),
  });
}

export async function archiveParticularJob(jobId) {
  return updateParticularJob(jobId, { status: 'archived' });
}

export async function duplicateParticularJob(jobId) {
  const source = await getParticularJob(jobId);
  return createParticularJob({
    ...source,
    title: `Copie · ${source.title}`,
    status: 'draft',
    published_at: null,
    completed_at: null,
    closed_at: null,
    selected_application_id: null,
  });
}

export async function deleteParticularJob(jobId) {
  const existing = await getParticularJob(jobId);

  const { error } = await supabase
    .from('minute_jobs')
    .delete()
    .eq('id', jobId)
    .eq('particular_user_id', existing.particular_user_id);

  if (error) throw error;
}
