import { supabase } from '/assets/supabase/supabase-client.js';
import { ROUTES } from '/assets/config/app.config.js';

export const ROLE_PROFILE_TABLES = {
  student: 'student_profiles',
  recruiter: 'recruiter_profiles',
  particular: 'particular_profiles',
  admin: 'admin_profiles',
};

export function cleanRecord(record = {}) {
  return Object.fromEntries(
    Object.entries(record).filter(([, value]) => value !== undefined)
  );
}

export async function getCurrentSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data.session ?? null;
}

export async function getAuthenticatedUser() {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw error;
  return data.user ?? null;
}

export async function getCurrentProfile() {
  const user = await getAuthenticatedUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from('profiles')
    .select(`
      id,
      role,
      full_name,
      email,
      phone,
      city,
      country,
      avatar_path,
      account_status,
      onboarding_completed,
      is_verified,
      last_login_at,
      created_at,
      updated_at
    `)
    .eq('id', user.id)
    .maybeSingle();

  if (error) throw error;
  return data ?? null;
}

export async function getRoleProfile(role, userId) {
  const table = ROLE_PROFILE_TABLES[role];
  if (!table) return null;

  const { data, error } = await supabase
    .from(table)
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();

  if (error) throw error;
  return data ?? null;
}

export async function getCurrentUserContext() {
  const profile = await getCurrentProfile();
  if (!profile) return null;

  const roleProfile = await getRoleProfile(profile.role, profile.id);
  return { profile, roleProfile };
}

export function getOnboardingRoute(role) {
  return ROUTES.onboarding[role] || null;
}

export function getRoleHomeRoute(profile) {
  if (!profile) return ROUTES.auth.login;

  if (['suspended', 'restricted', 'deleted'].includes(profile.account_status)) {
    return ROUTES.common.accessDenied;
  }

  const onboardingRoute = getOnboardingRoute(profile.role);
  if (!profile.onboarding_completed && onboardingRoute) {
    return onboardingRoute;
  }

  if (profile.account_status === 'pending') {
    return ROUTES.common.accountPending;
  }

  return ROUTES.dashboards[profile.role] || ROUTES.auth.login;
}

export function canAccessRole(profile, allowedRoles = []) {
  if (!profile) return false;
  if (!allowedRoles.length) return true;
  return allowedRoles.includes(profile.role);
}

export async function touchCurrentProfileLogin() {
  const user = await getAuthenticatedUser();
  if (!user) return;

  const { error } = await supabase
    .from('profiles')
    .update({ last_login_at: new Date().toISOString() })
    .eq('id', user.id);

  if (error) throw error;
}

export async function updateProfileBase(patch) {
  const profile = await getCurrentProfile();
  if (!profile) throw new Error('Utilisateur non connecté.');

  const { data, error } = await supabase
    .from('profiles')
    .update(cleanRecord({
      ...patch,
      updated_at: new Date().toISOString(),
    }))
    .eq('id', profile.id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateRoleProfile(role, patch, userId = null) {
  const currentProfile = await getCurrentProfile();
  if (!currentProfile) throw new Error('Utilisateur non connecté.');

  const targetRole = role || currentProfile.role;
  const targetUserId = userId || currentProfile.id;
  const table = ROLE_PROFILE_TABLES[targetRole];

  if (!table) {
    throw new Error('Rôle invalide pour la mise à jour du profil métier.');
  }

  const { data, error } = await supabase
    .from(table)
    .update(cleanRecord({
      ...patch,
      updated_at: new Date().toISOString(),
    }))
    .eq('user_id', targetUserId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateCurrentRoleProfile(patch) {
  const profile = await getCurrentProfile();
  if (!profile) throw new Error('Utilisateur non connecté.');
  return updateRoleProfile(profile.role, patch, profile.id);
}

export async function completeOnboardingForCurrentUser(payload = {}) {
  const profile = await getCurrentProfile();
  if (!profile) {
    throw new Error('Profil introuvable.');
  }

  const role = profile.role;
  if (!getOnboardingRoute(role)) {
    throw new Error('Aucun onboarding n’est prévu pour ce rôle.');
  }

  const profileUpdates = cleanRecord({
    full_name: payload.fullName?.trim(),
    phone: payload.phone?.trim() || null,
    city: payload.city?.trim(),
    country: payload.country?.trim() || null,
    onboarding_completed: true,
    account_status: profile.account_status === 'pending' ? 'active' : profile.account_status,
  });

  const roleUpdatesByRole = {
    student: cleanRecord({
      school_name: payload.schoolName?.trim(),
      study_level: payload.studyLevel?.trim(),
      headline: payload.headline?.trim(),
      bio: payload.bio?.trim() || null,
      availability_text: payload.availabilityText?.trim() || null,
    }),
    recruiter: cleanRecord({
      job_title: payload.jobTitle?.trim(),
      bio: payload.bio?.trim() || null,
    }),
    particular: cleanRecord({
      bio: payload.bio?.trim() || null,
    }),
  };

  const roleUpdates = roleUpdatesByRole[role] || {};
  const roleTable = ROLE_PROFILE_TABLES[role];

  if (roleTable && Object.keys(roleUpdates).length) {
    const { error: roleError } = await supabase
      .from(roleTable)
      .update(roleUpdates)
      .eq('user_id', profile.id);

    if (roleError) throw roleError;
  }

  const { error: profileError } = await supabase
    .from('profiles')
    .update(profileUpdates)
    .eq('id', profile.id);

  if (profileError) throw profileError;

  return getCurrentProfile();
}

export async function redirectAfterLogin() {
  const profile = await getCurrentProfile();
  window.location.href = getRoleHomeRoute(profile);
}
