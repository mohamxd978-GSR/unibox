import { supabase } from '/assets/supabase/supabase-client.js';
import { requireProfile, getRange } from '/assets/supabase/unibox-service-helpers.js';
import { SUPABASE_CONFIG } from '/assets/supabase/supabase-config.js';
import { createSignedAssetUrl, uploadMessageAttachment } from '/assets/supabase/unibox-storage.js';

async function attachMessageAssetUrls(messages = []) {
  return Promise.all((messages || []).map(async (message) => {
    if (!message?.attachment_path) return message;
    try {
      const signedUrl = await createSignedAssetUrl(SUPABASE_CONFIG.buckets.messageAttachments, message.attachment_path);
      return { ...message, attachment_url: signedUrl };
    } catch (_error) {
      return message;
    }
  }));
}

export async function listMessages(conversationId, {
  page = 1,
  pageSize = SUPABASE_CONFIG.defaults.messagePageSize,
} = {}) {
  const range = getRange(page, pageSize);

  const { data, error, count } = await supabase
    .from('messages')
    .select(`
      *,
      profiles:sender_user_id(
        id,
        full_name,
        avatar_path,
        role
      )
    `, { count: 'exact' })
    .eq('conversation_id', conversationId)
    .is('deleted_at', null)
    .order('sent_at', { ascending: true })
    .range(range.from, range.to);

  if (error) throw error;
  const withAssets = await attachMessageAssetUrls(data || []);
  return {
    data: withAssets,
    count: count || 0,
    page: range.page,
    pageSize: range.pageSize,
  };
}

export async function sendMessage({
  conversationId,
  body = '',
  attachmentPath = null,
  messageType = 'text',
}) {
  const profile = await requireProfile();
  const normalizedBody = body?.trim() || '';

  if (!normalizedBody && !attachmentPath) {
    throw new Error('Le message doit contenir du texte ou une pièce jointe.');
  }

  const { data, error } = await supabase
    .from('messages')
    .insert({
      conversation_id: conversationId,
      sender_user_id: profile.id,
      message_type: attachmentPath ? 'attachment' : messageType,
      body: normalizedBody || null,
      attachment_path: attachmentPath,
      sent_at: new Date().toISOString(),
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function sendMessageWithAttachment({
  conversationId,
  body = '',
  file = null,
}) {
  const attachmentPath = file ? await uploadMessageAttachment(file, conversationId) : null;
  return sendMessage({
    conversationId,
    body,
    attachmentPath,
    messageType: attachmentPath ? 'attachment' : 'text',
  });
}

export async function editMessage(messageId, body) {
  const { data, error } = await supabase
    .from('messages')
    .update({
      body: body?.trim() || null,
      edited_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('id', messageId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function deleteMessage(messageId) {
  const { data, error } = await supabase
    .from('messages')
    .update({
      deleted_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('id', messageId)
    .select()
    .single();

  if (error) throw error;
  return data;
}
