import {
  getCurrentSession,
  getCurrentProfile,
  getRoleHomeRoute,
  getOnboardingRoute,
  canAccessRole,
} from '/assets/supabase/unibox-profile.js';
import { ROUTES } from '/assets/config/app.config.js';

function resolveProtectedRoute(profile, allowedRoles = [], options = {}) {
  const {
    allowPending = false,
    allowIncompleteOnboarding = false,
  } = options;

  if (!profile) return ROUTES.common.accessDenied;

  if (!canAccessRole(profile, allowedRoles)) {
    return ROUTES.common.accessDenied;
  }

  if (['restricted', 'suspended', 'deleted'].includes(profile.account_status)) {
    return ROUTES.common.accessDenied;
  }

  const onboardingRoute = getOnboardingRoute(profile.role);
  if (!allowIncompleteOnboarding && !profile.onboarding_completed && onboardingRoute) {
    return onboardingRoute;
  }

  if (!allowPending && profile.account_status === 'pending') {
    return ROUTES.common.accountPending;
  }

  return null;
}

export async function bootUNIBOX() {
  const session = await getCurrentSession();
  if (!session) {
    return { session: null, profile: null, route: ROUTES.auth.login };
  }

  const profile = await getCurrentProfile();
  return {
    session,
    profile,
    route: getRoleHomeRoute(profile),
  };
}

export async function requireGuest() {
  const boot = await bootUNIBOX();
  if (boot.session && boot.profile) {
    window.location.href = boot.route;
  }
}

export async function redirectAuthenticatedVisitor() {
  const boot = await bootUNIBOX();
  if (boot.session && boot.profile) {
    window.location.href = boot.route;
  }
}

export async function requireAuthenticatedGuard() {
  const boot = await bootUNIBOX();

  if (!boot.session) {
    window.location.href = ROUTES.auth.login;
    return;
  }

  if (!boot.profile) {
    window.location.href = ROUTES.common.accessDenied;
  }
}

export async function requireRoleGuard(allowedRoles = []) {
  const boot = await bootUNIBOX();

  if (!boot.session) {
    window.location.href = ROUTES.auth.login;
    return;
  }

  const nextRoute = resolveProtectedRoute(boot.profile, allowedRoles, {
    allowPending: false,
    allowIncompleteOnboarding: false,
  });

  if (nextRoute) {
    window.location.href = nextRoute;
  }
}

export async function requireOnboardingGuard(allowedRoles = []) {
  const boot = await bootUNIBOX();

  if (!boot.session) {
    window.location.href = ROUTES.auth.login;
    return;
  }

  if (!boot.profile) {
    window.location.href = ROUTES.common.accessDenied;
    return;
  }

  if (!canAccessRole(boot.profile, allowedRoles)) {
    window.location.href = ROUTES.common.accessDenied;
    return;
  }

  if (['restricted', 'suspended', 'deleted'].includes(boot.profile.account_status)) {
    window.location.href = ROUTES.common.accessDenied;
    return;
  }

  if (boot.profile.onboarding_completed) {
    window.location.href = getRoleHomeRoute(boot.profile);
  }
}

export async function requirePendingGuard() {
  const boot = await bootUNIBOX();

  if (!boot.session) {
    window.location.href = ROUTES.auth.login;
    return;
  }

  if (!boot.profile) {
    window.location.href = ROUTES.common.accessDenied;
    return;
  }

  if (['restricted', 'suspended', 'deleted'].includes(boot.profile.account_status)) {
    window.location.href = ROUTES.common.accessDenied;
    return;
  }

  const onboardingRoute = getOnboardingRoute(boot.profile.role);
  if (!boot.profile.onboarding_completed && onboardingRoute) {
    window.location.href = onboardingRoute;
    return;
  }

  if (boot.profile.account_status !== 'pending') {
    window.location.href = getRoleHomeRoute(boot.profile);
  }
}
