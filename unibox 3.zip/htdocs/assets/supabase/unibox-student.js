import { listActiveListings, getListingDetail } from '/assets/supabase/unibox-listings.js';
import {
  listStudentFavorites,
  saveListingToFavorites,
  removeFavorite,
} from '/assets/supabase/unibox-favorites.js';
import {
  applyToListing,
  applyToOffer,
  listStudentApplications,
  getApplication,
  withdrawApplication,
} from '/assets/supabase/unibox-applications.js';
import {
  listMyNotifications,
  markNotificationRead,
  markAllMyNotificationsRead,
} from '/assets/supabase/unibox-notifications.js';
import {
  listConversationInbox,
  listConversationParticipants,
  listMyConversations,
  getOrCreateApplicationConversation,
  markConversationRead,
} from '/assets/supabase/unibox-conversations.js';
import {
  listMessages,
  sendMessage,
  sendMessageWithAttachment,
} from '/assets/supabase/unibox-messages.js';
import {
  listStudentPortfolioItems as listPortfolioItems,
  createStudentPortfolioItem as createPortfolioItem,
  updateStudentPortfolioItem as updatePortfolioItem,
  deleteStudentPortfolioItem as deletePortfolioItem,
} from '/assets/supabase/unibox-portfolio.js';
import {
  updateProfileBase,
  updateCurrentRoleProfile,
  getCurrentProfile,
} from '/assets/supabase/unibox-profile.js';

export async function listStudentListings(filters = {}) {
  return listActiveListings(filters);
}

export async function listStudentPublishedOffers(filters = {}) {
  const result = await listActiveListings(filters);
  return result.data;
}

export async function getStudentListingDetail({ listingType, listingId }) {
  return getListingDetail({ listingType, listingId });
}

export async function getStudentOfferDetail(offerId, listingType = 'offer') {
  return getListingDetail({ listingType, listingId: offerId });
}

export async function saveStudentListing({ listingType, offerId = null, minuteJobId = null }) {
  return saveListingToFavorites({
    listingType,
    listingId: listingType === 'offer' ? offerId : minuteJobId,
  });
}

export async function listStudentSavedListings() {
  const result = await listStudentFavorites();
  return result.data;
}

export async function removeStudentSavedListing(savedListingId) {
  return removeFavorite(savedListingId);
}

export async function applyStudentToOffer({ offerId, messageBody = '' }) {
  return applyToOffer({ offerId, messageBody });
}

export async function applyStudentToListing({ listingType, listingId, messageBody = '', cvFile = null }) {
  return applyToListing({ listingType, listingId, messageBody, cvFile });
}

export async function listStudentApplicationsCompat() {
  const result = await listStudentApplications();
  return result.data;
}
export { listStudentApplicationsCompat as listStudentApplications };

export async function getStudentApplicationDetail(applicationId) {
  return getApplication(applicationId);
}

export async function withdrawStudentApplication(applicationId) {
  return withdrawApplication(applicationId);
}

export async function listStudentNotifications() {
  const result = await listMyNotifications();
  return result.data;
}

export async function markStudentNotificationRead(notificationId) {
  return markNotificationRead(notificationId);
}

export async function markAllStudentNotificationsRead() {
  return markAllMyNotificationsRead();
}

export async function listStudentMessages() {
  const result = await listConversationInbox();
  return result.data;
}

export async function listStudentRawConversations() {
  const result = await listMyConversations();
  return result.data;
}

export async function getOrCreateStudentApplicationConversation(applicationId) {
  return getOrCreateApplicationConversation(applicationId);
}

export async function listStudentConversationParticipants(conversationId) {
  return listConversationParticipants(conversationId);
}

export async function markStudentConversationRead(conversationId) {
  return markConversationRead(conversationId);
}

export async function listConversationMessages(conversationId) {
  const result = await listMessages(conversationId);
  return result.data;
}

export async function sendStudentMessage({ conversationId, body, attachmentPath = null }) {
  return sendMessage({ conversationId, body, attachmentPath });
}

export async function sendStudentMessageWithAttachment({ conversationId, body, file }) {
  return sendMessageWithAttachment({ conversationId, body, file });
}

export async function updateStudentProfile(patch = {}) {
  const basePatch = {
    full_name: patch.full_name,
    phone: patch.phone,
    city: patch.city,
    country: patch.country,
    avatar_path: patch.avatar_path,
  };

  const rolePatch = {
    school_name: patch.school_name,
    study_level: patch.study_level,
    headline: patch.headline,
    bio: patch.bio,
    availability_text: patch.availability_text,
    cv_path: patch.cv_path,
    skills: patch.skills,
  };

  const profile = await getCurrentProfile();
  if (!profile) throw new Error('Utilisateur non connecté.');

  await updateProfileBase(basePatch);
  return updateCurrentRoleProfile(rolePatch);
}

export async function listStudentPortfolioItems() {
  const result = await listPortfolioItems();
  return result.data;
}

export async function createStudentPortfolioItem(payload) {
  return createPortfolioItem(payload);
}

export async function updateStudentPortfolioItem(itemId, patch) {
  return updatePortfolioItem(itemId, patch);
}

export async function deleteStudentPortfolioItem(itemId) {
  return deletePortfolioItem(itemId);
}
