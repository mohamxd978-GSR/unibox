import { OFFER_EMPLOYMENT_TYPES } from '/assets/config/app.config.js';
import { getCurrentProfile, getRoleProfile } from '/assets/supabase/unibox-profile.js';

export function trimToNull(value) {
  if (value === undefined) return undefined;
  if (value === null) return null;
  const normalized = String(value).trim();
  return normalized ? normalized : null;
}

export function cleanRecord(record = {}) {
  return Object.fromEntries(
    Object.entries(record).filter(([, value]) => value !== undefined)
  );
}

export function normalizeTextArray(values) {
  if (!Array.isArray(values)) return [];

  return values
    .map((value) => String(value || '').trim())
    .filter(Boolean)
    .filter((value, index, array) => array.indexOf(value) === index);
}

export function toNumberOrNull(value) {
  if (value === undefined) return undefined;
  if (value === null || value === '') return null;
  const numericValue = Number(value);
  return Number.isFinite(numericValue) ? numericValue : null;
}

export function getRange(page = 1, pageSize = 20) {
  const safePage = Math.max(1, Number(page) || 1);
  const safePageSize = Math.max(1, Number(pageSize) || 20);
  const from = (safePage - 1) * safePageSize;
  const to = from + safePageSize - 1;
  return {
    page: safePage,
    pageSize: safePageSize,
    from,
    to,
  };
}

export async function requireProfile(allowedRoles = []) {
  const profile = await getCurrentProfile();
  if (!profile) throw new Error('Utilisateur non connecté.');

  if (allowedRoles.length && !allowedRoles.includes(profile.role)) {
    throw new Error('Accès non autorisé pour ce rôle.');
  }

  return profile;
}

export async function requireRoleContext(role) {
  const profile = await requireProfile([role]);
  const roleProfile = await getRoleProfile(role, profile.id);
  return { profile, roleProfile };
}

export function normalizeOfferEmploymentType(rawValue) {
  if (rawValue === undefined) return undefined;
  if (rawValue === null) return null;

  const value = String(rawValue).trim().toLowerCase();
  if (!value) return null;

  const aliases = new Map([
    ['stage', 'stage'],
    ['internship', 'stage'],
    ['intern', 'stage'],
    ['part-time', 'part-time'],
    ['part time', 'part-time'],
    ['parttime', 'part-time'],
    ['temps partiel', 'part-time'],
    ['mi-temps', 'part-time'],
    ['full-time', 'full-time'],
    ['full time', 'full-time'],
    ['fulltime', 'full-time'],
    ['temps plein', 'full-time'],
  ]);

  const normalized = aliases.get(value);
  if (!normalized || !OFFER_EMPLOYMENT_TYPES.includes(normalized)) {
    throw new Error('Le type d’offre doit être stage, part-time ou full-time.');
  }

  return normalized;
}

export function ensureRequired(value, message) {
  if (!String(value || '').trim()) {
    throw new Error(message);
  }
}

export function ensureOfferPublicationRequirements(record = {}) {
  ensureRequired(record.title, 'Le titre de l’offre est obligatoire.');
  ensureRequired(record.description, 'La description de l’offre est obligatoire.');
  ensureRequired(record.contract_type, 'Le type d’offre est obligatoire : stage, part-time ou full-time.');
  ensureRequired(record.address_text, 'L’adresse ou la localisation du poste est obligatoire.');
  ensureRequired(record.city, 'La ville du poste est obligatoire.');
  ensureRequired(record.country, 'Le pays du poste est obligatoire.');
}

export function ensureMinuteJobPublicationRequirements(record = {}) {
  ensureRequired(record.title, 'Le titre de la mission est obligatoire.');
  ensureRequired(record.description, 'La description de la mission est obligatoire.');
  ensureRequired(record.address_text, 'L’adresse ou la localisation de la mission est obligatoire.');
  ensureRequired(record.city, 'La ville de la mission est obligatoire.');
  ensureRequired(record.country, 'Le pays de la mission est obligatoire.');
}

export function buildOfferWritePayload(payload = {}, context = {}) {
  const status = payload.status || undefined;
  const contractType = normalizeOfferEmploymentType(
    payload.employmentType ?? payload.employment_type ?? payload.contractType ?? payload.contract_type
  );

  const record = cleanRecord({
    company_id: context.companyId,
    created_by_recruiter_user_id: context.recruiterUserId,
    title: trimToNull(payload.title),
    summary: trimToNull(payload.summary),
    description: trimToNull(payload.description),
    requirements: trimToNull(payload.requirements),
    responsibilities: trimToNull(payload.responsibilities),
    contract_type: contractType,
    work_mode: trimToNull(payload.workMode ?? payload.work_mode),
    city: trimToNull(payload.city),
    country: trimToNull(payload.country),
    address_text: trimToNull(payload.addressText ?? payload.address_text),
    salary_min: toNumberOrNull(payload.salaryMin ?? payload.salary_min),
    salary_max: toNumberOrNull(payload.salaryMax ?? payload.salary_max),
    salary_currency: trimToNull(payload.salaryCurrency ?? payload.salary_currency) || 'EUR',
    salary_label: trimToNull(payload.salaryLabel ?? payload.salary_label),
    hours_per_week: toNumberOrNull(payload.hoursPerWeek ?? payload.hours_per_week),
    start_date: payload.startDate ?? payload.start_date ?? undefined,
    application_deadline: payload.applicationDeadline ?? payload.application_deadline ?? undefined,
    spots_count: toNumberOrNull(payload.spotsCount ?? payload.spots_count) ?? 1,
    skills: normalizeTextArray(payload.skills),
    benefits: normalizeTextArray(payload.benefits),
    status,
  });

  if (record.status === 'published') {
    ensureOfferPublicationRequirements(record);
  }

  return record;
}

export function buildMinuteJobWritePayload(payload = {}, context = {}) {
  const record = cleanRecord({
    particular_user_id: context.particularUserId,
    title: trimToNull(payload.title),
    category: trimToNull(payload.category),
    summary: trimToNull(payload.summary),
    description: trimToNull(payload.description),
    requirements: trimToNull(payload.requirements),
    city: trimToNull(payload.city),
    country: trimToNull(payload.country),
    address_text: trimToNull(payload.addressText ?? payload.address_text),
    rate_amount: toNumberOrNull(payload.rateAmount ?? payload.rate_amount),
    rate_currency: trimToNull(payload.rateCurrency ?? payload.rate_currency) || 'EUR',
    rate_label: trimToNull(payload.rateLabel ?? payload.rate_label),
    duration_hours: toNumberOrNull(payload.durationHours ?? payload.duration_hours),
    starts_at: payload.startsAt ?? payload.starts_at ?? undefined,
    ends_at: payload.endsAt ?? payload.ends_at ?? undefined,
    needed_people_count: toNumberOrNull(payload.neededPeopleCount ?? payload.needed_people_count) ?? 1,
    urgency_level: trimToNull(payload.urgencyLevel ?? payload.urgency_level) || 'normal',
    status: payload.status || undefined,
  });

  if (record.status === 'published') {
    ensureMinuteJobPublicationRequirements(record);
  }

  return record;
}
