import { supabase } from '/assets/supabase/supabase-client.js';
import { requireRoleContext, trimToNull, cleanRecord, getRange, ensureRequired } from '/assets/supabase/unibox-service-helpers.js';

function buildCompanyPayload(payload = {}, ownerUserId = undefined, fallbackStatus = undefined) {
  return cleanRecord({
    owner_user_id: ownerUserId,
    legal_name: trimToNull(payload.legalName ?? payload.legal_name),
    name: trimToNull(payload.name),
    slug: trimToNull(payload.slug),
    email: trimToNull(payload.email),
    phone: trimToNull(payload.phone),
    website_url: trimToNull(payload.websiteUrl ?? payload.website_url),
    industry: trimToNull(payload.industry),
    company_size: trimToNull(payload.companySize ?? payload.company_size),
    description: trimToNull(payload.description),
    logo_path: trimToNull(payload.logoPath ?? payload.logo_path),
    city: trimToNull(payload.city),
    country: trimToNull(payload.country),
    address_line1: trimToNull(payload.addressLine1 ?? payload.address_line1),
    address_line2: trimToNull(payload.addressLine2 ?? payload.address_line2),
    postal_code: trimToNull(payload.postalCode ?? payload.postal_code),
    status: payload.status || fallbackStatus || undefined,
  });
}

function ensureCompanyRequirements(record = {}) {
  ensureRequired(record.name, 'Le nom de l’entreprise est obligatoire.');
  ensureRequired(record.city, 'La ville de l’entreprise est obligatoire.');
  ensureRequired(record.country, 'Le pays de l’entreprise est obligatoire.');
  ensureRequired(record.address_line1, 'L’adresse principale de l’entreprise est obligatoire.');
}

export async function getCurrentRecruiterCompany() {
  const { profile, roleProfile } = await requireRoleContext('recruiter');

  if (roleProfile?.company_id) {
    const { data, error } = await supabase
      .from('companies')
      .select('*')
      .eq('id', roleProfile.company_id)
      .maybeSingle();

    if (error) throw error;
    if (data) return data;
  }

  const { data, error } = await supabase
    .from('companies')
    .select('*')
    .eq('owner_user_id', profile.id)
    .maybeSingle();

  if (error) throw error;
  return data ?? null;
}

export async function getCompanyById(companyId) {
  const { data, error } = await supabase
    .from('companies')
    .select('*')
    .eq('id', companyId)
    .single();

  if (error) throw error;
  return data;
}

export async function upsertCurrentRecruiterCompany(payload = {}) {
  const { profile } = await requireRoleContext('recruiter');
  const existing = await getCurrentRecruiterCompany();

  const record = buildCompanyPayload(payload, profile.id, existing?.status || 'active');
  ensureCompanyRequirements({
    ...existing,
    ...record,
  });

  if (existing?.id) {
    const { data, error } = await supabase
      .from('companies')
      .update({
        ...record,
        updated_at: new Date().toISOString(),
      })
      .eq('id', existing.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  const { data, error } = await supabase
    .from('companies')
    .insert({
      ...record,
      owner_user_id: profile.id,
      status: record.status || 'active',
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function createRecruiterCompany(payload = {}) {
  return upsertCurrentRecruiterCompany(payload);
}

export async function updateRecruiterCompany(companyId, patch = {}) {
  const existing = await getCompanyById(companyId);
  const record = buildCompanyPayload(patch, undefined, existing.status || 'active');
  ensureCompanyRequirements({
    ...existing,
    ...record,
  });

  const { data, error } = await supabase
    .from('companies')
    .update({
      ...record,
      updated_at: new Date().toISOString(),
    })
    .eq('id', companyId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function listVisibleCompanies({ search = '', page = 1, pageSize = 20 } = {}) {
  const range = getRange(page, pageSize);

  let query = supabase
    .from('companies')
    .select('*', { count: 'exact' })
    .order('created_at', { ascending: false });

  if (search?.trim()) {
    query = query.or(`name.ilike.%${search.trim()}%,industry.ilike.%${search.trim()}%,city.ilike.%${search.trim()}%`);
  }

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;

  return {
    data: data || [],
    count: count || 0,
    page: range.page,
    pageSize: range.pageSize,
  };
}
