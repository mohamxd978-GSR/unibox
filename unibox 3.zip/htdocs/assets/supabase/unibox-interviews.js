import { supabase } from '/assets/supabase/supabase-client.js';
import { requireProfile, getRange } from '/assets/supabase/unibox-service-helpers.js';
import { scheduleInterview as scheduleInterviewForApplication } from '/assets/supabase/unibox-applications.js';

export async function listMyInterviews({ status = null, page = 1, pageSize = 20 } = {}) {
  const profile = await requireProfile();
  const range = getRange(page, pageSize);

  let query = supabase
    .from('interviews')
    .select(`
      *,
      applications!inner(
        id,
        student_user_id,
        offer_id,
        minute_job_id,
        offers(id, title, city, created_by_recruiter_user_id),
        minute_jobs(id, title, city, particular_user_id)
      )
    `, { count: 'exact' })
    .order('scheduled_at', { ascending: true });

  if (profile.role === 'student') {
    query = query.eq('applications.student_user_id', profile.id);
  } else if (profile.role === 'recruiter') {
    query = query.eq('applications.offers.created_by_recruiter_user_id', profile.id);
  } else if (profile.role === 'particular') {
    query = query.eq('applications.minute_jobs.particular_user_id', profile.id);
  }

  if (status) query = query.eq('status', status);

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;

  return {
    data: data || [],
    count: count || 0,
    page: range.page,
    pageSize: range.pageSize,
  };
}

export async function getInterview(interviewId) {
  const { data, error } = await supabase
    .from('interviews')
    .select(`
      *,
      applications(*),
      profiles:created_by_user_id(id, full_name, email, role)
    `)
    .eq('id', interviewId)
    .single();

  if (error) throw error;
  return data;
}

export async function scheduleInterview(payload) {
  return scheduleInterviewForApplication(payload);
}

export async function updateInterviewStatus(interviewId, status) {
  const patch = {
    status,
    updated_at: new Date().toISOString(),
  };

  if (status === 'confirmed') patch.confirmed_at = new Date().toISOString();
  if (status === 'cancelled') patch.cancelled_at = new Date().toISOString();
  if (status === 'completed') patch.completed_at = new Date().toISOString();

  const { data, error } = await supabase
    .from('interviews')
    .update(patch)
    .eq('id', interviewId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function rescheduleInterview(interviewId, scheduledAt) {
  const { data, error } = await supabase
    .from('interviews')
    .update({
      scheduled_at: scheduledAt,
      status: 'proposed',
      updated_at: new Date().toISOString(),
    })
    .eq('id', interviewId)
    .select()
    .single();

  if (error) throw error;
  return data;
}
