import { supabase } from '/assets/supabase/supabase-client.js';
import { requireProfile, getRange, trimToNull } from '/assets/supabase/unibox-service-helpers.js';

function buildReportTargetPayload(targetType, targetId) {
  const payload = {
    offer_id: null,
    minute_job_id: null,
    profile_id: null,
    message_id: null,
    conversation_id: null,
    company_id: null,
  };

  const map = {
    offer: 'offer_id',
    minute_job: 'minute_job_id',
    profile: 'profile_id',
    message: 'message_id',
    conversation: 'conversation_id',
    company: 'company_id',
  };

  const targetKey = map[targetType];
  if (!targetKey) throw new Error('targetType invalide.');
  payload[targetKey] = targetId;
  return payload;
}

function withPagePayload(data, count, page, pageSize) {
  return {
    data: data || [],
    count: count || 0,
    page,
    pageSize,
  };
}

function getCurrentIso() {
  return new Date().toISOString();
}

async function insertAdminAuditLog({ actionType, targetTable = null, targetId = null, detail = {} }) {
  const profile = await requireProfile(['admin']);
  await supabase.from('admin_audit_logs').insert({
    admin_user_id: profile.id,
    action_type: actionType,
    target_table: targetTable,
    target_id: targetId,
    detail,
  });
}

export function getReportTargetDisplay(report) {
  if (!report) return 'Signalement';
  switch (report.target_type) {
    case 'offer':
      return report.offers?.title || 'Offre UNIBOX';
    case 'minute_job':
      return report.minute_jobs?.title || 'Job minute UNIBOX';
    case 'profile':
      return report.profiles?.full_name || report.profiles?.email || 'Profil UNIBOX';
    case 'message':
      return report.messages?.body?.slice(0, 70) || 'Message UNIBOX';
    case 'conversation':
      return report.conversations?.conversation_type || 'Conversation UNIBOX';
    case 'company':
      return report.companies?.name || 'Entreprise UNIBOX';
    default:
      return report.reason_code || 'Signalement UNIBOX';
  }
}

export async function createReport({
  targetType,
  targetId,
  reasonCode,
  description = '',
  priority = 'normal',
}) {
  const profile = await requireProfile();

  if (!targetType || !targetId || !reasonCode?.trim()) {
    throw new Error('targetType, targetId et reasonCode sont obligatoires.');
  }

  const { data, error } = await supabase
    .from('reports')
    .insert({
      created_by_user_id: profile.id,
      target_type: targetType,
      reason_code: reasonCode.trim(),
      description: trimToNull(description),
      priority,
      status: 'open',
      ...buildReportTargetPayload(targetType, targetId),
    })
    .select(`
      *,
      offers(id, title),
      minute_jobs(id, title),
      profiles!reports_profile_id_fkey(id, full_name, email),
      companies(id, name)
    `)
    .single();

  if (error) throw error;
  return data;
}

export async function listMyReports({ page = 1, pageSize = 20 } = {}) {
  const profile = await requireProfile();
  const range = getRange(page, pageSize);

  const { data, error, count } = await supabase
    .from('reports')
    .select(`
      *,
      offers(id, title),
      minute_jobs(id, title),
      profiles!reports_profile_id_fkey(id, full_name, email),
      companies(id, name),
      conversations(id, conversation_type),
      messages(id, body)
    `, { count: 'exact' })
    .eq('created_by_user_id', profile.id)
    .order('created_at', { ascending: false })
    .range(range.from, range.to);

  if (error) throw error;
  return withPagePayload(data, count, range.page, range.pageSize);
}

export async function listAdminReports({ status = null, page = 1, pageSize = 30 } = {}) {
  await requireProfile(['admin']);
  const range = getRange(page, pageSize);

  let query = supabase
    .from('reports')
    .select(`
      *,
      reporter:created_by_user_id(id, full_name, email, role),
      admin_assignee:assigned_admin_user_id(user_id, access_level),
      offers(id, title, city, hidden_by_admin),
      minute_jobs(id, title, city, hidden_by_admin),
      profiles!reports_profile_id_fkey(id, full_name, email, role),
      companies(id, name, city, status),
      conversations(id, conversation_type),
      messages(id, body)
    `, { count: 'exact' })
    .order('created_at', { ascending: false });

  if (status) query = query.eq('status', status);

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;

  return withPagePayload(data, count, range.page, range.pageSize);
}

export async function getAdminReportDetail(reportId) {
  await requireProfile(['admin']);

  const { data, error } = await supabase
    .from('reports')
    .select(`
      *,
      reporter:created_by_user_id(id, full_name, email, role, city),
      admin_assignee:assigned_admin_user_id(user_id, access_level),
      offers(id, title, city, country, address_text, hidden_by_admin),
      minute_jobs(id, title, city, country, address_text, hidden_by_admin),
      profiles!reports_profile_id_fkey(id, full_name, email, role, city),
      companies(id, name, city, country, status),
      conversations(id, conversation_type),
      messages(id, body)
    `)
    .eq('id', reportId)
    .single();

  if (error) throw error;
  return data;
}

export async function assignReport(reportId, adminUserId = null) {
  const profile = await requireProfile(['admin']);
  const targetAdminId = adminUserId || profile.id;

  const { data, error } = await supabase
    .from('reports')
    .update({
      assigned_admin_user_id: targetAdminId,
      status: 'in_review',
      updated_at: getCurrentIso(),
    })
    .eq('id', reportId)
    .select()
    .single();

  if (error) throw error;

  await insertAdminAuditLog({
    actionType: 'assign_report',
    targetTable: 'reports',
    targetId: reportId,
    detail: { assigned_admin_user_id: targetAdminId },
  }).catch(() => null);

  return data;
}

export async function resolveReport(reportId, resolutionNote = '') {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('reports')
    .update({
      status: 'resolved',
      resolved_at: getCurrentIso(),
      resolution_note: trimToNull(resolutionNote),
      updated_at: getCurrentIso(),
    })
    .eq('id', reportId)
    .select()
    .single();

  if (error) throw error;

  await insertAdminAuditLog({
    actionType: 'resolve_report',
    targetTable: 'reports',
    targetId: reportId,
    detail: { resolution_note: trimToNull(resolutionNote) },
  }).catch(() => null);

  return data;
}

export async function dismissReport(reportId, resolutionNote = '') {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('reports')
    .update({
      status: 'dismissed',
      resolved_at: getCurrentIso(),
      resolution_note: trimToNull(resolutionNote),
      updated_at: getCurrentIso(),
    })
    .eq('id', reportId)
    .select()
    .single();

  if (error) throw error;

  await insertAdminAuditLog({
    actionType: 'dismiss_report',
    targetTable: 'reports',
    targetId: reportId,
    detail: { resolution_note: trimToNull(resolutionNote) },
  }).catch(() => null);

  return data;
}

export async function openModerationCase({
  reportId,
  assignedAdminUserId = null,
  actionType = 'none',
  decisionNote = '',
  internalNote = '',
}) {
  const profile = await requireProfile(['admin']);

  const { data, error } = await supabase
    .from('moderation_cases')
    .insert({
      report_id: reportId,
      opened_by_admin_user_id: profile.id,
      assigned_admin_user_id: assignedAdminUserId || profile.id,
      status: 'open',
      action_type: actionType,
      decision_note: trimToNull(decisionNote),
      internal_note: trimToNull(internalNote),
    })
    .select()
    .single();

  if (error) throw error;

  await supabase
    .from('reports')
    .update({
      status: 'in_review',
      assigned_admin_user_id: assignedAdminUserId || profile.id,
      updated_at: getCurrentIso(),
    })
    .eq('id', reportId)
    .catch(() => null);

  await insertAdminAuditLog({
    actionType: 'open_moderation_case',
    targetTable: 'moderation_cases',
    targetId: data.id,
    detail: { report_id: reportId, action_type: actionType },
  }).catch(() => null);

  return data;
}

export async function listModerationCases({ status = null, page = 1, pageSize = 30 } = {}) {
  await requireProfile(['admin']);
  const range = getRange(page, pageSize);

  let query = supabase
    .from('moderation_cases')
    .select(`
      *,
      reports(id, target_type, reason_code, status, priority, description),
      opened_admin:opened_by_admin_user_id(user_id, access_level),
      assigned_admin:assigned_admin_user_id(user_id, access_level)
    `, { count: 'exact' })
    .order('created_at', { ascending: false });

  if (status) query = query.eq('status', status);

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;

  return withPagePayload(data, count, range.page, range.pageSize);
}

export async function updateModerationCase(caseId, patch) {
  const profile = await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('moderation_cases')
    .update({
      ...patch,
      updated_at: getCurrentIso(),
      assigned_admin_user_id: patch?.assigned_admin_user_id || patch?.assignedAdminUserId || profile.id,
    })
    .eq('id', caseId)
    .select()
    .single();

  if (error) throw error;

  await insertAdminAuditLog({
    actionType: 'update_moderation_case',
    targetTable: 'moderation_cases',
    targetId: caseId,
    detail: patch,
  }).catch(() => null);

  return data;
}

export async function hideOfferByAdmin(offerId, hiddenReason = 'Masquée par l’admin') {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('offers')
    .update({
      hidden_by_admin: true,
      hidden_reason: hiddenReason,
      updated_at: getCurrentIso(),
    })
    .eq('id', offerId)
    .select()
    .single();

  if (error) throw error;

  await insertAdminAuditLog({
    actionType: 'hide_offer',
    targetTable: 'offers',
    targetId: offerId,
    detail: { hidden_reason: hiddenReason },
  }).catch(() => null);

  return data;
}

export async function restoreOfferByAdmin(offerId) {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('offers')
    .update({
      hidden_by_admin: false,
      hidden_reason: null,
      updated_at: getCurrentIso(),
    })
    .eq('id', offerId)
    .select()
    .single();

  if (error) throw error;

  await insertAdminAuditLog({
    actionType: 'restore_offer',
    targetTable: 'offers',
    targetId: offerId,
    detail: {},
  }).catch(() => null);

  return data;
}

export async function hideMinuteJobByAdmin(jobId, hiddenReason = 'Masquée par l’admin') {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('minute_jobs')
    .update({
      hidden_by_admin: true,
      hidden_reason: hiddenReason,
      updated_at: getCurrentIso(),
    })
    .eq('id', jobId)
    .select()
    .single();

  if (error) throw error;

  await insertAdminAuditLog({
    actionType: 'hide_minute_job',
    targetTable: 'minute_jobs',
    targetId: jobId,
    detail: { hidden_reason: hiddenReason },
  }).catch(() => null);

  return data;
}

export async function restoreMinuteJobByAdmin(jobId) {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('minute_jobs')
    .update({
      hidden_by_admin: false,
      hidden_reason: null,
      updated_at: getCurrentIso(),
    })
    .eq('id', jobId)
    .select()
    .single();

  if (error) throw error;

  await insertAdminAuditLog({
    actionType: 'restore_minute_job',
    targetTable: 'minute_jobs',
    targetId: jobId,
    detail: {},
  }).catch(() => null);

  return data;
}
