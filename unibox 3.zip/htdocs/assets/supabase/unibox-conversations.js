import { supabase } from '/assets/supabase/supabase-client.js';
import { requireProfile, getRange } from '/assets/supabase/unibox-service-helpers.js';

function conversationTypeLabel(value) {
  switch (value) {
    case 'application':
      return 'Candidature';
    case 'support':
      return 'Support';
    case 'moderation':
      return 'Modération';
    default:
      return 'Conversation';
  }
}

async function ensureConversation(conversationId) {
  const { data, error } = await supabase
    .from('conversations')
    .select('*')
    .eq('id', conversationId)
    .single();

  if (error) throw error;
  return data;
}

async function getExistingConversationByApplication(applicationId) {
  const { data, error } = await supabase
    .from('conversations')
    .select('*')
    .eq('application_id', applicationId)
    .maybeSingle();

  if (error) throw error;
  return data || null;
}

async function getApplicationParticipants(applicationId) {
  const { data, error } = await supabase
    .from('applications')
    .select(`
      id,
      student_user_id,
      offer_id,
      minute_job_id,
      offers:offers!applications_offer_id_fkey(
        id,
        title,
        created_by_recruiter_user_id
      ),
      minute_job:minute_jobs!applications_minute_job_id_fkey(
        id,
        title,
        particular_user_id
      )
    `)
    .eq('id', applicationId)
    .single();

  if (error) throw error;

  const participantIds = [
    data.student_user_id,
    data.offers?.created_by_recruiter_user_id,
    data.minute_job?.particular_user_id,
  ].filter(Boolean);

  return {
    application: data,
    participantIds: Array.from(new Set(participantIds)),
  };
}

async function listExistingParticipantIds(conversationId) {
  const { data, error } = await supabase
    .from('conversation_participants')
    .select('user_id')
    .eq('conversation_id', conversationId);

  if (error) throw error;
  return new Set((data || []).map((row) => row.user_id));
}

async function ensureConversationParticipants(conversationId, participantIds = []) {
  const uniqueParticipantIds = Array.from(new Set((participantIds || []).filter(Boolean)));
  if (!uniqueParticipantIds.length) return [];

  const existingIds = await listExistingParticipantIds(conversationId);
  const rows = uniqueParticipantIds
    .filter((userId) => !existingIds.has(userId))
    .map((userId) => ({
      conversation_id: conversationId,
      user_id: userId,
      participant_role: 'member',
    }));

  if (!rows.length) return [];

  const { data, error } = await supabase
    .from('conversation_participants')
    .insert(rows)
    .select('conversation_id, user_id');

  if (error && error.code !== '23505') throw error;
  return data || [];
}

async function fetchConversationParticipants(conversationIds = []) {
  if (!conversationIds.length) return [];
  const { data, error } = await supabase
    .from('conversation_participants')
    .select(`
      conversation_id,
      user_id,
      participant_role,
      last_read_at,
      profiles:user_id(
        id,
        full_name,
        email,
        avatar_path,
        role
      )
    `)
    .in('conversation_id', conversationIds)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return data || [];
}

async function fetchConversationMessagesPreview(conversationIds = []) {
  if (!conversationIds.length) return [];
  const { data, error } = await supabase
    .from('messages')
    .select(`
      id,
      conversation_id,
      body,
      message_type,
      attachment_path,
      sender_user_id,
      sent_at,
      deleted_at,
      profiles:sender_user_id(id, full_name, role)
    `)
    .in('conversation_id', conversationIds)
    .is('deleted_at', null)
    .order('sent_at', { ascending: false });

  if (error) throw error;
  return data || [];
}

async function fetchApplicationLabels(applicationIds = []) {
  if (!applicationIds.length) return new Map();

  const { data, error } = await supabase
    .from('applications')
    .select(`
      id,
      offers:offers!applications_offer_id_fkey(title),
      minute_job:minute_jobs!applications_minute_job_id_fkey(title)
    `)
    .in('id', applicationIds);

  if (error) throw error;

  return new Map(
    (data || []).map((row) => [
      row.id,
      row.offers?.title || row.minute_job?.title || 'Candidature UNIBOX',
    ])
  );
}

function buildConversationSummary(row, currentUserId, participants, lastMessage, applicationLabelMap) {
  const conversation = row.conversations || {};
  const otherParticipants = participants.filter((entry) => entry.user_id !== currentUserId);
  const otherNames = otherParticipants
    .map((entry) => entry.profiles?.full_name || entry.profiles?.email)
    .filter(Boolean);

  const applicationLabel = conversation.application_id
    ? applicationLabelMap.get(conversation.application_id)
    : null;

  const title = applicationLabel
    || conversation.support_subject
    || (otherNames.length ? otherNames.join(' · ') : conversationTypeLabel(conversation.conversation_type));

  const subtitle = otherNames.length
    ? `Avec ${otherNames.join(', ')}`
    : conversationTypeLabel(conversation.conversation_type);

  const preview = lastMessage?.body?.trim()
    || (lastMessage?.attachment_path ? 'Pièce jointe envoyée' : 'Aucun message pour le moment');

  const sentAt = lastMessage?.sent_at || conversation.last_message_at || conversation.updated_at || conversation.created_at;

  return {
    ...row,
    title,
    subtitle,
    preview,
    sent_at: sentAt,
    participant_names: otherNames,
    participants,
    last_message: lastMessage || null,
    is_closed: Boolean(conversation.is_closed),
  };
}

export async function listMyConversations({ page = 1, pageSize = 20 } = {}) {
  const profile = await requireProfile();
  const range = getRange(page, pageSize);

  const { data, error, count } = await supabase
    .from('conversation_participants')
    .select(`
      *,
      conversations(
        id,
        conversation_type,
        application_id,
        support_subject,
        is_closed,
        last_message_at,
        created_at,
        updated_at
      )
    `, { count: 'exact' })
    .eq('user_id', profile.id)
    .order('updated_at', { ascending: false })
    .range(range.from, range.to);

  if (error) throw error;
  return {
    data: data || [],
    count: count || 0,
    page: range.page,
    pageSize: range.pageSize,
  };
}

export async function listConversationInbox(options = {}) {
  const profile = await requireProfile();
  const result = await listMyConversations(options);
  const rows = result.data || [];

  if (!rows.length) return result;

  const conversationIds = rows.map((row) => row.conversation_id).filter(Boolean);
  const applicationIds = rows.map((row) => row.conversations?.application_id).filter(Boolean);

  const [participants, previewMessages, applicationLabelMap] = await Promise.all([
    fetchConversationParticipants(conversationIds),
    fetchConversationMessagesPreview(conversationIds),
    fetchApplicationLabels(applicationIds),
  ]);

  const participantsByConversation = new Map();
  for (const entry of participants) {
    const bucket = participantsByConversation.get(entry.conversation_id) || [];
    bucket.push(entry);
    participantsByConversation.set(entry.conversation_id, bucket);
  }

  const latestMessageByConversation = new Map();
  for (const entry of previewMessages) {
    if (!latestMessageByConversation.has(entry.conversation_id)) {
      latestMessageByConversation.set(entry.conversation_id, entry);
    }
  }

  return {
    ...result,
    data: rows
      .map((row) => buildConversationSummary(
        row,
        profile.id,
        participantsByConversation.get(row.conversation_id) || [],
        latestMessageByConversation.get(row.conversation_id) || null,
        applicationLabelMap,
      ))
      .sort((a, b) => new Date(b.sent_at || 0) - new Date(a.sent_at || 0)),
  };
}

export async function getConversation(conversationId) {
  return ensureConversation(conversationId);
}

export async function listConversationParticipants(conversationId) {
  const { data, error } = await supabase
    .from('conversation_participants')
    .select(`
      *,
      profiles:user_id(
        id,
        full_name,
        email,
        avatar_path,
        role
      )
    `)
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return data || [];
}

export async function getOrCreateApplicationConversation(applicationId, participantUserIds = []) {
  const profile = await requireProfile();
  const derived = await getApplicationParticipants(applicationId);
  const participantIds = Array.from(new Set([
    profile.id,
    ...derived.participantIds,
    ...participantUserIds.filter(Boolean),
  ]));

  const existingConversation = await getExistingConversationByApplication(applicationId);
  if (existingConversation) {
    await ensureConversationParticipants(existingConversation.id, participantIds);
    return existingConversation;
  }

  try {
    const { data, error } = await supabase
      .from('conversations')
      .insert({
        conversation_type: 'application',
        application_id: applicationId,
        created_by_user_id: profile.id,
        is_closed: false,
      })
      .select()
      .single();

    if (error) throw error;

    await ensureConversationParticipants(data.id, participantIds);
    return data;
  } catch (error) {
    if (error?.code === '23505') {
      const fallbackConversation = await getExistingConversationByApplication(applicationId);
      if (!fallbackConversation) throw error;
      await ensureConversationParticipants(fallbackConversation.id, participantIds);
      return fallbackConversation;
    }
    throw error;
  }
}

export async function resolveConversationId({ conversationId = null, applicationId = null } = {}) {
  if (conversationId) {
    const existing = await ensureConversation(conversationId);
    return existing.id;
  }

  if (applicationId) {
    const conversation = await getOrCreateApplicationConversation(applicationId);
    return conversation.id;
  }

  return null;
}

export async function createSupportConversation({ subject, participantUserIds = [] }) {
  const profile = await requireProfile();
  const participants = Array.from(new Set([profile.id, ...participantUserIds.filter(Boolean)]));

  const { data, error } = await supabase
    .from('conversations')
    .insert({
      conversation_type: 'support',
      support_subject: subject?.trim() || 'Support UNIBOX',
      created_by_user_id: profile.id,
      is_closed: false,
    })
    .select()
    .single();

  if (error) throw error;

  await ensureConversationParticipants(data.id, participants);
  return data;
}

export async function addConversationParticipant(conversationId, userId, participantRole = 'member') {
  const { data, error } = await supabase
    .from('conversation_participants')
    .insert({
      conversation_id: conversationId,
      user_id: userId,
      participant_role: participantRole,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function markConversationRead(conversationId) {
  const profile = await requireProfile();

  const { data, error } = await supabase
    .from('conversation_participants')
    .update({
      last_read_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('conversation_id', conversationId)
    .eq('user_id', profile.id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function closeConversation(conversationId) {
  await ensureConversation(conversationId);

  const { data, error } = await supabase
    .from('conversations')
    .update({
      is_closed: true,
      updated_at: new Date().toISOString(),
    })
    .eq('id', conversationId)
    .select()
    .single();

  if (error) throw error;
  return data;
}