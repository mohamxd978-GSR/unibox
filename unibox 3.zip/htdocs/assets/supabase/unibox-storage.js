import { supabase } from '/assets/supabase/supabase-client.js';
import { SUPABASE_CONFIG } from '/assets/supabase/supabase-config.js';
import { getAuthenticatedUser } from '/assets/supabase/unibox-profile.js';

function ensureFile(file) {
  if (!file) throw new Error('Aucun fichier sélectionné.');
}

function ensureAcceptedFile(file, { extensions = [], mimeTypes = [] } = {}) {
  ensureFile(file);

  const fileName = String(file.name || '');
  const extension = fileName.includes('.') ? fileName.split('.').pop().toLowerCase() : '';
  const hasAllowedExtension = !extensions.length || extensions.includes(extension);
  const hasAllowedMimeType = !mimeTypes.length || mimeTypes.includes(file.type);

  if (!hasAllowedExtension && !hasAllowedMimeType) {
    throw new Error('Format de fichier non autorisé.');
  }
}

function filePath(prefix, file) {
  const ext = file.name.includes('.') ? file.name.split('.').pop().toLowerCase() : 'bin';
  return `${prefix}/${Date.now()}-${crypto.randomUUID()}.${ext}`;
}

async function uploadToBucket(bucket, path, file, options = {}) {
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(path, file, options);

  if (error) throw error;
  return data.path;
}

export async function uploadAvatar(file) {
  ensureAcceptedFile(file, {
    extensions: ['png', 'jpg', 'jpeg', 'webp'],
  });

  const user = await getAuthenticatedUser();
  if (!user) throw new Error('Utilisateur non connecté');

  const path = filePath(`${user.id}/avatar`, file);
  return uploadToBucket(SUPABASE_CONFIG.buckets.avatars, path, file, {
    cacheControl: '3600',
    upsert: true,
  });
}

export async function uploadStudentCv(file) {
  ensureAcceptedFile(file, {
    extensions: ['pdf', 'png'],
    mimeTypes: ['application/pdf', 'image/png'],
  });

  const user = await getAuthenticatedUser();
  if (!user) throw new Error('Utilisateur non connecté');

  const path = filePath(`${user.id}/cv`, file);
  return uploadToBucket(SUPABASE_CONFIG.buckets.studentCvs, path, file, {
    cacheControl: '3600',
    upsert: true,
  });
}

export async function uploadApplicationDocument(file, applicationId = 'pending') {
  ensureAcceptedFile(file, {
    extensions: ['pdf', 'png'],
    mimeTypes: ['application/pdf', 'image/png'],
  });

  const user = await getAuthenticatedUser();
  if (!user) throw new Error('Utilisateur non connecté');

  const path = filePath(`${user.id}/applications/${applicationId}`, file);
  return uploadToBucket(SUPABASE_CONFIG.buckets.applicationDocuments, path, file, {
    cacheControl: '3600',
    upsert: false,
  });
}

export async function uploadPortfolioAsset(file, portfolioItemId) {
  ensureFile(file);

  const user = await getAuthenticatedUser();
  if (!user) throw new Error('Utilisateur non connecté');

  const path = filePath(`${user.id}/${portfolioItemId}`, file);
  return uploadToBucket(SUPABASE_CONFIG.buckets.studentPortfolio, path, file, {
    cacheControl: '3600',
    upsert: false,
  });
}

export async function uploadCompanyLogo(file) {
  ensureAcceptedFile(file, {
    extensions: ['png', 'jpg', 'jpeg', 'webp', 'svg'],
  });

  const user = await getAuthenticatedUser();
  if (!user) throw new Error('Utilisateur non connecté');

  const path = filePath(`${user.id}/company-logo`, file);
  return uploadToBucket(SUPABASE_CONFIG.buckets.companyLogos, path, file, {
    cacheControl: '3600',
    upsert: true,
  });
}

export async function uploadReportAttachment(file, reportId = 'pending') {
  ensureFile(file);

  const user = await getAuthenticatedUser();
  if (!user) throw new Error('Utilisateur non connecté');

  const path = filePath(`${user.id}/reports/${reportId}`, file);
  return uploadToBucket(SUPABASE_CONFIG.buckets.reportAttachments, path, file, {
    cacheControl: '3600',
    upsert: false,
  });
}

export async function uploadMessageAttachment(file, conversationId = 'pending') {
  ensureFile(file);

  const user = await getAuthenticatedUser();
  if (!user) throw new Error('Utilisateur non connecté');

  const path = filePath(`${user.id}/messages/${conversationId}`, file);
  return uploadToBucket(SUPABASE_CONFIG.buckets.messageAttachments, path, file, {
    cacheControl: '3600',
    upsert: false,
  });
}

export function getPublicAssetUrl(bucket, storagePath) {
  if (!storagePath) return null;
  if (storagePath.startsWith('http://') || storagePath.startsWith('https://')) {
    return storagePath;
  }
  const { data } = supabase.storage.from(bucket).getPublicUrl(storagePath);
  return data.publicUrl;
}

export async function getSafeAssetUrl(bucket, storagePath) {
  if (!storagePath) return null;
  if (storagePath.startsWith('http://') || storagePath.startsWith('https://')) {
    return storagePath;
  }
  
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(storagePath, 604800); // 7 jours
  
  if (error || !data?.signedUrl) {
    const { data: pubData } = supabase.storage.from(bucket).getPublicUrl(storagePath);
    return pubData?.publicUrl || null;
  }
  
  return data.signedUrl;
}

export async function createSignedAssetUrl(bucket, storagePath, expiresIn = 3600) {
  const { data, error } = await supabase.storage
    .from(bucket)
    .createSignedUrl(storagePath, expiresIn);

  if (error) throw error;
  return data.signedUrl;
}
