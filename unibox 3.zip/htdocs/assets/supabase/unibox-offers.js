import { supabase } from '/assets/supabase/supabase-client.js';
import { getCurrentRecruiterCompany } from '/assets/supabase/unibox-companies.js';
import {
  requireRoleContext,
  buildOfferWritePayload,
  getRange,
  normalizeOfferEmploymentType,
  ensureOfferPublicationRequirements,
  trimToNull,
} from '/assets/supabase/unibox-service-helpers.js';

function hydrateOffer(item) {
  if (!item) return item;
  return {
    ...item,
    employment_type: item.contract_type,
  };
}

export async function listRecruiterOffers({ status = null, search = '', page = 1, pageSize = 20 } = {}) {
  const { profile } = await requireRoleContext('recruiter');
  const range = getRange(page, pageSize);

  let query = supabase
    .from('offers')
    .select(`
      *,
      companies(id, name, city, country, status, hidden_by_admin)
    `, { count: 'exact' })
    .eq('created_by_recruiter_user_id', profile.id)
    .order('created_at', { ascending: false });

  if (status) query = query.eq('status', status);
  if (search?.trim()) query = query.ilike('title', `%${search.trim()}%`);

  const { data, error, count } = await query.range(range.from, range.to);
  if (error) throw error;

  return {
    data: (data || []).map(hydrateOffer),
    count: count || 0,
    page: range.page,
    pageSize: range.pageSize,
  };
}

export async function getRecruiterOffer(offerId) {
  const { data, error } = await supabase
    .from('offers')
    .select(`
      *,
      companies(*)
    `)
    .eq('id', offerId)
    .single();

  if (error) throw error;
  return hydrateOffer(data);
}

function ensureOfferCoreRequirements(record = {}) {
  if (!record.title) throw new Error('Le titre de l’offre est obligatoire.');
  if (!record.description) throw new Error('La description de l’offre est obligatoire.');
  ensureOfferPublicationRequirements(record);
}

export async function createRecruiterOffer(payload = {}) {
  const { profile } = await requireRoleContext('recruiter');
  const company = await getCurrentRecruiterCompany();

  if (!company?.id) {
    throw new Error('Crée ou complète ton entreprise UNIBOX avant de publier une offre.');
  }

  const record = buildOfferWritePayload(payload, {
    companyId: company.id,
    recruiterUserId: profile.id,
  });

  ensureOfferCoreRequirements(record);

  if (record.status === 'published') {
    record.published_at = new Date().toISOString();
  }

  const { data, error } = await supabase
    .from('offers')
    .insert(record)
    .select(`
      *,
      companies(*)
    `)
    .single();

  if (error) throw error;
  return hydrateOffer(data);
}

export async function updateRecruiterOffer(offerId, patch = {}) {
  const existing = await getRecruiterOffer(offerId);
  const nextPatch = buildOfferWritePayload({
    ...existing,
    ...patch,
    contract_type: patch.contract_type ?? patch.contractType ?? patch.employmentType ?? patch.employment_type ?? existing.contract_type,
  });

  const merged = {
    ...existing,
    ...nextPatch,
  };
  ensureOfferCoreRequirements(merged);

  const finalPatch = {
    ...nextPatch,
    updated_at: new Date().toISOString(),
  };

  const nextStatus = patch.status || existing.status;
  if (patch.published_at !== undefined) {
    finalPatch.published_at = patch.published_at;
  } else if (nextStatus === 'published' && !existing.published_at) {
    finalPatch.published_at = new Date().toISOString();
  }

  const { data, error } = await supabase
    .from('offers')
    .update(finalPatch)
    .eq('id', offerId)
    .select(`
      *,
      companies(*)
    `)
    .single();

  if (error) throw error;
  return hydrateOffer(data);
}

export async function publishRecruiterOffer(offerId) {
  const existing = await getRecruiterOffer(offerId);
  ensureOfferCoreRequirements(existing);

  return updateRecruiterOffer(offerId, {
    status: 'published',
    published_at: existing.published_at || new Date().toISOString(),
  });
}

export async function pauseRecruiterOffer(offerId) {
  return updateRecruiterOffer(offerId, { status: 'paused' });
}

export async function closeRecruiterOffer(offerId) {
  return updateRecruiterOffer(offerId, {
    status: 'closed',
    closed_at: new Date().toISOString(),
  });
}

export async function archiveRecruiterOffer(offerId) {
  return updateRecruiterOffer(offerId, { status: 'archived' });
}

export async function deleteRecruiterOffer(offerId) {
  const { error } = await supabase
    .from('offers')
    .delete()
    .eq('id', offerId);

  if (error) throw error;
}

export async function duplicateRecruiterOffer(offerId, overrides = {}) {
  const existing = await getRecruiterOffer(offerId);

  return createRecruiterOffer({
    title: overrides.title || `${existing.title} · copie`,
    summary: existing.summary,
    description: existing.description,
    requirements: existing.requirements,
    responsibilities: existing.responsibilities,
    employmentType: normalizeOfferEmploymentType(existing.contract_type),
    work_mode: existing.work_mode,
    city: existing.city,
    country: existing.country,
    address_text: existing.address_text,
    salary_min: existing.salary_min,
    salary_max: existing.salary_max,
    salary_currency: existing.salary_currency,
    salary_label: existing.salary_label,
    hours_per_week: existing.hours_per_week,
    start_date: existing.start_date,
    application_deadline: existing.application_deadline,
    spots_count: existing.spots_count,
    skills: existing.skills || [],
    benefits: existing.benefits || [],
    status: overrides.status || 'draft',
  });
}

export function normalizeRecruiterOfferPayload(payload = {}) {
  return {
    ...payload,
    contract_type: normalizeOfferEmploymentType(
      payload.contract_type ?? payload.contractType ?? payload.employmentType ?? payload.employment_type
    ),
    address_text: trimToNull(payload.address_text ?? payload.addressText),
  };
}
