import { supabase } from '/assets/supabase/supabase-client.js';
import { getRange } from '/assets/supabase/unibox-service-helpers.js';

function cleanText(value) {
  return String(value || '').trim();
}

function escapeIlike(value) {
  return cleanText(value).replace(/,/g, ' ').replace(/%/g, '');
}

function mapListing(listing) {
  if (!listing) return listing;

  return {
    ...listing,
    listing_id: listing.listing_id || listing.id,
    employment_type: listing.employment_type || null,
    urgency_level: listing.urgency_level || null,
    location_label:
      listing.location_label
      || [listing.address_text, listing.city, listing.country].filter(Boolean).join(', ')
      || 'Localisation à confirmer',
  };
}

function normalizeEmploymentTypeFilters(filters = []) {
  const values = Array.isArray(filters) ? filters : [filters];
  return values
    .map((value) => cleanText(value).toLowerCase())
    .filter(Boolean)
    .filter((value, index, array) => array.indexOf(value) === index);
}

function applySearchFilters(query, { search = '', location = '' } = {}) {
  let next = query;
  const safeSearch = escapeIlike(search);
  const safeLocation = escapeIlike(location);

  if (safeSearch) {
    next = next.or([
      `title.ilike.%${safeSearch}%`,
      `summary.ilike.%${safeSearch}%`,
      `description.ilike.%${safeSearch}%`,
      `company_name.ilike.%${safeSearch}%`,
      `owner_display_name.ilike.%${safeSearch}%`,
      `rate_or_salary_label.ilike.%${safeSearch}%`,
    ].join(','));
  }

  if (safeLocation) {
    next = next.ilike('location_label', `%${safeLocation}%`);
  }

  return next;
}

async function fetchListingsChunk(queryBuilder, { page = 1, pageSize = 20 } = {}) {
  const range = getRange(page, pageSize);
  const { data, error, count } = await queryBuilder.range(range.from, range.to);

  if (error) throw error;
  return {
    data: (data || []).map(mapListing),
    count: count || 0,
    page: range.page,
    pageSize: range.pageSize,
  };
}

export async function listActiveListings({
  listingType = null,
  employmentTypes = [],
  search = '',
  location = '',
  page = 1,
  pageSize = 20,
} = {}) {
  const normalizedEmploymentTypes = normalizeEmploymentTypeFilters(employmentTypes);
  const range = getRange(page, pageSize);

  if (!normalizedEmploymentTypes.length || listingType === 'offer' || listingType === 'minute_job') {
    let query = supabase
      .from('active_listings_view')
      .select('*', { count: 'exact' })
      .order('published_at', { ascending: false });

    if (listingType) query = query.eq('listing_type', listingType);
    if (normalizedEmploymentTypes.length) query = query.in('employment_type', normalizedEmploymentTypes);

    query = applySearchFilters(query, { search, location });
    return fetchListingsChunk(query, range);
  }

  let offerQuery = supabase
    .from('active_listings_view')
    .select('*')
    .eq('listing_type', 'offer')
    .in('employment_type', normalizedEmploymentTypes)
    .order('published_at', { ascending: false })
    .limit(200);

  let minuteJobQuery = supabase
    .from('active_listings_view')
    .select('*')
    .eq('listing_type', 'minute_job')
    .order('published_at', { ascending: false })
    .limit(200);

  offerQuery = applySearchFilters(offerQuery, { search, location });
  minuteJobQuery = applySearchFilters(minuteJobQuery, { search, location });

  const [offerResult, minuteJobResult] = await Promise.all([offerQuery, minuteJobQuery]);
  if (offerResult.error) throw offerResult.error;
  if (minuteJobResult.error) throw minuteJobResult.error;

  const merged = [...(offerResult.data || []), ...(minuteJobResult.data || [])]
    .map(mapListing)
    .sort((a, b) => new Date(b.published_at || b.source_created_at || 0) - new Date(a.published_at || a.source_created_at || 0));

  return {
    data: merged.slice(range.from, range.to + 1),
    count: merged.length,
    page: range.page,
    pageSize: range.pageSize,
  };
}

export async function getListingDetail({ listingType, listingId }) {
  if (!listingType || !listingId) {
    throw new Error('listingType et listingId sont obligatoires.');
  }

  if (listingType === 'offer') {
    const { data, error } = await supabase
      .from('offers')
      .select(`
        *,
        companies(*)
      `)
      .eq('id', listingId)
      .single();

    if (error) throw error;
    return mapListing({
      ...data,
      listing_type: 'offer',
      listing_id: data.id,
      employment_type: data.contract_type,
      company_name: data.companies?.name || null,
      owner_display_name: data.companies?.name || null,
      location_label: [data.address_text, data.city, data.country].filter(Boolean).join(', '),
      rate_or_salary_label: data.salary_label || null,
    });
  }

  if (listingType === 'minute_job') {
    const { data, error } = await supabase
      .from('minute_jobs')
      .select(`
        *,
        profiles:particular_user_id(
          id,
          full_name,
          city,
          country,
          avatar_path
        )
      `)
      .eq('id', listingId)
      .single();

    if (error) throw error;
    return mapListing({
      ...data,
      listing_type: 'minute_job',
      listing_id: data.id,
      owner_display_name: data.profiles?.full_name || 'Particulier UNIBOX',
      location_label: [data.address_text, data.city, data.country].filter(Boolean).join(', '),
      rate_or_salary_label: data.rate_label || null,
    });
  }

  throw new Error('listingType invalide.');
}
