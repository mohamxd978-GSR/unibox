import { supabase } from '/assets/supabase/supabase-client.js';
import { requireProfile, trimToNull } from '/assets/supabase/unibox-service-helpers.js';
import { listMyNotifications, markNotificationRead, markAllMyNotificationsRead } from '/assets/supabase/unibox-notifications.js';
import {
  listAdminReports,
  listModerationCases,
  openModerationCase,
  updateModerationCase,
  hideOfferByAdmin,
  restoreOfferByAdmin,
  hideMinuteJobByAdmin,
  restoreMinuteJobByAdmin,
  assignReport,
  resolveReport,
  dismissReport,
} from '/assets/supabase/unibox-reports.js';
import { listAdminApplications } from '/assets/supabase/unibox-applications.js';

async function logAdminAction(actionType, targetTable = null, targetId = null, detail = {}) {
  const profile = await requireProfile(['admin']);
  await supabase.from('admin_audit_logs').insert({
    admin_user_id: profile.id,
    action_type: actionType,
    target_table: targetTable,
    target_id: targetId,
    detail,
  });
}

export async function listAdminProfilesByRole(role) {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('role', role)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
}

export async function listAdminCompanies() {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('companies')
    .select(`
      *,
      owner:owner_user_id(id, full_name, email, city)
    `)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
}

export async function listAdminOffers() {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('offers')
    .select(`
      *,
      companies(id, name, city, status),
      recruiter:created_by_recruiter_user_id(id, full_name, email)
    `)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
}

export async function listAdminMinuteJobs() {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('minute_jobs')
    .select(`
      *,
      owner:particular_user_id(id, full_name, email, city)
    `)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
}

export async function listAdminApplicationsCompat() {
  const result = await listAdminApplications();
  return result.data;
}
export { listAdminApplicationsCompat as listAdminApplications };

export async function listAdminReportsCompat() {
  const result = await listAdminReports();
  return result.data;
}
export { listAdminReportsCompat as listAdminReports };

export async function listAdminModerationCases() {
  const result = await listModerationCases();
  return result.data;
}

export async function listAdminNotifications() {
  const result = await listMyNotifications();
  return result.data;
}

export async function markAdminNotificationRead(notificationId) {
  return markNotificationRead(notificationId);
}

export async function markAllAdminNotificationsRead() {
  return markAllMyNotificationsRead();
}

export async function listAdminAuditLogs() {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('admin_audit_logs')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(100);

  if (error) throw error;
  return data || [];
}

export async function updateAdminAccountStatus(profileId, accountStatus) {
  await requireProfile(['admin']);
  const patch = {
    account_status: accountStatus,
    updated_at: new Date().toISOString(),
  };

  if (accountStatus === 'active') {
    patch.onboarding_completed = true;
  }

  const { data, error } = await supabase
    .from('profiles')
    .update(patch)
    .eq('id', profileId)
    .select()
    .single();

  if (error) throw error;
  await logAdminAction('update_account_status', 'profiles', profileId, { account_status: accountStatus }).catch(() => null);
  return data;
}

export async function updateAdminCompanyStatus(companyId, status) {
  await requireProfile(['admin']);
  const { data, error } = await supabase
    .from('companies')
    .update({
      status,
      updated_at: new Date().toISOString(),
    })
    .eq('id', companyId)
    .select()
    .single();

  if (error) throw error;
  await logAdminAction('update_company_status', 'companies', companyId, { status }).catch(() => null);
  return data;
}

export async function updateAdminOfferVisibility(offerId, hiddenByAdmin, hiddenReason = '') {
  return hiddenByAdmin ? hideOfferByAdmin(offerId, hiddenReason) : restoreOfferByAdmin(offerId);
}

export async function updateAdminMinuteJobVisibility(jobId, hiddenByAdmin, hiddenReason = '') {
  return hiddenByAdmin ? hideMinuteJobByAdmin(jobId, hiddenReason) : restoreMinuteJobByAdmin(jobId);
}

export async function assignAdminReportToMe(reportId) {
  return assignReport(reportId);
}

export async function resolveAdminReport(reportId, note = '') {
  return resolveReport(reportId, note);
}

export async function dismissAdminReport(reportId, note = '') {
  return dismissReport(reportId, note);
}

export async function createAdminModerationCase(payload) {
  return openModerationCase({
    reportId: payload.report_id || payload.reportId,
    assignedAdminUserId: payload.assigned_admin_user_id || payload.assignedAdminUserId || null,
    actionType: payload.action_type || payload.actionType || 'none',
    decisionNote: payload.decision_note || payload.decisionNote || '',
    internalNote: payload.internal_note || payload.internalNote || '',
  });
}

export { updateModerationCase as updateAdminModerationCase };

export async function saveAdminSettings({ full_name = '', city = '', access_level = '' }) {
  const profile = await requireProfile(['admin']);

  const { data: updatedProfile, error: profileError } = await supabase
    .from('profiles')
    .update({
      full_name: trimToNull(full_name),
      city: trimToNull(city),
      updated_at: new Date().toISOString(),
    })
    .eq('id', profile.id)
    .select()
    .single();

  if (profileError) throw profileError;

  const { data: updatedRoleProfile, error: roleError } = await supabase
    .from('admin_profiles')
    .update({
      access_level: trimToNull(access_level) || 'platform_admin',
      updated_at: new Date().toISOString(),
    })
    .eq('user_id', profile.id)
    .select()
    .single();

  if (roleError) throw roleError;

  await logAdminAction('save_admin_settings', 'admin_profiles', profile.id, {
    full_name: trimToNull(full_name),
    city: trimToNull(city),
    access_level: trimToNull(access_level) || 'platform_admin',
  }).catch(() => null);

  return {
    profile: updatedProfile,
    roleProfile: updatedRoleProfile,
  };
}
