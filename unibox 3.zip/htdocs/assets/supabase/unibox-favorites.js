import { supabase } from '/assets/supabase/supabase-client.js';
import { requireProfile, getRange } from '/assets/supabase/unibox-service-helpers.js';

export async function listStudentFavorites({ page = 1, pageSize = 20 } = {}) {
  const profile = await requireProfile(['student']);
  const range = getRange(page, pageSize);

  const { data, error, count } = await supabase
    .from('saved_listings')
    .select(`
      *,
      offers(id, title, city, status, published_at, salary_label, contract_type, companies(id, name)),
      minute_jobs(id, title, city, status, published_at, rate_label, urgency_level, profiles(id, full_name))
    `, { count: 'exact' })
    .eq('student_user_id', profile.id)
    .order('created_at', { ascending: false })
    .range(range.from, range.to);

  if (error) throw error;
  return {
    data: data || [],
    count: count || 0,
    page: range.page,
    pageSize: range.pageSize,
  };
}

export async function saveListingToFavorites({ listingType, listingId }) {
  const profile = await requireProfile(['student']);
  if (!listingType || !listingId) {
    throw new Error('listingType et listingId sont obligatoires.');
  }

  const { data, error } = await supabase
    .from('saved_listings')
    .insert({
      student_user_id: profile.id,
      listing_type: listingType,
      offer_id: listingType === 'offer' ? listingId : null,
      minute_job_id: listingType === 'minute_job' ? listingId : null,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function removeFavorite(savedListingId) {
  const { error } = await supabase
    .from('saved_listings')
    .delete()
    .eq('id', savedListingId);

  if (error) throw error;
}
