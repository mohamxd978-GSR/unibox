import { STORAGE_BUCKETS } from '/assets/config/app.config.js';

export const SUPABASE_CONFIG = {
  url: 'https://nujydlqwrernhdqjfmjw.supabase.co',
  publishableKey: 'sb_publishable_lmP_Qu-sLGLt-gH3XKqdpA_iRPEBNGn',
  siteUrl: 'https://unibox.great-site.net',
  buckets: STORAGE_BUCKETS,
  defaults: {
    pageSize: 20,
    messagePageSize: 50,
    notificationPageSize: 30,
  },
};

export function assertSupabaseConfig() {
  if (!SUPABASE_CONFIG.url || !SUPABASE_CONFIG.publishableKey) {
    throw new Error(
      'Configuration Supabase manquante. Vérifie url et publishableKey dans /assets/supabase/supabase-config.js'
    );
  }
}