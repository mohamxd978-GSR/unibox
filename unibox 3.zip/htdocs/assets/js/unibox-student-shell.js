import { qs, appToast } from '/assets/js/unibox-core.js';
import { ROUTES } from '/assets/config/app.config.js';
import { signOutUNIBOX } from '/assets/supabase/unibox-auth.js';
import { getCurrentProfile } from '/assets/supabase/unibox-profile.js';
import { getSafeAssetUrl } from '/assets/supabase/unibox-storage.js';
import { SUPABASE_CONFIG } from '/assets/supabase/supabase-config.js';

const NAV_ITEMS = [
  { label: 'Accueil', icon: 'dashboard', href: '/student/etd-sidebar-acceuil.html', key: 'dashboard' },
  { label: 'Offres', icon: 'work', href: '/student/etd-offres.html', key: 'offers' },
  { label: 'Candidatures', icon: 'fact_check', href: '/student/etd-candidatures.html', key: 'applications' },
  { label: 'Favoris', icon: 'favorite', href: '/student/etd-favoris.html', key: 'favorites' },
  { label: 'Entretiens', icon: 'event', href: '/student/etd-entretiens.html', key: 'interviews' },
  { label: 'Messagerie', icon: 'chat', href: '/student/etd-messagerie.html', key: 'messages' },
  { label: 'Notifications', icon: 'notifications', href: '/student/etd-notifications.html', key: 'notifications' },
  { label: 'Historique', icon: 'history', href: '/student/etd-historique.html', key: 'history' },
  { label: 'Portfolio', icon: 'dashboard_customize', href: '/student/etd-portfolio.html', key: 'portfolio' },
  { label: 'Profil', icon: 'settings', href: '/student/etd-profilsettings.html', key: 'profile' },
  { label: 'Aide', icon: 'help', href: '/student/etd-help.html', key: 'help' },
];

function sidebarMarkup(activeKey) {
  return `
    <aside class="student-sidebar">
      <div class="student-sidebar-brand">
        <div class="brand-mark"><svg width="32" height="32" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="2" width="36" height="36" rx="10" fill="#6b38d4"/><path d="M20 9L30 15L20 21L10 15L20 9Z" fill="white" opacity="0.95"/><path d="M30 15L30 25L20 31L20 21L30 15Z" fill="white" opacity="0.7"/><path d="M10 15L20 21L20 31L10 25L10 15Z" fill="white" opacity="0.85"/></svg></div>
        <div class="student-sidebar-copy">
          <strong>UNIBOX</strong>
          <span>Espace étudiant</span>
        </div>
      </div>

      <p class="sidebar-section-label">NAVIGATION</p>
      <nav class="student-nav">
        ${NAV_ITEMS.map((item) => `
          <a href="${item.href}" class="student-nav-link ${item.key === activeKey ? 'is-active' : ''}">
            <span class="material-symbols-outlined">${item.icon}</span>
            <span>${item.label}</span>
          </a>
        `).join('')}
      </nav>

      <div class="student-nav-bottom">
        <div class="student-user-card" style="display: flex; align-items: center; justify-content: space-between; padding-right: 8px;">
          <a href="/student/etd-profilsettings.html" style="display: flex; align-items: center; gap: 12px; text-decoration: none; flex: 1; min-width: 0;">
            <div class="student-user-avatar" data-student-user-avatar>
              <span class="material-symbols-outlined">person</span>
            </div>
            <div class="student-user-info" style="min-width: 0;">
              <strong data-student-user-name style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block;">Chargement...</strong>
              <span data-student-user-role>Étudiant</span>
            </div>
          </a>
          <button type="button" class="btn-logout-icon" data-student-action="logout" title="Déconnexion" style="background: transparent; border: none; color: #5d576c; display: grid; place-items: center; cursor: pointer; padding: 6px; border-radius: 6px; transition: background 0.2s, color 0.2s;">
            <span class="material-symbols-outlined" style="font-size: 20px;">logout</span>
          </button>
        </div>
      </div>
    </aside>
  `;
}

function topbarMarkup(title, subtitle) {
  return `
    <header class="student-topbar">
      <div class="student-topbar-left">
        <button type="button" class="topbar-toggle" id="sidebarToggle">
          <span class="material-symbols-outlined">menu</span>
        </button>
        <div class="student-search">
          <span class="material-symbols-outlined">search</span>
          <input type="search" placeholder="Rechercher…" />
        </div>
      </div>

      <div class="student-topbar-right">
        <button type="button" class="topbar-icon-btn" title="Notifications">
          <span class="material-symbols-outlined">notifications</span>
        </button>
        <div class="topbar-user-pill" data-student-topbar-user>
          <div class="topbar-user-avatar" data-student-user-avatar>
            <span class="material-symbols-outlined">person</span>
          </div>
          <span class="topbar-user-name" data-topbar-user-name>Étudiant</span>
        </div>
      </div>
    </header>
  `;
}

export async function mountStudentShell() {
  const active = document.body.dataset.studentSection || 'dashboard';
  const title = document.body.dataset.studentTitle || 'Espace étudiant';
  const subtitle = document.body.dataset.studentSubtitle || 'Ton espace UNIBOX';

  const shell = qs('#studentShell');
  const content = qs('#studentPageContent');

  if (!shell || !content) return;

  const contentHtml = content.innerHTML;

  shell.innerHTML = `
    <div class="student-shell">
      ${sidebarMarkup(active)}
      <main class="student-main">
        ${topbarMarkup(title, subtitle)}
        <div id="studentContentMount" class="student-content">${contentHtml}</div>
      </main>
    </div>
  `;

  content.remove();

  // Sidebar toggle for mobile
  qs('#sidebarToggle')?.addEventListener('click', () => {
    qs('.student-shell')?.classList.toggle('sidebar-open');
  });

  try {
    const profile = await getCurrentProfile();
    const nameNode = qs('[data-student-user-name]');
    if (nameNode && profile?.full_name) nameNode.textContent = profile.full_name;

    // Hydrate topbar user name
    const topbarName = qs('[data-topbar-user-name]');
    if (topbarName && profile?.full_name) topbarName.textContent = profile.full_name;

    // Hydrate dashboard greeting
    const greetNode = qs('[data-student-greeting]');
    if (greetNode && profile?.full_name) {
      const firstName = profile.full_name.split(' ')[0];
      greetNode.textContent = firstName;
    }

    // Hydrate avatar
    if (profile?.avatar_path) {
      const avatarUrl = await getSafeAssetUrl(SUPABASE_CONFIG.buckets.avatars, profile.avatar_path);
      document.querySelectorAll('[data-student-user-avatar]').forEach(container => {
        container.innerHTML = `<img src="${avatarUrl}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
      });
    }
  } catch (_err) { }

  // Hydrate today's date
  const dateNode = qs('[data-today-date]');
  if (dateNode) {
    dateNode.textContent = new Date().toLocaleDateString('fr-FR', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
  }

  qs('[data-student-action="logout"]')?.addEventListener('click', async () => {
    try {
      await signOutUNIBOX();
      window.location.href = ROUTES.auth.login;
    } catch (error) {
      appToast(error.message || 'Déconnexion impossible', 'error');
    }
  });
}
