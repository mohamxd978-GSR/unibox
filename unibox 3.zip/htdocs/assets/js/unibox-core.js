import { APP_NAME } from '/assets/config/app.config.js';

const PENDING_SIGNUP_KEY = 'unibox_pending_signup';
const APP_FLASH_KEY = 'unibox_app_flash';

export function qs(selector, root = document) {
  return root.querySelector(selector);
}

export function qsa(selector, root = document) {
  return Array.from(root.querySelectorAll(selector));
}

export function go(path) {
  window.location.href = path;
}

export function readJson(key, fallback = null) {
  try {
    const raw = sessionStorage.getItem(key) || localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (_err) {
    return fallback;
  }
}

export function writeSession(key, value) {
  sessionStorage.setItem(key, JSON.stringify(value));
}

export function removeSession(key) {
  sessionStorage.removeItem(key);
}

export function setPendingSignup(payload) {
  writeSession(PENDING_SIGNUP_KEY, payload);
}

export function getPendingSignup() {
  return readJson(PENDING_SIGNUP_KEY, null);
}

export function clearPendingSignup() {
  removeSession(PENDING_SIGNUP_KEY);
}

export function setAppFlash(payload) {
  writeSession(APP_FLASH_KEY, payload);
}

export function consumeAppFlash() {
  const payload = readJson(APP_FLASH_KEY, null);
  if (payload) removeSession(APP_FLASH_KEY);
  return payload;
}

export function appToast(message, type = 'info') {
  let toast = qs('#uniboxToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'uniboxToast';
    toast.className = 'toast';
    toast.innerHTML = `
      <span class="material-symbols-outlined" data-toast-icon>info</span>
      <span data-toast-message></span>
    `;
    document.body.appendChild(toast);
  }

  const icon = qs('[data-toast-icon]', toast);
  const label = qs('[data-toast-message]', toast);
  const iconMap = {
    info: 'info',
    success: 'check_circle',
    error: 'error',
    warning: 'warning',
  };

  if (icon) icon.textContent = iconMap[type] || 'info';
  if (label) label.textContent = message;
  toast.classList.add('is-visible');
  clearTimeout(toast.__timer);
  toast.__timer = setTimeout(() => toast.classList.remove('is-visible'), 2600);
}

export function setLoading(button, isLoading, loadingText = 'Chargement...') {
  if (!button) return;
  if (!button.dataset.defaultLabel) button.dataset.defaultLabel = button.innerHTML;

  if (isLoading) {
    button.disabled = true;
    button.innerHTML = `<span class="material-symbols-outlined">progress_activity</span>${loadingText}`;
  } else {
    button.disabled = false;
    button.innerHTML = button.dataset.defaultLabel;
  }
}

function clearLegacyThemeState() {
  [document.documentElement, document.body].forEach((node) => {
    Array.from(node.classList)
      .filter((className) => className.toLowerCase().includes('theme'))
      .forEach((className) => node.classList.remove(className));
  });

  Object.keys(localStorage).forEach((key) => {
    if (key.startsWith('unibox_') && key.toLowerCase().includes('theme')) {
      localStorage.removeItem(key);
    }
  });
}

export function initYear() {
  qsa('[data-current-year]').forEach((node) => {
    node.textContent = String(new Date().getFullYear());
  });
}

function initAppFlash() {
  const flash = consumeAppFlash();
  if (flash?.message) {
    appToast(flash.message, flash.type || 'info');
  }
}

export function mountAppShell() {
  document.title = `${APP_NAME} · ${document.body.dataset.pageTitle || 'Plateforme stages, emplois et job minute'}`;
  clearLegacyThemeState();
  initYear();
  initAppFlash();
}

export function bindPasswordToggles() {
  qsa('[data-toggle-password]').forEach((button) => {
    button.addEventListener('click', () => {
      const targetId = button.getAttribute('data-toggle-password');
      const input = document.getElementById(targetId);
      if (!input) return;
      const nextType = input.type === 'password' ? 'text' : 'password';
      input.type = nextType;
      button.innerHTML = nextType === 'password'
        ? '<span class="material-symbols-outlined">visibility</span>'
        : '<span class="material-symbols-outlined">visibility_off</span>';
    });
  });
}
