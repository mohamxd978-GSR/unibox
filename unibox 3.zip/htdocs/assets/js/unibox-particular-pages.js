import { qs, qsa, appToast, setLoading } from '/assets/js/unibox-core.js';
import { mountParticularShell } from '/assets/js/unibox-particular-shell.js';
import {
  listParticularJobs,
  listParticularJobsPaginated,
  createParticularJob,
  updateParticularJob,
  getParticularJob,
  publishParticularJob,
  pauseParticularJob,
  closeParticularJob,
  completeParticularJob,
  duplicateParticularJob,
  listParticularApplications,
  getParticularApplicationDetail,
  updateParticularApplicationStatus,
  selectParticularCandidate,
  listParticularConversations,
  listParticularMessages,
  sendParticularMessage,
  getOrCreateParticularApplicationConversation,
  listParticularConversationParticipants,
  markParticularConversationRead,
  listParticularNotifications,
  markParticularNotificationRead,
  markAllParticularNotificationsRead,
  updateParticularProfile,
} from '/assets/supabase/unibox-particular.js';
import { getCurrentProfile, getRoleProfile } from '/assets/supabase/unibox-profile.js';
import { getSafeAssetUrl } from '/assets/supabase/unibox-storage.js';
import { supabase } from '/assets/supabase/supabase-client.js';

const JOB_STATUS_LABELS = {
  draft: 'Brouillon',
  published: 'Publiée',
  paused: 'En pause',
  assigned: 'Attribuée',
  completed: 'Terminée',
  closed: 'Clôturée',
  archived: 'Archivée',
};

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

const APPLICATION_STATUS_LABELS = {
  submitted: 'En examination',
  under_review: 'En examination',
  shortlisted: 'Pré-sélectionnée',
  interview_requested: 'Entretien demandé',
  accepted: 'Acceptée',
  rejected: 'Refusée',
  withdrawn: 'Retirée',
  cancelled: 'Annulée',
};

const APP_STATUS_STYLE = {
  submitted:           { label: 'En examination', bg: 'rgba(107,56,212,0.12)', color: '#6b38d4' },
  under_review:        { label: 'En examination', bg: 'rgba(107,56,212,0.12)', color: '#6b38d4' },
  shortlisted:         { label: 'Pré-sélectionnée', bg: 'rgba(245,158,11,0.12)', color: '#d97706' },
  interview_requested: { label: 'Entretien demandé', bg: 'rgba(59,130,246,0.12)', color: '#2563eb' },
  accepted:            { label: 'Acceptée', bg: 'rgba(16,185,129,0.12)', color: '#059669' },
  rejected:            { label: 'Refusée', bg: 'rgba(239,68,68,0.12)', color: '#dc2626' },
  withdrawn:           { label: 'Retirée', bg: 'rgba(107,114,128,0.12)', color: '#4b5563' },
  cancelled:           { label: 'Annulée', bg: 'rgba(107,114,128,0.12)', color: '#4b5563' },
};

function statusPill(status) {
  const s = APP_STATUS_STYLE[status] || { label: status || 'Inconnu', bg: 'rgba(107,114,128,0.12)', color: '#4b5563' };
  return `<span class="pill" style="background:${s.bg};color:${s.color};border:none;font-weight:600;">${s.label}</span>`;
}


function openModal(id) {
  const modal = qs(`#${id}`);
  if (modal) {
    modal.classList.add('is-open');
    modal.style.setProperty('display', 'flex', 'important');
  }
}

function closeModal(modal) {
  modal?.classList.remove('is-open');
  modal?.style.removeProperty('display');
}

function initModals() {
  qsa('[data-open-modal]').forEach((button) => {
    button.addEventListener('click', () => openModal(button.dataset.openModal));
  });

  qsa('[data-modal]').forEach((modal) => {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeModal(modal);
    });
  });

  qsa('[data-close-modal]').forEach((button) => {
    button.addEventListener('click', () => closeModal(button.closest('[data-modal]')));
  });
}

function formatStatus(status) {
  return JOB_STATUS_LABELS[status] || status || '—';
}

function formatApplicationStatus(status) {
  return APPLICATION_STATUS_LABELS[status] || status || '—';
}

function formatDateTime(value) {
  if (!value) return 'À préciser';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'À préciser';
  return date.toLocaleString('fr-FR', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}

function formatDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('fr-FR', { dateStyle: 'medium' });
}

function formatLocation(item = {}) {
  return [item.address_text, item.city, item.country].filter(Boolean).join(' · ') || 'Localisation à préciser';
}

function formatUrgency(level) {
  const value = String(level || 'normal').toLowerCase();
  if (value === 'urgent') return 'Urgence élevée';
  if (value === 'high') return 'Priorité haute';
  return 'Rythme normal';
}

function renderJobs(target, items) {
  if (!target) return;
  if (!items.length) {
    target.innerHTML = `
      <div class="empty-state small">
        <strong>Aucune mission pour l’instant</strong>
        <span>Crée ta première mission UNIBOX pour commencer à recevoir des candidatures.</span>
      </div>
    `;
    return;
  }

  target.innerHTML = items.map((item) => {
    const statusClass = `status-${item.status || 'draft'}`;
    const statusLabel = formatStatus(item.status);
    const appCount = item.applications_count || 0;
    const locParts = [item.address_text, item.city].filter(Boolean);
    const locationText = locParts.length ? locParts.join(', ') : 'Localisation non précisée';
    const startDate = item.starts_at ? formatDateTime(item.starts_at) : null;

    return `
    <article class="offer-card" data-job-status="${escapeHtml(item.status || '')}" style="background:#fff;border:1px solid #ede9f8;border-radius:14px;overflow:hidden;transition:box-shadow 0.2s ease;margin-bottom:14px;">
      <div style="display:flex;align-items:center;gap:16px;padding:20px 24px;">
        <div style="width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,#6b38d4,#8a5ff1);display:grid;place-items:center;flex-shrink:0;box-shadow:0 3px 10px rgba(107,56,212,0.20);">
          <span class="material-symbols-outlined" style="font-size:24px;color:#fff;">work</span>
        </div>
        <div style="flex:1;min-width:0;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap;">
            <h3 style="margin:0;font-size:15px;font-weight:700;color:#1b1b25;line-height:1.3;">${escapeHtml(item.title || 'Mission UNIBOX')}</h3>
            <span class="offer-card-status ${statusClass}">${escapeHtml(statusLabel)}</span>
          </div>
          <p style="margin:0 0 6px;font-size:13px;color:#6b38d4;font-weight:600;">${escapeHtml(formatUrgency(item.urgency_level))} · ${escapeHtml(item.rate_label || 'Tarif à préciser')}</p>
          <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;">
            <span class="pill soft" style="font-size:11px;padding:3px 8px;background:#f8f6ff;border:1px solid #ede9f8;">
              <span class="material-symbols-outlined" style="font-size:12px;">location_on</span>
              ${escapeHtml(locationText)}
            </span>
            ${startDate ? `<span class="pill soft" style="font-size:11px;padding:3px 8px;background:#f8f6ff;border:1px solid #ede9f8;">
              <span class="material-symbols-outlined" style="font-size:12px;">event</span>
              ${escapeHtml(startDate)}
            </span>` : ''}
            <span class="pill soft" style="font-size:11px;padding:3px 8px;background:#f8f6ff;border:1px solid #ede9f8;">
              <span class="material-symbols-outlined" style="font-size:12px;">group</span>
              ${item.needed_people_count || 1} pers.
            </span>
            ${appCount > 0 ? `<span style="font-size:11px;color:#6b38d4;display:flex;align-items:center;gap:3px;font-weight:600;">
              <span class="material-symbols-outlined" style="font-size:12px;">person</span>
              ${appCount} cand.
            </span>` : ''}
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;flex-shrink:0;">
          <a class="btn btn-primary" href="/particular/job-detail.html?job=${item.id}" style="justify-content:center;min-width:110px;font-size:13px;padding:8px 14px;">
            <span class="material-symbols-outlined" style="font-size:16px;">visibility</span>
            Voir
          </a>
          <a class="btn btn-secondary" href="/particular/job-candidatures.html?job=${item.id}" style="justify-content:center;font-size:13px;padding:8px 14px;">
            <span class="material-symbols-outlined" style="font-size:16px;">fact_check</span>
            Cand.
          </a>
        </div>
      </div>
    </article>
  `;
  }).join('');
}

function candidateAvatarHtml(item) {
  const initials = (item.profiles?.full_name || 'C').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  const avatarPath = item.profiles?.avatar_path;
  if (avatarPath) {
    return `<div class="app-candidate-avatar" data-avatar-path="${escapeHtml(avatarPath)}">${escapeHtml(initials)}</div>`;
  }
  return `<div class="app-candidate-avatar">${escapeHtml(initials)}</div>`;
}

function renderApplications(target, items) {
  if (!target) return;
  if (!items.length) {
    target.innerHTML = `
      <div class="empty-state small">
        <strong>Aucune candidature pour le moment</strong>
        <span>Les candidatures reçues sur tes missions UNIBOX apparaîtront ici.</span>
      </div>
    `;
    return;
  }

  target.innerHTML = items.map((item) => {
    const missionTitle = item.minute_jobs?.title || item.minute_job_title || 'Mission UNIBOX';
    const docsCount = (item.application_documents || []).length;
    const candidateName = item.profiles?.full_name || 'Candidate UNIBOX';
    const candidateEmail = item.profiles?.email || '';
    const candidateCity = item.profiles?.city || '';
    return `
      <article class="app-card" data-app-status="${escapeHtml(item.status || '')}">
        <div class="app-card-inner">
          <div class="app-card-avatar-col">
            ${candidateAvatarHtml(item)}
          </div>
          <div class="app-card-body">
            <div class="app-card-top">
              <div>
                <h3 class="app-card-name">${escapeHtml(candidateName)}</h3>
                <p class="app-card-job">${escapeHtml(missionTitle)}</p>
              </div>
            </div>
            <div class="app-card-meta">
              ${statusPill(item.status)}
              <span class="pill soft">Job minute</span>
              ${candidateEmail ? `<span class="pill soft">${escapeHtml(candidateEmail)}</span>` : ''}
              ${candidateCity ? `<span class="pill soft">${escapeHtml(candidateCity)}</span>` : ''}
              <span class="pill soft">${docsCount} doc${docsCount > 1 ? 's' : ''}</span>
            </div>
            <p class="app-card-date">Soumis le ${escapeHtml(formatDateTime(item.submitted_at))}</p>
          </div>
          <div class="app-card-action-col">
            <a class="btn btn-primary" href="/particular/job-candidate-detail.html?application=${item.id}&job=${item.minute_job_id || item.minute_jobs?.id || ''}" style="padding: 8px 14px; font-size: 13px;">
              <span class="material-symbols-outlined" style="font-size:16px;">visibility</span>
              Voir
            </a>
            ${['accepted', 'rejected'].includes(item.status) ? '' : `<button type="button" class="btn btn-secondary" data-accept-application="${item.id}" data-job-id="${item.minute_job_id || item.minute_jobs?.id || ''}" style="padding: 8px 14px; font-size: 13px;">
              <span class="material-symbols-outlined" style="font-size:16px;">check</span>
              Accepter
            </button>`}
          </div>
        </div>
      </article>
    `;
  }).join('');

  // Async hydrate avatars with real images
  qsa('[data-avatar-path]', target).forEach(async (el) => {
    try {
      const url = await getSafeAssetUrl('avatars', el.dataset.avatarPath);
      el.innerHTML = `<img src="${url}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    } catch (_) {}
  });
}

function renderEmptyState(target, title, body) {
  if (!target) return;
  target.innerHTML = `
    <div class="empty-state">
      <strong>${title}</strong>
      <span>${body}</span>
    </div>
  `;
}

function renderCandidateDocuments(documents = []) {
  if (!documents.length) {
    return '<p style="margin:0;font-size:13px;color:#8b85a0;font-style:italic;">Aucun document envoyé pour cette candidature.</p>';
  }

  return `<div style="display:flex;flex-direction:column;gap:8px;">${documents.map((document) => `
    <a href="${escapeHtml(document.signed_url || '#')}" ${document.signed_url ? 'target="_blank" rel="noopener"' : ''} style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:#f8f6ff;border:1px solid #ede9f8;border-radius:8px;text-decoration:none;transition:background 0.15s ease;" onmouseover="this.style.background='#f0ecff'" onmouseout="this.style.background='#f8f6ff'">
      <span class="material-symbols-outlined" style="font-size:20px;color:#6b38d4;flex-shrink:0;">description</span>
      <div style="min-width:0;">
        <div style="font-size:13px;font-weight:600;color:#1b1b25;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(document.file_name || 'Document')}</div>
        <div style="font-size:11px;color:#8b85a0;margin-top:2px;">${escapeHtml(document.mime_type || 'PDF')}</div>
      </div>
      <span class="material-symbols-outlined" style="font-size:16px;color:#8b85a0;flex-shrink:0;margin-left:auto;">open_in_new</span>
    </a>
  `).join('')}</div>`;
}

function renderApplicationTimeline(events = []) {
  if (!events.length) {
    return '<p style="margin:0;font-size:13px;color:#8b85a0;font-style:italic;">Aucun historique disponible pour le moment.</p>';
  }

  const items = events.map((event, index) => {
    const s = APP_STATUS_STYLE[event.to_status || event.status] || { label: event.to_status || event.status || 'Inconnu', color: '#5d576c', bg: 'rgba(107,114,128,0.08)' };
    const isLast = index === events.length - 1;
    return `
      <div style="display:flex;gap:12px;${!isLast ? 'margin-bottom:12px;' : ''}">
        <div style="display:flex;flex-direction:column;align-items:center;flex-shrink:0;">
          <div style="width:10px;height:10px;border-radius:50%;background:${s.color};box-shadow:0 0 0 3px ${s.bg || 'rgba(107,114,128,0.08)'};flex-shrink:0;"></div>
          ${!isLast ? '<div style="width:2px;flex:1;background:linear-gradient(to bottom, #ddd6ea, transparent);margin-top:4px;"></div>' : ''}
        </div>
        <div style="flex:1;min-width:0;padding-bottom:4px;">
          <div style="font-size:13px;font-weight:600;color:${s.color};">${escapeHtml(s.label)}</div>
          <div style="font-size:11px;color:#8b85a0;margin-top:2px;">${escapeHtml(formatDateTime(event.created_at))}</div>
          ${event.notes ? `<div style="font-size:12px;color:#5d576c;margin-top:4px;line-height:1.4;">${escapeHtml(event.notes)}</div>` : ''}
        </div>
      </div>
    `;
  }).join('');

  return `<div style="display:flex;flex-direction:column;">${items}</div>`;
}

function getNotificationIcon(title = '', body = '') {
  const text = (title + ' ' + body).toLowerCase();
  if (text.includes('candidat') || text.includes('candidature')) return 'person_add';
  if (text.includes('message') || text.includes('messag')) return 'chat';
  if (text.includes('mission') || text.includes('job') || text.includes('poste')) return 'work';
  if (text.includes('entretien') || text.includes('interview')) return 'event';
  if (text.includes('accept') || text.includes('approv')) return 'check_circle';
  if (text.includes('refus') || text.includes('reject')) return 'cancel';
  if (text.includes('shortlist')) return 'star';
  return 'notifications';
}

function getNotificationColor(title = '', body = '') {
  const text = (title + ' ' + body).toLowerCase();
  if (text.includes('candidat') || text.includes('candidature')) return '#6b38d4';
  if (text.includes('message')) return '#0ea5e9';
  if (text.includes('mission') || text.includes('job')) return '#f59e0b';
  if (text.includes('entretien') || text.includes('interview')) return '#f59e0b';
  if (text.includes('accept') || text.includes('approv')) return '#10b981';
  if (text.includes('refus') || text.includes('reject')) return '#dc2626';
  if (text.includes('shortlist')) return '#8b5cf6';
  return '#6b7280';
}

function renderNotifications(target, items) {
  if (!target) return;
  target.innerHTML = items.map((item) => {
    const icon = getNotificationIcon(item.title, item.body);
    const color = getNotificationColor(item.title, item.body);
    const isNew = !item.is_read;
    const timeAgo = formatDateTime(item.created_at);

    return `
    <article class="notification-card" style="${isNew ? 'border-left: 3px solid ' + color + '; background: linear-gradient(135deg, #f8f6ff 0%, #ffffff 100%);' : ''} padding: 0; overflow: hidden;">
      <div style="display: flex; align-items: flex-start; gap: 16px; padding: 18px 20px;">
        <div style="flex-shrink: 0; width: 44px; height: 44px; border-radius: 12px; background: ${isNew ? color + '15' : '#f5f2ff'}; display: grid; place-items: center;">
          <span class="material-symbols-outlined" style="font-size: 22px; color: ${color};">${icon}</span>
        </div>
        <div style="flex: 1; min-width: 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 4px;">
            <h3 style="margin: 0; font-size: 15px; font-weight: 600; color: #1b1b25; line-height: 1.4;">${escapeHtml(item.title)}</h3>
            ${isNew ? `<span style="flex-shrink: 0; width: 8px; height: 8px; border-radius: 50%; background: ${color}; margin-top: 6px;"></span>` : ''}
          </div>
          <p style="margin: 0 0 8px; color: #5d576c; font-size: 14px; line-height: 1.5;">${escapeHtml(item.body)}</p>
          <span style="font-size: 12px; color: #a09ab8; display: flex; align-items: center; gap: 4px;">
            <span class="material-symbols-outlined" style="font-size: 14px;">schedule</span>
            ${escapeHtml(timeAgo)}
          </span>
        </div>
      </div>
      <div style="display: flex; gap: 8px; padding: 0 20px 14px 80px;">
        ${item.action_url ? `<a class="btn btn-primary" href="${escapeHtml(item.action_url)}" style="padding: 6px 14px; font-size: 13px;">Ouvrir</a>` : ''}
        ${isNew ? `<button class="btn btn-secondary" type="button" data-particular-read-notification="${item.id}" style="padding: 6px 14px; font-size: 13px;">Marquer comme lu</button>` : ''}
      </div>
    </article>
  `}).join('');
}

function collectJobFormData() {
  const startsAtRaw = qs('#jobStartsAt')?.value || '';
  const durationHoursValue = Number(qs('#jobDurationHours')?.value || 0);
  const startsAtIso = startsAtRaw ? new Date(startsAtRaw).toISOString() : null;
  const endsAtIso = startsAtRaw && durationHoursValue > 0
    ? new Date(new Date(startsAtRaw).getTime() + (durationHoursValue * 60 * 60 * 1000)).toISOString()
    : null;

  return {
    title: qs('#jobTitle')?.value.trim(),
    category: qs('#jobCategory')?.value.trim(),
    summary: qs('#jobSummary')?.value.trim(),
    description: qs('#jobDescription')?.value.trim(),
    requirements: qs('#jobRequirements')?.value.trim(),
    address_text: qs('#jobAddress')?.value.trim(),
    city: qs('#jobCity')?.value.trim(),
    country: qs('#jobCountry')?.value.trim(),
    starts_at: startsAtIso,
    ends_at: endsAtIso,
    duration_hours: durationHoursValue || null,
    needed_people_count: Number(qs('#jobNeededPeople')?.value || 1),
    rate_amount: Number(qs('#jobRateAmount')?.value || 0) || null,
    rate_currency: qs('#jobRateCurrency')?.value || 'EUR',
    rate_label: qs('#jobRateLabel')?.value.trim(),
    urgency_level: qs('#jobUrgency')?.value || 'normal',
  };
}

async function loadJobs({ status = 'all', search = '', page = 1 } = {}) {
  return listParticularJobsPaginated({ status, search, page, pageSize: 24 });
}

function setMissionSuccessLink(jobId) {
  const link = qs('#jobPublishSuccessLink');
  if (link && jobId) link.href = `/particular/job-detail.html?job=${jobId}`;
}

async function initDashboard() {
  try {
    const jobs = await listParticularJobs();
    renderJobs(qs('#particularDashboardJobs'), jobs.slice(0, 3));

    const applications = await listParticularApplications().catch(() => []);
    const metrics = {
      jobs: jobs.length,
      published: jobs.filter((item) => item.status === 'published').length,
      applications: applications.length,
      selected: jobs.filter((item) => item.selected_application_id).length,
    };

    Object.entries(metrics).forEach(([key, value]) => {
      const node = qs(`[data-kpi="${key}"]`);
      if (node) node.textContent = String(value);
    });
  } catch (error) {
    renderJobs(qs('#particularDashboardJobs'), []);
    appToast(error.message || 'Impossible de charger le dashboard particulier', 'error');
  }
}

async function initCreate() {
  // Wizard navigation
  let currentStep = 1;
  const totalSteps = 3;
  const progressLine = qs('#wizardProgressLine');

  function showStep(step) {
    qsa('.wizard-step').forEach(el => {
      el.style.display = el.dataset.step === String(step) ? 'flex' : 'none';
    });
    qsa('.wizard-dot-container').forEach(container => {
      const dotNum = parseInt(container.dataset.dot, 10);
      const dot = container.querySelector('.wizard-dot');
      const label = container.querySelector('span');
      const isActive = dotNum === step;
      const isCompleted = dotNum < step;

      container.classList.toggle('active', isActive);

      if (isActive) {
        dot.style.background = '#6b38d4';
        dot.style.color = 'white';
        label.style.color = '#1b1b25';
      } else if (isCompleted) {
        dot.style.background = '#6b38d4';
        dot.style.color = 'white';
        label.style.color = '#1b1b25';
      } else {
        dot.style.background = '#ede9f8';
        dot.style.color = '#5d576c';
        label.style.color = '#a09ab8';
      }
    });
    if (progressLine) {
      const pct = ((step - 1) / (totalSteps - 1)) * 100;
      progressLine.style.width = `${pct}%`;
    }
    currentStep = step;
  }

  qsa('.btn-next').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = parseInt(btn.dataset.targetStep, 10);
      if (target) showStep(target);
    });
  });

  qsa('.btn-prev').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = parseInt(btn.dataset.targetStep, 10);
      if (target) showStep(target);
    });
  });

  showStep(1);

  qs('#particularJobCreateForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const button = qs('#jobCreateSubmit');
    try {
      setLoading(button, true, 'Publication...');
      const created = await createParticularJob({ ...collectJobFormData(), status: 'published' });
      setMissionSuccessLink(created.id);
      appToast('Mission publiée', 'success');
      openModal('jobPublishSuccessModal');
    } catch (error) {
      appToast(error.message || 'Impossible de publier la mission', 'error');
    } finally {
      setLoading(button, false);
    }
  });

  qs('#jobCreateDraft')?.addEventListener('click', async () => {
    const button = qs('#jobCreateDraft');
    try {
      setLoading(button, true, 'Enregistrement...');
      const created = await createParticularJob({ ...collectJobFormData(), status: 'draft' });
      appToast('Brouillon enregistré', 'success');
      window.location.href = `/particular/job-detail.html?job=${created.id}`;
    } catch (error) {
      appToast(error.message || 'Impossible d’enregistrer le brouillon', 'error');
    } finally {
      setLoading(button, false);
    }
  });
}

async function initMissions() {
  const listTarget = qs('#particularMissionsList');
  const countTarget = qs('#particularMissionsCount');
  const statusInput = qs('#particularStatusFilter');
  const searchInput = qs('#particularMissionSearch');

  async function refresh() {
    const status = statusInput?.value || 'all';
    const search = searchInput?.value || '';
    try {
      const result = await loadJobs({ status, search });
      renderJobs(listTarget, result.data);
      if (countTarget) {
        countTarget.textContent = `${result.count} mission${result.count > 1 ? 's' : ''}`;
      }
    } catch (error) {
      if (listTarget) {
        listTarget.innerHTML = `
          <div class="empty-state small">
            <strong>Impossible de charger les missions</strong>
            <span>${error.message || 'Réessaie dans un instant.'}</span>
          </div>
        `;
      }
    }
  }

  qsa('[data-status-chip]').forEach((button) => {
    button.addEventListener('click', () => {
      qsa('[data-status-chip]').forEach((node) => node.classList.remove('is-active'));
      button.classList.add('is-active');
      if (statusInput) statusInput.value = button.dataset.statusChip || 'all';
      refresh();
    });
  });

  searchInput?.addEventListener('input', () => refresh());
  qs('#particularMissionsRefresh')?.addEventListener('click', refresh);

  await refresh();
}

async function initDetail() {
  const params = new URLSearchParams(window.location.search);
  const jobId = params.get('job');
  const mount = qs('#particularJobDetailMount');
  const relatedMount = qs('#particularJobApplicationsHint');

  if (!jobId) {
    if (mount) {
      mount.innerHTML = `
        <section class="particular-section">
          <div class="empty-state">
            <strong>Aucune mission sélectionnée</strong>
            <span>Retourne dans Mes missions pour ouvrir une mission UNIBOX existante.</span>
          </div>
        </section>
      `;
    }
    return;
  }

  let data;
  try {
    data = await getParticularJob(jobId);
  } catch (error) {
    if (mount) {
      mount.innerHTML = `
        <section class="particular-section">
          <div class="empty-state">
            <strong>Mission introuvable</strong>
            <span>${error.message || 'Cette mission n’est pas accessible.'}</span>
          </div>
        </section>
      `;
    }
    return;
  }

  const status = data.status || 'draft';
  const canPublish = ['draft', 'paused', 'closed'].includes(status);
  const canPause = status === 'published';
  const canClose = ['published', 'paused'].includes(status);
  const canComplete = ['published', 'closed'].includes(status);

  const statusClass = `status-${status}`;
  const statusLabel = formatStatus(status);
  const appCount = data.applications_count || 0;

  mount.innerHTML = `
    <section class="dash-card" style="padding: 0; overflow: hidden;">
      <!-- Header Banner -->
      <div style="background: linear-gradient(135deg, #6b38d4 0%, #8a5ff1 100%); padding: 28px; position: relative; overflow: hidden;">
        <div style="position: absolute; top: -40px; right: -40px; width: 160px; height: 160px; border-radius: 50%; background: rgba(255,255,255,0.08); pointer-events: none;"></div>
        <div style="position: absolute; bottom: -20px; left: 20%; width: 100px; height: 100px; border-radius: 50%; background: rgba(255,255,255,0.05); pointer-events: none;"></div>

        <div style="display: flex; align-items: center; gap: 20px; position: relative; z-index: 1;">
          <div style="width: 64px; height: 64px; border-radius: 16px; background: rgba(255,255,255,0.18); display: grid; place-items: center; flex-shrink: 0;">
            <span class="material-symbols-outlined" style="font-size: 32px; color: #fff;">work</span>
          </div>
          <div style="flex: 1; min-width: 0;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 4px; flex-wrap: wrap;">
              <h2 style="margin: 0; font-size: 22px; font-weight: 700; color: #fff;">${escapeHtml(data.title || 'Mission UNIBOX')}</h2>
              <span class="offer-card-status ${statusClass}" style="background: rgba(255,255,255,0.2); color: #fff; border-color: rgba(255,255,255,0.3);">${escapeHtml(statusLabel)}</span>
            </div>
            <p style="margin: 0; color: rgba(255,255,255,0.85); font-size: 14px;">${escapeHtml(data.category || 'Mission particulier')}</p>
          </div>
        </div>

        <div style="display: flex; gap: 16px; margin-top: 16px; flex-wrap: wrap; position: relative; z-index: 1;">
          <div style="display: flex; align-items: center; gap: 6px; color: rgba(255,255,255,0.9); font-size: 13px;">
            <span class="material-symbols-outlined" style="font-size: 16px;">location_on</span>
            ${escapeHtml(formatLocation(data) || 'À compléter')}
          </div>
          <div style="display: flex; align-items: center; gap: 6px; color: rgba(255,255,255,0.9); font-size: 13px;">
            <span class="material-symbols-outlined" style="font-size: 16px;">event</span>
            ${escapeHtml(formatDateTime(data.starts_at) || 'À définir')}
          </div>
          <div style="display: flex; align-items: center; gap: 6px; color: rgba(255,255,255,0.9); font-size: 13px;">
            <span class="material-symbols-outlined" style="font-size: 16px;">schedule</span>
            ${data.duration_hours ? `${escapeHtml(data.duration_hours)} h` : 'Durée à préciser'}
          </div>
        </div>
      </div>

      <!-- Body -->
      <div style="padding: 28px;">
        <!-- Info Grid -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 24px;">
          <div style="background: #f8f6ff; border-radius: 10px; padding: 14px; border: 1px solid #ede9f8;">
            <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; font-weight: 600;">Localisation</span>
            <span style="font-size: 13px; color: #1b1b25; font-weight: 500;">${escapeHtml(formatLocation(data) || 'À compléter')}</span>
          </div>
          <div style="background: #f8f6ff; border-radius: 10px; padding: 14px; border: 1px solid #ede9f8;">
            <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; font-weight: 600;">Début</span>
            <span style="font-size: 13px; color: #1b1b25; font-weight: 500;">${escapeHtml(formatDateTime(data.starts_at) || 'À définir')}</span>
          </div>
          <div style="background: #f8f6ff; border-radius: 10px; padding: 14px; border: 1px solid #ede9f8;">
            <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; font-weight: 600;">Durée</span>
            <span style="font-size: 13px; color: #1b1b25; font-weight: 500;">${data.duration_hours ? `${escapeHtml(data.duration_hours)} h` : 'À préciser'}</span>
          </div>
          <div style="background: #f8f6ff; border-radius: 10px; padding: 14px; border: 1px solid #ede9f8;">
            <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; font-weight: 600;">Participants</span>
            <span style="font-size: 13px; color: #1b1b25; font-weight: 500;">${escapeHtml(data.needed_people_count || 1)}</span>
          </div>
          <div style="background: #f8f6ff; border-radius: 10px; padding: 14px; border: 1px solid #ede9f8;">
            <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; font-weight: 600;">Budget</span>
            <span style="font-size: 13px; color: #1b1b25; font-weight: 500;">${data.rate_amount ? `${escapeHtml(data.rate_amount)} ${escapeHtml(data.rate_currency || 'EUR')}` : (escapeHtml(data.rate_label) || 'À préciser')}</span>
          </div>
          <div style="background: #f8f6ff; border-radius: 10px; padding: 14px; border: 1px solid #ede9f8;">
            <span style="display: block; font-size: 11px; color: #5d576c; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px; font-weight: 600;">Urgence</span>
            <span style="font-size: 13px; color: #1b1b25; font-weight: 500;">${escapeHtml(formatUrgency(data.urgency_level))}</span>
          </div>
        </div>

        <!-- Description -->
        <div style="margin-bottom: 24px;">
          <h3 style="font-size: 13px; font-weight: 700; color: #1b1b25; margin: 0 0 10px; display: flex; align-items: center; gap: 8px;">
            <span class="material-symbols-outlined" style="font-size: 18px; color: #6b38d4;">description</span>
            Description
          </h3>
          <div style="background: #f8f6ff; border-radius: 10px; padding: 16px; border: 1px solid #ede9f8;">
            <p style="margin: 0; color: #334155; font-size: 14px; line-height: 1.6;">${escapeHtml(data.description || data.summary || 'Mission UNIBOX détaillée côté particulier.')}</p>
          </div>
        </div>

        ${data.requirements ? `
        <div style="margin-bottom: 24px;">
          <h3 style="font-size: 13px; font-weight: 700; color: #1b1b25; margin: 0 0 10px; display: flex; align-items: center; gap: 8px;">
            <span class="material-symbols-outlined" style="font-size: 18px; color: #6b38d4;">task_alt</span>
            Exigences
          </h3>
          <div style="background: #f8f6ff; border-radius: 10px; padding: 16px; border: 1px solid #ede9f8;">
            <p style="margin: 0; color: #334155; font-size: 14px; line-height: 1.6;">${escapeHtml(data.requirements)}</p>
          </div>
        </div>
        ` : ''}

        <!-- Actions -->
        <div style="margin-top: 28px; padding-top: 24px; border-top: 1px solid #f0edf7; display: flex; flex-wrap: wrap; gap: 10px; justify-content: center;">
          <a class="btn btn-primary" href="/particular/job-candidatures.html?job=${data.id}" style="box-shadow:0 2px 8px rgba(107,56,212,0.18);">
            <span class="material-symbols-outlined" style="font-size:18px;">fact_check</span>
            Voir les candidatures
          </a>
          ${canPublish ? '<button type="button" class="btn btn-secondary" data-open-modal="jobPublishModal"><span class="material-symbols-outlined" style="font-size:18px;">publish</span> Publier</button>' : ''}
          ${canPause ? '<button type="button" class="btn btn-secondary" data-open-modal="jobPauseModal"><span class="material-symbols-outlined" style="font-size:18px;">pause</span> Mettre en pause</button>' : ''}
          ${canClose ? '<button type="button" class="btn btn-secondary" data-open-modal="jobCloseModal"><span class="material-symbols-outlined" style="font-size:18px;">close</span> Clôturer</button>' : ''}
          ${canComplete ? '<button type="button" class="btn btn-secondary" data-open-modal="jobCompleteModal"><span class="material-symbols-outlined" style="font-size:18px;">check_circle</span> Marquer terminée</button>' : ''}
          <button type="button" class="btn btn-secondary" data-open-modal="jobDuplicateModal"><span class="material-symbols-outlined" style="font-size:18px;">content_copy</span> Dupliquer</button>
        </div>
      </div>
    </section>
  `;

  if (relatedMount) {
    relatedMount.innerHTML = '';
  }

  const withAction = (selector, label, action) => {
    qs(selector)?.addEventListener('click', async () => {
      const button = qs(selector);
      try {
        setLoading(button, true, label);
        const result = await action();
        appToast('Mission mise à jour', 'success');
        const nextId = result?.id || data.id;
        window.location.href = `/particular/job-detail.html?job=${nextId}`;
      } catch (error) {
        appToast(error.message || 'Action impossible sur cette mission', 'error');
      } finally {
        setLoading(button, false);
      }
    });
  };

  withAction('#jobPublishConfirm', 'Publication...', () => publishParticularJob(data.id));
  withAction('#jobPauseConfirm', 'Pause...', () => pauseParticularJob(data.id));
  withAction('#jobCloseConfirm', 'Clôture...', () => closeParticularJob(data.id));
  withAction('#jobCompleteConfirm', 'Finalisation...', () => completeParticularJob(data.id));
  withAction('#jobDuplicateConfirm', 'Duplication...', () => duplicateParticularJob(data.id));
}

async function initApplications() {
  const mount = qs('#particularApplicationsList');
  const applications = await listParticularApplications().catch((error) => {
    appToast(error.message || 'Impossible de charger les candidatures.', 'error');
    return [];
  });

  const countPill = qs('#particularApplicationsCount');
  if (countPill) countPill.textContent = `${applications.length} candidature${applications.length > 1 ? 's' : ''}`;

  function bindAcceptButtons() {
    qsa('[data-accept-application]').forEach((button) => {
      button.addEventListener('click', async () => {
        const appId = button.dataset.acceptApplication;
        const jobId = button.dataset.jobId;
        console.log('[DEBUG] Accepter clic - appId:', appId, 'jobId:', jobId);
        if (!jobId) {
          appToast('ID mission manquant - impossible de sélectionner', 'error');
          return;
        }
        try {
          await selectParticularCandidate(jobId, appId);
          appToast('Candidate sélectionnée', 'success');
        } catch (error) {
          console.error('[DEBUG] Erreur acceptation:', error);
          appToast(error.message || 'Impossible de sélectionner cette candidature', 'error');
        }
      });
    });
  }

  function applyFilter(status) {
    const filtered = status === 'all'
      ? applications
      : applications.filter(i => {
          if (status === 'submitted') return ['submitted', 'under_review', 'shortlisted', 'interview_requested'].includes(i.status);
          return i.status === status;
        });
    renderApplications(mount, filtered);
    bindAcceptButtons();
  }

  renderApplications(mount, applications);
  bindAcceptButtons();

  qsa('[data-app-status-filter]').forEach((chip) => {
    chip.addEventListener('click', () => {
      qsa('[data-app-status-filter]').forEach(c => c.classList.remove('is-active'));
      chip.classList.add('is-active');
      applyFilter(chip.dataset.appStatusFilter);
    });
  });
}

async function initCandidateDetail() {
  const params = new URLSearchParams(window.location.search);
  const jobId = params.get('job');
  const applicationId = params.get('application');
  const mount = qs('#particularCandidateDetailMount');
  const actions = qs('#particularCandidateActions');

  if (!applicationId) {
    renderEmptyState(mount, 'Candidature introuvable', 'Le lien reçu est incomplet.');
    return;
  }

  let application;
  try {
    application = await getParticularApplicationDetail(applicationId);
  } catch (error) {
    renderEmptyState(mount, 'Impossible de charger le dossier', error.message || 'Réessaie dans un instant.');
    return;
  }

  const student = application.profiles || {};
  const studentProfile = application.student_profile || {};
  const missionTitle = application.minute_jobs?.title || 'Mission UNIBOX';
  const effectiveJobId = jobId || application.minute_job_id || application.minute_jobs?.id;
  const initials = (student.full_name || 'C').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();

  let avatarHtml = `<div class="modal-candidate-avatar">${escapeHtml(initials)}</div>`;
  if (student.avatar_path) {
    try {
      const avatarUrl = await getSafeAssetUrl('avatars', student.avatar_path);
      avatarHtml = `<div class="modal-candidate-avatar"><img src="${avatarUrl}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;"></div>`;
    } catch (_) {}
  }

  mount.innerHTML = `
    <div class="dash-card" style="padding:24px;">
      <!-- Header candidat -->
      <div style="display:flex;align-items:flex-start;gap:18px;padding:0 0 20px;border-bottom:1px solid #ede9f8;">
        ${avatarHtml}
        <div style="flex:1;min-width:0;">
          <h4 class="modal-candidate-name">${escapeHtml(student.full_name || 'Candidate UNIBOX')}</h4>
          <p class="modal-candidate-sub">${escapeHtml(student.email || '')}</p>
          <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;">
            ${student.city ? `<span class="pill soft"><span class="material-symbols-outlined" style="font-size:13px;">location_on</span> ${escapeHtml(student.city)}</span>` : ''}
            ${statusPill(application.status)}
            <span class="pill soft">Job minute</span>
            <span class="pill soft">Soumis le ${escapeHtml(formatDateTime(application.submitted_at))}</span>
          </div>
        </div>
      </div>

      <!-- Mission -->
      <div style="padding:20px 0;border-bottom:1px solid #ede9f8;">
        <p style="margin:0 0 6px;font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Mission</p>
        <h3 style="margin:0;font-size:16px;font-weight:700;color:#1b1b25;">${escapeHtml(missionTitle)}</h3>
        ${application.message_body ? `<p style="margin:12px 0 0;font-size:14px;color:#5d576c;font-style:italic;border-left:3px solid #6b38d4;padding-left:12px;line-height:1.5;">${escapeHtml(application.message_body)}</p>` : ''}
      </div>

      <!-- Documents & Historique -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;padding:20px 0;border-bottom:1px solid #ede9f8;">
        <div>
          <h4 style="margin:0 0 14px;font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Documents soumis</h4>
          ${renderCandidateDocuments(application.application_documents || [])}
        </div>
        <div>
          <h4 style="margin:0 0 14px;font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Historique des statuts</h4>
          ${renderApplicationTimeline(application.application_status_events || [])}
        </div>
      </div>

      <!-- Profil étudiant -->
      ${studentProfile?.bio || studentProfile?.skills || studentProfile?.headline ? `
      <div style="border-top:1px solid #ede9f8;padding-top:20px;">
        <h4 style="margin:0 0 12px;font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Profil étudiant</h4>
        <div style="display:flex;flex-direction:column;">
          ${studentProfile.headline ? `
          <div style="padding:10px 0;border-bottom:1px solid #ede9f8;">
            <div style="font-size:11px;color:#8b85a0;text-transform:uppercase;letter-spacing:.03em;font-weight:600;">Titre</div>
            <div style="font-size:14px;color:#1b1b25;font-weight:500;margin-top:2px;">${escapeHtml(studentProfile.headline)}</div>
          </div>` : ''}
          ${studentProfile.skills ? `
          <div style="padding:10px 0;border-bottom:1px solid #ede9f8;">
            <div style="font-size:11px;color:#8b85a0;text-transform:uppercase;letter-spacing:.03em;font-weight:600;">Compétences</div>
            <div style="font-size:14px;color:#1b1b25;margin-top:2px;">${escapeHtml(studentProfile.skills)}</div>
          </div>` : ''}
          ${studentProfile.study_level ? `
          <div style="padding:10px 0;border-bottom:1px solid #ede9f8;">
            <div style="font-size:11px;color:#8b85a0;text-transform:uppercase;letter-spacing:.03em;font-weight:600;">Niveau d'études</div>
            <div style="font-size:14px;color:#1b1b25;margin-top:2px;">${escapeHtml(studentProfile.study_level)}</div>
          </div>` : ''}
          ${studentProfile.bio ? `
          <div style="padding:10px 0;">
            <div style="font-size:11px;color:#8b85a0;text-transform:uppercase;letter-spacing:.03em;font-weight:600;">Biographie</div>
            <div style="font-size:14px;color:#5d576c;line-height:1.5;margin-top:2px;">${escapeHtml(studentProfile.bio)}</div>
          </div>` : ''}
        </div>
      </div>` : ''}

      <!-- Actions rapides -->
      <div style="padding-top:20px;border-top:1px solid #ede9f8;display:flex;flex-wrap:wrap;gap:10px;">
        ${application.status === 'accepted' ? '' : `<button type="button" class="btn btn-primary" id="particularCandidateSelect" style="flex:1;min-width:140px;justify-content:center;"><span class="material-symbols-outlined" style="font-size:16px;">check_circle</span>Choisir cette étudiante</button>`}
        <a class="btn btn-secondary" href="/particular/job-messages.html?application=${application.id}" style="flex:1;min-width:140px;justify-content:center;text-decoration:none;"><span class="material-symbols-outlined" style="font-size:16px;">chat</span>Conversation</a>
        ${['accepted', 'rejected'].includes(application.status) ? '' : `<button type="button" class="btn btn-secondary" id="particularCandidateReject" style="flex:1;min-width:140px;justify-content:center;color:#dc2626;border-color:#fca5a5;"><span class="material-symbols-outlined" style="font-size:16px;">cancel</span>Refuser</button>`}
        <button type="button" class="btn btn-secondary" data-open-modal="particularCandidateMessageModal" style="flex:1;min-width:140px;justify-content:center;"><span class="material-symbols-outlined" style="font-size:16px;">send</span>Envoyer un message</button>
      </div>
    </div>
  `;

  if (actions) actions.innerHTML = '';

  initModals();

  qs('#particularCandidateSelect')?.addEventListener('click', async () => {
    try {
      await updateParticularApplicationStatus(applicationId, 'accepted');
      if (effectiveJobId) await selectParticularCandidate(effectiveJobId, applicationId);
      appToast('Étudiante sélectionnée', 'success');
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible de sélectionner cette candidate', 'error');
    }
  });

  qs('#particularCandidateReject')?.addEventListener('click', async () => {
    try {
      await updateParticularApplicationStatus(applicationId, 'rejected');
      appToast('Candidature refusée', 'success');
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible de refuser cette candidature', 'error');
    }
  });

  qs('#particularCandidateMessageSend')?.addEventListener('click', async () => {
    const message = qs('#particularCandidateMessageText')?.value.trim();
    if (!message) {
      appToast('Ajoute un message avant de continuer.', 'warning');
      return;
    }

    try {
      const conversation = await getOrCreateParticularApplicationConversation(applicationId);
      await sendParticularMessage({ conversationId: conversation.id, body: message });
      appToast('Message envoyé', 'success');
      closeModal(qs('#particularCandidateMessageModal'));
      window.location.href = `/particular/job-messages.html?conversation=${conversation.id}`;
    } catch (error) {
      appToast(error.message || 'Impossible d’envoyer le message.', 'error');
    }
  });
}

async function initMessages() {
  const list = qs('#particularConversationList');
  const thread = qs('#particularMessageThread');
  const form = qs('#particularMessageSendForm');
  const input = qs('#particularMessageInput');
  const params = new URLSearchParams(window.location.search);
  const applicationId = params.get('application');
  const requestedConversationId = params.get('conversation');

  const currentProfile = await getCurrentProfile().catch(() => null);
  let selectedConversationId = null;

  async function fetchInbox() {
    const data = await listParticularConversations().catch(() => []);
    if (!applicationId) return data;

    const ensured = await getOrCreateParticularApplicationConversation(applicationId);
    if (ensured?.id && !data.some((row) => row.conversation_id === ensured.id)) {
      return await listParticularConversations();
    }
    return data;
  }

  let conversations = [];
  try {
    conversations = await fetchInbox();
  } catch (error) {
    list.innerHTML = `<div class="msg-loading">Messagerie indisponible</div>`;
    if (thread) thread.innerHTML = `<div class="msg-empty"><span class="material-symbols-outlined" style="font-size:48px;color:#555770;">chat</span><p>La conversation UNIBOX sera visible ici dès qu'elle sera disponible.</p></div>`;
    return;
  }

  if (!conversations.length) {
    list.innerHTML = `<div class="msg-loading">Aucune conversation pour le moment</div>`;
    if (thread) thread.innerHTML = `<div class="msg-empty"><span class="material-symbols-outlined" style="font-size:48px;color:#555770;">chat</span><p>Sélectionne une conversation pour commencer</p></div>`;
    return;
  }

  // Tabs and search
  let activeTab = 'all';
  let searchQuery = '';
  const searchInput = qs('.msg-search input');
  const tabs = qsa('.msg-tab');

  function updateTabs() {
    tabs.forEach(tab => {
      const isActive = (activeTab === 'all' && tab.textContent.toLowerCase().includes('tous')) ||
                       (activeTab === 'unread' && tab.textContent.toLowerCase().includes('non lus'));
      tab.classList.toggle('active', isActive);
    });
  }

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      activeTab = tab.textContent.toLowerCase().includes('tous') ? 'all' : 'unread';
      updateTabs();
      renderConversationList(selectedConversationId);
    });
  });

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.toLowerCase().trim();
      renderConversationList(selectedConversationId);
    });
  }

  async function renderConversationList(activeConversationId) {
    // Fetch participants for all conversations
    const conversationIds = conversations.map(c => c.conversation_id).filter(Boolean);
    let allParticipants = [];
    try {
      const { data } = await supabase
        .from('conversation_participants')
        .select(`conversation_id, user_id, profiles:user_id(id, full_name, email, avatar_path)`)
        .in('conversation_id', conversationIds);
      allParticipants = data || [];
    } catch (e) {
      console.warn('Could not fetch participants:', e);
    }

    const participantsByConv = new Map();
    for (const p of allParticipants) {
      const bucket = participantsByConv.get(p.conversation_id) || [];
      bucket.push(p);
      participantsByConv.set(p.conversation_id, bucket);
    }

    // Filter conversations
    let filteredConversations = conversations;
    
    if (activeTab === 'unread') {
      filteredConversations = filteredConversations.filter(row => {
        const convParticipants = participantsByConv.get(row.conversation_id) || [];
        const myParticipant = convParticipants.find(p => p.user_id === currentProfile?.id);
        const lastReadAt = myParticipant?.last_read_at;
        const lastMessageAt = row.last_message_at || row.sent_at;
        return lastReadAt && lastMessageAt && new Date(lastMessageAt) > new Date(lastReadAt);
      });
    }
    
    if (searchQuery) {
      filteredConversations = filteredConversations.filter(row => {
        const title = (row.title || '').toLowerCase();
        const subtitle = (row.subtitle || '').toLowerCase();
        return title.includes(searchQuery) || subtitle.includes(searchQuery);
      });
    }

    if (!filteredConversations.length) {
      list.innerHTML = `<div class="msg-loading">${activeTab === 'unread' ? 'Aucune conversation non lue' : 'Aucun résultat pour "' + escapeHtml(searchQuery) + '"'}</div>`;
      qsa('[data-particular-conversation]').forEach((button) => {
        button.addEventListener('click', () => loadThread(button.dataset.particularConversation));
      });
      return;
    }

    list.innerHTML = filteredConversations.map((row) => {
      const isActive = row.conversation_id === activeConversationId;
      const title = row.title || 'Conversation';
      const subtitle = (row.subtitle || 'Aucun message').replace(/^Avec\s*/i, '');
      
      const convParticipants = participantsByConv.get(row.conversation_id) || [];
      const otherParticipants = convParticipants.filter(p => p.user_id !== currentProfile?.id);
      const firstOther = otherParticipants[0];
      const avatarPath = firstOther?.profiles?.avatar_path || null;
      const avatarDataAttr = avatarPath ? `data-avatar-path="${escapeHtml(avatarPath)}"` : '';
      
      const time = row.last_message_at
        ? new Date(row.last_message_at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
        : '';
      
      return `
        <button type="button" class="msg-conv-item ${isActive ? 'active' : ''}" data-particular-conversation="${escapeHtml(row.conversation_id)}">
          <div class="msg-conv-avatar msg-lazy-avatar" ${avatarDataAttr}></div>
          <div class="msg-conv-info">
            <p class="msg-conv-name">${escapeHtml(subtitle)}</p>
            <p class="msg-conv-snippet">${escapeHtml(title)}</p>
          </div>
          <div class="msg-conv-meta">
            ${time ? `<span class="msg-conv-time">${escapeHtml(time)}</span>` : ''}
          </div>
        </button>
      `;
    }).join('');

    qsa('[data-particular-conversation]').forEach((button) => {
      button.addEventListener('click', () => loadThread(button.dataset.particularConversation));
    });

    // Lazy load avatars
    const lazyAvatars = qsa('.msg-lazy-avatar[data-avatar-path]');
    if (lazyAvatars.length) {
      try {
        for (const avatar of lazyAvatars) {
          const path = avatar.dataset.avatarPath;
          if (path) {
            const url = await getSafeAssetUrl('avatars', path);
            avatar.style.backgroundImage = `url('${escapeHtml(url)}')`;
            avatar.style.backgroundSize = 'cover';
            avatar.style.backgroundPosition = 'center';
          }
        }
      } catch (_) {}
    }
  }

  async function loadThread(conversationId) {
    selectedConversationId = conversationId;
    await renderConversationList(conversationId);

    const [messages, participants] = await Promise.all([
      listParticularMessages(conversationId).catch(() => []),
      listParticularConversationParticipants(conversationId).catch(() => []),
    ]);

    const otherParticipants = participants.filter((entry) => entry.user_id !== currentProfile?.id);
    const firstOther = otherParticipants[0];
    const participantNames = otherParticipants
      .map((entry) => entry.profiles?.full_name || entry.profiles?.email)
      .filter(Boolean);
    const participantAvatarPath = firstOther?.profiles?.avatar_path || null;

    const headerName = qs('#particularChatActiveTitle');
    const headerStatus = qs('#particularChatActiveStatus');
    const headerAvatar = qs('#particularChatHeaderAvatar');
    if (participantNames.length) {
      const name = participantNames.join(', ');
      if (headerName) headerName.textContent = name;
      if (headerStatus) headerStatus.textContent = 'En ligne';
      if (headerAvatar && participantAvatarPath) {
        headerAvatar.classList.add('msg-lazy-avatar');
        headerAvatar.setAttribute('data-avatar-path', participantAvatarPath);
        
        try {
          const url = await getSafeAssetUrl('avatars', participantAvatarPath);
          headerAvatar.style.backgroundImage = `url('${escapeHtml(url)}')`;
          headerAvatar.style.backgroundSize = 'cover';
          headerAvatar.style.backgroundPosition = 'center';
          headerAvatar.textContent = '';
        } catch (_) {}
      } else if (headerAvatar) {
        headerAvatar.textContent = name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
      }
    }

    if (!messages.length) {
      thread.innerHTML = `<div class="msg-empty"><span class="material-symbols-outlined" style="font-size:48px;color:#555770;">chat</span><p>Démarre la conversation avec un premier message.</p></div>`;
      await markParticularConversationRead(conversationId).catch(() => null);
      return;
    }

    thread.innerHTML = messages.map((message) => {
      const isMine = message.sender_user_id === currentProfile?.id;
      const senderName = escapeHtml(message.profiles?.full_name || message.profiles?.email || 'UNIBOX');
      const time = escapeHtml(formatDateTime(message.sent_at));
      return `
        <div class="msg-row ${isMine ? 'me' : ''}">
          <div class="msg-bubble ${isMine ? 'msg-bubble-sent' : 'msg-bubble-received'}">
            <div class="msg-meta"><strong>${senderName}</strong><span>${time}</span></div>
            ${message.body ? `<div>${escapeHtml(message.body)}</div>` : ''}
            ${message.attachment_url ? `<a class="msg-bubble-attachment" href="${escapeHtml(message.attachment_url)}" target="_blank" rel="noopener"><span class="material-symbols-outlined" style="font-size:14px;">description</span> Pièce jointe</a>` : ''}
          </div>
        </div>
      `;
    }).join('');

    thread.scrollTop = thread.scrollHeight;
    await markParticularConversationRead(conversationId).catch(() => null);
  }

  await renderConversationList(null);

  const initialId = requestedConversationId
    || (applicationId ? conversations.find((row) => row.conversations?.application_id === applicationId)?.conversation_id : null)
    || conversations[0]?.conversation_id;

  if (initialId) await loadThread(initialId);

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const value = input?.value.trim();
    if (!value || !selectedConversationId) return;
    try {
      await sendParticularMessage({ conversationId: selectedConversationId, body: value });
      input.value = '';
      await loadThread(selectedConversationId);
      appToast('Message envoyé', 'success');
    } catch (error) {
      appToast(error.message || 'Erreur lors de l\'envoi.', 'error');
    }
  });
}

async function initNotifications() {
  const mount = qs('#particularNotificationsList');
  if (!mount) return;

  const notifications = await listParticularNotifications().catch(() => []);
  if (!notifications.length) {
    mount.innerHTML = `
      <div style="text-align: center; padding: 48px 24px;">
        <span class="material-symbols-outlined" style="font-size: 56px; color: #ddd6ea; margin-bottom: 16px; display: block;">notifications_off</span>
        <h3 style="margin: 0 0 8px; font-size: 18px; font-weight: 600; color: #1b1b25;">Aucune notification</h3>
        <p style="margin: 0; color: #a09ab8; font-size: 14px; line-height: 1.5;">Les nouvelles candidatures, messages et changements de mission apparaîtront ici.</p>
      </div>
    `;
    return;
  }

  renderNotifications(mount, notifications);

  qsa('[data-particular-read-notification]').forEach((button) => {
    button.addEventListener('click', async () => {
      try {
        await markParticularNotificationRead(button.dataset.particularReadNotification);
        const card = button.closest('.notification-card');
        if (card) {
          card.style.borderLeft = 'none';
          card.style.background = '';
          const dot = card.querySelector('[style*="border-radius: 50%"]');
          if (dot) dot.remove();
        }
        button.remove();
        appToast('Notification lue', 'success');
      } catch (error) {
        appToast(error.message || 'Impossible de mettre la notification à jour.', 'error');
      }
    });
  });

  qs('#particularNotificationsMarkAll')?.addEventListener('click', async () => {
    try {
      await markAllParticularNotificationsRead();
      qsa('[data-particular-read-notification]').forEach((button) => button.remove());
      qsa('#particularNotificationsList .notification-card').forEach((card) => {
        card.style.borderLeft = 'none';
        card.style.background = '';
        const dot = card.querySelector('[style*="border-radius: 50%"]');
        if (dot) dot.remove();
      });
      appToast('Toutes les notifications sont à jour', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible de marquer les notifications comme lues.', 'error');
    }
  });
}

async function initHistory() {
  qs('#particularReviewSend')?.addEventListener('click', () => {
    appToast('Avis publié', 'success');
    closeModal(qs('#particularReviewModal'));
  });
}

async function initHelp() {
  // Accordion FAQ
  qsa('[data-particular-faq]').forEach((button) => {
    button.addEventListener('click', () => {
      const icon = button.querySelector('.icon');
      const content = qs(`#${button.dataset.particularFaq}`);
      if (content && icon) {
        content.classList.toggle('hidden');
        if (content.classList.contains('hidden')) {
          button.classList.remove('active');
          icon.style.transform = 'rotate(0deg)';
        } else {
          button.classList.add('active');
          icon.style.transform = 'rotate(180deg)';
        }
      }
    });
  });

  // Highlight cat-link on click + filter FAQ sections
  function showFaqSection(targetId) {
    qsa('section[id^="faq-"]').forEach((section) => {
      section.style.display = section.id === targetId ? '' : 'none';
    });
  }

  qsa('.cat-link').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      qsa('.cat-link').forEach((l) => l.classList.remove('active'));
      link.classList.add('active');
      const href = link.getAttribute('href');
      if (href) showFaqSection(href.slice(1));
    });
  });

  // Show all sections on load
  qsa('section[id^="faq-"]').forEach((section) => { section.style.display = ''; });

  // Search FAQ
  qs('#faqSearchInput')?.addEventListener('input', (e) => {
    const term = e.target.value.trim().toLowerCase();
    if (!term) {
      const active = qs('.cat-link.active');
      const href = active?.getAttribute('href');
      if (href) showFaqSection(href.slice(1));
      qsa('.faq-item').forEach((item) => { item.style.display = ''; });
      qsa('.faq-section-title').forEach((t) => { t.style.display = ''; });
      return;
    }
    qsa('section[id^="faq-"]').forEach((s) => { s.style.display = ''; });
    qsa('.faq-item').forEach((item) => {
      const text = item.textContent.toLowerCase();
      item.style.display = text.includes(term) ? '' : 'none';
    });
    qsa('.faq-section-title').forEach((title) => {
      const section = title.closest('section');
      if (section) {
        const visible = section.querySelectorAll('.faq-item:not([style*="none"])').length;
        title.style.display = visible > 0 ? '' : 'none';
        section.style.display = visible > 0 ? '' : 'none';
      }
    });
  });

  qs('#particularHelpSend')?.addEventListener('click', () => {
    appToast('Message support envoyé', 'success');
    closeModal(qs('#particularHelpModal'));
    qs('#particularHelpSubject').value = '';
    qs('#particularHelpMessage').value = '';
  });
}

async function initProfile() {
  const profile = await getCurrentProfile().catch(() => null);
  const roleProfile = profile ? await getRoleProfile('particular', profile.id).catch(() => null) : null;

  const fullName = profile?.full_name || 'Particulier UNIBOX';

  if (qs('#particularFullName') && profile) qs('#particularFullName').value = profile.full_name || '';
  if (qs('#particularEmail') && profile) qs('#particularEmail').value = profile.email || '';
  if (qs('#particularCity') && profile) qs('#particularCity').value = profile.city || '';
  if (qs('#particularBio') && roleProfile) qs('#particularBio').value = roleProfile.bio || '';

  if (qs('#particularAvatarName')) qs('#particularAvatarName').textContent = fullName;

  // Avatar preview on file select
  qs('#particularAvatarInput')?.addEventListener('change', (event) => {
    const file = event.target.files?.[0];
    const preview = qs('#particularAvatarPreview');
    if (file && preview) {
      const reader = new FileReader();
      reader.onload = (e) => { preview.src = e.target.result; };
      reader.readAsDataURL(file);
    }
  });

  // Load current avatar from profile
  if (profile?.avatar_path) {
    const preview = qs('#particularAvatarPreview');
    if (preview) {
      try {
        const { getSafeAssetUrl } = await import('/assets/supabase/unibox-storage.js');
        const url = await getSafeAssetUrl('avatars', profile.avatar_path);
        preview.src = url;
      } catch (_) {}
    }
  }

  // Live update avatar hero on input change
  qs('#particularFullName')?.addEventListener('input', (e) => {
    const nameEl = qs('#particularAvatarName');
    if (nameEl) nameEl.textContent = e.target.value.trim() || 'Particulier UNIBOX';
  });

  qs('#particularProfileForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const button = qs('#particularProfileSave');
    const avatarInput = qs('#particularAvatarInput');
    try {
      setLoading(button, true, 'Enregistrement...');

      let avatarPath = null;
      if (avatarInput?.files?.[0]) {
        try {
          const { uploadAvatar } = await import('/assets/supabase/unibox-storage.js');
          avatarPath = await uploadAvatar(avatarInput.files[0]);
        } catch (uploadError) {
          appToast('Erreur lors de l\'upload de l\'avatar', 'error');
          setLoading(button, false);
          return;
        }
      }

      await updateParticularProfile({
        full_name: qs('#particularFullName')?.value.trim(),
        city: qs('#particularCity')?.value.trim(),
        bio: qs('#particularBio')?.value.trim(),
        avatar_path: avatarPath,
      });
      appToast('Profil mis à jour', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible d\'enregistrer', 'error');
    } finally {
      setLoading(button, false);
    }
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  await mountParticularShell();
  initModals();

  const page = document.body.dataset.page;
  if (page === 'particular-dashboard') await initDashboard();
  if (page === 'particular-create') await initCreate();
  if (page === 'particular-jobs') await initMissions();
  if (page === 'particular-detail') await initDetail();
  if (page === 'particular-applications') await initApplications();
  if (page === 'particular-candidate-detail') await initCandidateDetail();
  if (page === 'particular-notifications') await initNotifications();
  if (page === 'particular-history') await initHistory();
  if (page === 'particular-help') await initHelp();
  if (page === 'particular-profile') await initProfile();
  if (page === 'particular-messages') await initMessages();
});
