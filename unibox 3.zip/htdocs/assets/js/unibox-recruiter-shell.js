import { qs, appToast } from '/assets/js/unibox-core.js';
import { ROUTES } from '/assets/config/app.config.js';
import { signOutUNIBOX } from '/assets/supabase/unibox-auth.js';
import { getCurrentProfile } from '/assets/supabase/unibox-profile.js';
import { getSafeAssetUrl } from '/assets/supabase/unibox-storage.js';
import { SUPABASE_CONFIG } from '/assets/supabase/supabase-config.js';

const NAV_ITEMS = [
  { label: 'Accueil', icon: 'dashboard', href: '/recruiter/rec-dashboard.html', key: 'dashboard' },
  { label: 'Offres', icon: 'work', href: '/recruiter/rec-sdbar+offre.html', key: 'offers' },
  { label: 'Créer une offre', icon: 'add_box', href: '/recruiter/rec-offre-create.html', key: 'offer-create' },
  { label: 'Candidatures', icon: 'fact_check', href: '/recruiter/rec-condidatures.html', key: 'applications' },
  { label: 'Messagerie', icon: 'chat', href: '/recruiter/rec-message.html', key: 'messages' },
  { label: 'Notifications', icon: 'notifications', href: '/recruiter/rec-notofications.html', key: 'notifications' },
  { label: 'Historique', icon: 'history', href: '/recruiter/rec-historique.html', key: 'history' },
  { label: 'Signalements', icon: 'flag', href: '/recruiter/rec-signalement.html', key: 'reports' },
  { label: 'Entreprise', icon: 'apartment', href: '/recruiter/rec-company.html', key: 'company' },
  { label: 'Paramètres', icon: 'settings', href: '/recruiter/rec-profilsettings.html', key: 'settings' },
  { label: 'Aide', icon: 'help', href: '/recruiter/rec-help.html', key: 'help' },
];

function sidebarMarkup(activeKey) {
  return `
    <aside class="recruiter-sidebar">
      <div class="recruiter-sidebar-brand">
        <div class="brand-mark"><svg width="32" height="32" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="2" width="36" height="36" rx="10" fill="#6b38d4"/><path d="M20 9L30 15L20 21L10 15L20 9Z" fill="white" opacity="0.95"/><path d="M30 15L30 25L20 31L20 21L30 15Z" fill="white" opacity="0.7"/><path d="M10 15L20 21L20 31L10 25L10 15Z" fill="white" opacity="0.85"/></svg></div>
        <div class="recruiter-sidebar-copy">
          <strong>UNIBOX</strong>
          <span>Espace recruteur</span>
        </div>
      </div>

      <p class="sidebar-section-label">NAVIGATION</p>
      <nav class="recruiter-nav">
        ${NAV_ITEMS.map((item) => `
          <a href="${item.href}" class="recruiter-nav-link ${item.key === activeKey ? 'is-active' : ''}">
            <span class="material-symbols-outlined">${item.icon}</span>
            <span>${item.label}</span>
          </a>
        `).join('')}
      </nav>

      <div class="recruiter-nav-bottom">
        <div class="recruiter-user-card" style="display: flex; align-items: center; justify-content: space-between; padding-right: 8px;">
          <a href="/recruiter/rec-profilsettings.html" style="display: flex; align-items: center; gap: 12px; text-decoration: none; flex: 1; min-width: 0;">
            <div class="recruiter-user-avatar" data-recruiter-user-avatar>
              <span class="material-symbols-outlined">person</span>
            </div>
            <div class="recruiter-user-info" style="min-width: 0;">
              <strong data-recruiter-user-name style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block;">Chargement...</strong>
              <span data-recruiter-user-role>Recruteur</span>
            </div>
          </a>
          <button type="button" class="btn-logout-icon" data-recruiter-action="logout" title="Déconnexion" style="background: transparent; border: none; color: #5d576c; display: grid; place-items: center; cursor: pointer; padding: 6px; border-radius: 6px; transition: background 0.2s, color 0.2s;">
            <span class="material-symbols-outlined" style="font-size: 20px;">logout</span>
          </button>
        </div>
      </div>
    </aside>
  `;
}

function topbarMarkup(title, subtitle) {
  return `
    <header class="recruiter-topbar">
      <div class="recruiter-topbar-left">
        <button type="button" class="topbar-toggle" id="sidebarToggle">
          <span class="material-symbols-outlined">menu</span>
        </button>
        <div class="recruiter-search">
          <span class="material-symbols-outlined">search</span>
          <input type="search" placeholder="Rechercher…" />
        </div>
      </div>

      <div class="recruiter-topbar-right">
        <button type="button" class="topbar-icon-btn" title="Notifications">
          <span class="material-symbols-outlined">notifications</span>
        </button>
        <div class="topbar-user-pill" data-recruiter-topbar-user>
          <div class="topbar-user-avatar" data-recruiter-user-avatar>
            <span class="material-symbols-outlined">person</span>
          </div>
          <span class="topbar-user-name" data-topbar-user-name>Recruteur</span>
        </div>
      </div>
    </header>
  `;
}

export async function mountRecruiterShell() {
  const active = document.body.dataset.recruiterSection || 'dashboard';
  const title = document.body.dataset.recruiterTitle || 'Espace recruteur';
  const subtitle = document.body.dataset.recruiterSubtitle || 'Ton espace UNIBOX';

  const shell = qs('#recruiterShell');
  const content = qs('#recruiterPageContent');
  if (!shell || !content) return;

  const contentHtml = content.innerHTML;
  shell.innerHTML = `
    <div class="recruiter-shell">
      ${sidebarMarkup(active)}
      <main class="recruiter-main">
        ${topbarMarkup(title, subtitle)}
        <div id="recruiterContentMount" class="recruiter-content">${contentHtml}</div>
      </main>
    </div>
  `;
  content.remove();

  qs('#sidebarToggle')?.addEventListener('click', () => {
    qs('.recruiter-shell')?.classList.toggle('sidebar-open');
  });

  try {
    const profile = await getCurrentProfile();
    const nameNode = qs('[data-recruiter-user-name]');
    if (nameNode && profile?.full_name) nameNode.textContent = profile.full_name;

    const topbarName = qs('[data-topbar-user-name]');
    if (topbarName && profile?.full_name) topbarName.textContent = profile.full_name;

    if (profile?.avatar_path) {
      const avatarUrl = await getSafeAssetUrl(SUPABASE_CONFIG.buckets.avatars, profile.avatar_path);
      document.querySelectorAll('[data-recruiter-user-avatar]').forEach(container => {
        container.innerHTML = `<img src="${avatarUrl}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
      });
    }
  } catch (_err) { }

  qs('[data-recruiter-action="logout"]')?.addEventListener('click', async () => {
    try {
      await signOutUNIBOX();
      window.location.href = ROUTES.auth.login;
    } catch (error) {
      appToast(error.message || 'Déconnexion impossible', 'error');
    }
  });
}
