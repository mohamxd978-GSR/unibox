import {
  redirectAuthenticatedVisitor,
  requireAuthenticatedGuard,
  requireGuest,
  requireOnboardingGuard,
  requirePendingGuard,
  requireRoleGuard,
} from '/assets/supabase/unibox-bootstrap.js';

document.addEventListener('DOMContentLoaded', async () => {
  const guard = document.body.dataset.guard;

  if (guard === 'guest') {
    await requireGuest();
    return;
  }

  if (guard === 'auth') {
    await requireAuthenticatedGuard();
    return;
  }

  if (guard === 'role') {
    const allowed = (document.body.dataset.allowedRoles || '')
      .split(',')
      .map((value) => value.trim())
      .filter(Boolean);

    await requireRoleGuard(allowed);
    return;
  }

  if (guard === 'onboarding') {
    const allowed = (document.body.dataset.allowedRoles || '')
      .split(',')
      .map((value) => value.trim())
      .filter(Boolean);

    await requireOnboardingGuard(allowed);
    return;
  }

  if (guard === 'pending') {
    await requirePendingGuard();
    return;
  }

  if (guard === 'redirect-authenticated') {
    await redirectAuthenticatedVisitor();
  }
});
