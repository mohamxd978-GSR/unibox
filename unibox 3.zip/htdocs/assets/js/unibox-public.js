import { go, qs, setAppFlash } from '/assets/js/unibox-core.js';
import { ROUTES } from '/assets/config/app.config.js';
import { signOutUNIBOX } from '/assets/supabase/unibox-auth.js';
import { bootUNIBOX } from '/assets/supabase/unibox-bootstrap.js';

function initLandingPage() {
  qs('[data-action="login"]')?.addEventListener('click', () => go(ROUTES.auth.login));
  qs('[data-action="signup"]')?.addEventListener('click', () => go(ROUTES.auth.signup));
  qs('[data-action="explore"]')?.addEventListener('click', () => go(ROUTES.auth.signup));
}

function initErrorPage() {
  qs('[data-action="go-home"]')?.addEventListener('click', () => go(ROUTES.landing));
  qs('[data-action="go-login"]')?.addEventListener('click', () => go(ROUTES.auth.login));
}

async function initAccountPendingPage() {
  const statusText = qs('[data-account-pending-status]');
  const hintText = qs('[data-account-pending-hint]');
  const loginButton = qs('[data-action="go-login"]');
  const homeButton = qs('[data-action="go-home"]');
  const logoutButton = qs('[data-action="logout"]');

  homeButton?.addEventListener('click', () => go(ROUTES.landing));
  loginButton?.addEventListener('click', () => go(ROUTES.auth.login));
  logoutButton?.addEventListener('click', async () => {
    await signOutUNIBOX().catch(() => null);
    setAppFlash({ message: 'Déconnexion effectuée.', type: 'info' });
    go(ROUTES.auth.login);
  });

  const boot = await bootUNIBOX().catch(() => null);
  if (!boot?.profile) return;

  if (statusText) {
    statusText.textContent = `Statut actuel : ${boot.profile.account_status}`;
  }

  if (hintText) {
    hintText.textContent = boot.profile.account_status === 'pending'
      ? 'Ton compte a été créé et ton onboarding est terminé. Il reste une validation finale avant l’accès complet.'
      : 'Le statut de ton compte nécessite une action complémentaire.';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const page = document.body.dataset.page;

  if (page === 'landing') initLandingPage();
  if (['not-found', 'access-denied'].includes(page)) initErrorPage();
  if (page === 'account-pending') initAccountPendingPage();
});
