import { qs, appToast } from '/assets/js/unibox-core.js';
import { ROUTES } from '/assets/config/app.config.js';
import { signOutUNIBOX } from '/assets/supabase/unibox-auth.js';
import { getCurrentProfile } from '/assets/supabase/unibox-profile.js';
import { getSafeAssetUrl } from '/assets/supabase/unibox-storage.js';
import { SUPABASE_CONFIG } from '/assets/supabase/supabase-config.js';

const NAV_ITEMS = [
  { label: 'Accueil', icon: 'dashboard', href: '/admin/admin-dashboard.html', key: 'dashboard' },
  { label: 'Étudiants', icon: 'school', href: '/admin/admin-students.html', key: 'students' },
  { label: 'Entreprises', icon: 'apartment', href: '/admin/admin-enterprises.html', key: 'companies' },
  { label: 'Particuliers', icon: 'person', href: '/admin/admin-particulars.html', key: 'particulars' },
  { label: 'Offres & missions', icon: 'work_history', href: '/admin/admin-offers.html', key: 'offers' },
  { label: 'Candidatures', icon: 'fact_check', href: '/admin/admin-applications.html', key: 'applications' },
  { label: 'Modération', icon: 'gavel', href: '/admin/admin-moderation.html', key: 'moderation' },
  { label: 'Signalements', icon: 'flag', href: '/admin/admin-reports.html', key: 'reports' },
  { label: 'Notifications', icon: 'notifications', href: '/admin/admin-notifications.html', key: 'notifications' },
  { label: 'Historique', icon: 'history', href: '/admin/admin-history.html', key: 'history' },
  { label: 'Paramètres', icon: 'settings', href: '/admin/admin-settings.html', key: 'settings' },
];

const LOGO_SVG = `<svg width="32" height="32" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="2" width="36" height="36" rx="10" fill="#6b38d4"/><path d="M20 9L30 15L20 21L10 15L20 9Z" fill="white" opacity="0.95"/><path d="M30 15L30 25L20 31L20 21L30 15Z" fill="white" opacity="0.7"/><path d="M10 15L20 21L20 31L10 25L10 15Z" fill="white" opacity="0.85"/></svg>`;

function sidebarMarkup(activeKey) {
  return `
    <aside class="admin-sidebar">
      <div class="admin-sidebar-brand">
        <div class="brand-mark">${LOGO_SVG}</div>
        <div class="admin-sidebar-copy">
          <strong>UNIBOX</strong>
          <span>Espace administrateur</span>
        </div>
      </div>

      <p class="sidebar-section-label">NAVIGATION</p>
      <nav class="admin-nav">
        ${NAV_ITEMS.map((item) => `
          <a href="${item.href}" class="admin-nav-link ${item.key === activeKey ? 'is-active' : ''}">
            <span class="material-symbols-outlined">${item.icon}</span>
            <span>${item.label}</span>
          </a>
        `).join('')}
      </nav>

      <div class="admin-nav-bottom">
        <div class="admin-user-card" style="display: flex; align-items: center; justify-content: space-between; padding-right: 8px;">
          <a href="/admin/admin-settings.html" style="display: flex; align-items: center; gap: 12px; text-decoration: none; flex: 1; min-width: 0;">
            <div class="admin-user-avatar" data-admin-user-avatar>
              <span class="material-symbols-outlined">admin_panel_settings</span>
            </div>
            <div class="admin-user-info" style="min-width: 0;">
              <strong data-admin-user-name style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block;">Chargement...</strong>
              <span>Admin UNIBOX</span>
            </div>
          </a>
          <button type="button" class="btn-logout-icon" data-admin-action="logout" title="Déconnexion" style="background: transparent; border: none; color: #5d576c; display: grid; place-items: center; cursor: pointer; padding: 6px; border-radius: 6px; transition: background 0.2s, color 0.2s;">
            <span class="material-symbols-outlined" style="font-size: 20px;">logout</span>
          </button>
        </div>
      </div>
    </aside>
  `;
}

function topbarMarkup(title, subtitle) {
  return `
    <header class="admin-topbar">
      <div class="admin-topbar-left">
        <button type="button" class="topbar-toggle" id="sidebarToggle">
          <span class="material-symbols-outlined">menu</span>
        </button>
        <div class="admin-search">
          <span class="material-symbols-outlined">search</span>
          <input type="search" placeholder="Rechercher…" />
        </div>
      </div>

      <div class="admin-topbar-right">
        <button type="button" class="topbar-icon-btn" title="Notifications">
          <span class="material-symbols-outlined">notifications</span>
        </button>
        <div class="topbar-user-pill">
          <div class="topbar-user-avatar" data-admin-user-avatar>
            <span class="material-symbols-outlined">admin_panel_settings</span>
          </div>
          <span class="topbar-user-name" data-topbar-user-name>Admin</span>
        </div>
      </div>
    </header>
  `;
}

export async function mountAdminShell() {
  const active = document.body.dataset.adminSection || 'dashboard';
  const title = document.body.dataset.admintitle || document.body.dataset.adminTitle || 'Back-office admin';
  const subtitle = document.body.dataset.adminsubtitle || document.body.dataset.adminSubtitle || 'Pilotage UNIBOX';

  const shell = qs('#adminShell');
  const content = qs('#adminPageContent');
  if (!shell || !content) return;

  const contentHtml = content.innerHTML;
  shell.innerHTML = `
    <div class="admin-shell">
      ${sidebarMarkup(active)}
      <main class="admin-main">
        ${topbarMarkup(title, subtitle)}
        <div id="adminContentMount" class="admin-content">${contentHtml}</div>
      </main>
    </div>
  `;
  content.remove();

  qs('#sidebarToggle')?.addEventListener('click', () => {
    qs('.admin-shell')?.classList.toggle('sidebar-open');
  });

  try {
    const profile = await getCurrentProfile();
    const nameNode = qs('[data-admin-user-name]');
    if (nameNode && profile?.full_name) nameNode.textContent = profile.full_name;

    const topbarName = qs('[data-topbar-user-name]');
    if (topbarName && profile?.full_name) topbarName.textContent = profile.full_name;

    if (profile?.avatar_path) {
      const avatarUrl = await getSafeAssetUrl(SUPABASE_CONFIG.buckets.avatars, profile.avatar_path);
      document.querySelectorAll('[data-admin-user-avatar]').forEach(container => {
        container.innerHTML = `<img src="${avatarUrl}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
      });
    }
  } catch (_err) { }

  qs('[data-admin-action="logout"]')?.addEventListener('click', async () => {
    try {
      await signOutUNIBOX();
      window.location.href = ROUTES.auth.login;
    } catch (error) {
      appToast(error.message || 'Déconnexion impossible', 'error');
    }
  });
}


