// ========================================
// MINTLY LANDING PAGE - JAVASCRIPT
// ========================================

// ========================================
// HEADER NAVIGATION
// ========================================

// Wait for DOM to be fully loaded
document.addEventListener(
	"DOMContentLoaded",
	function () {
		// Mobile Menu Toggle
		const mobileMenuToggle =
			document.querySelector(
				".mobile-menu-toggle"
			);
		const mobileNav = document.querySelector(
			".mobile-nav"
		);
		const header =
			document.querySelector(".header");
		const body = document.body;

		// Toggle mobile menu
		if (mobileMenuToggle && mobileNav) {
			mobileMenuToggle.addEventListener(
				"click",
				() => {
					const isExpanded =
						mobileMenuToggle.getAttribute(
							"aria-expanded"
						) === "true";

					mobileMenuToggle.setAttribute(
						"aria-expanded",
						!isExpanded
					);
					mobileNav.classList.toggle("active");
					body.style.overflow = !isExpanded
						? "hidden"
						: "";
				}
			);

			// Close mobile menu when clicking on a link
			const mobileNavLinks =
				document.querySelectorAll(
					".mobile-nav-link, .mobile-nav-btn"
				);
			mobileNavLinks.forEach((link) => {
				link.addEventListener("click", () => {
					mobileMenuToggle.setAttribute(
						"aria-expanded",
						"false"
					);
					mobileNav.classList.remove("active");
					body.style.overflow = "";
				});
			});

			// Close mobile menu on window resize
			window.addEventListener("resize", () => {
				if (window.innerWidth > 900) {
					mobileMenuToggle.setAttribute(
						"aria-expanded",
						"false"
					);
					mobileNav.classList.remove("active");
					body.style.overflow = "";
				}
			});
		}

		// Header scroll effect
		let lastScroll = 0;
		const scrollThreshold = 100;

		window.addEventListener("scroll", () => {
			const currentScroll = window.pageYOffset;

			// Add/remove scrolled class for styling
			if (currentScroll > 50) {
				header?.classList.add("scrolled");
			} else {
				header?.classList.remove("scrolled");
			}

			lastScroll = currentScroll;
		});

		// Smooth scroll for navigation links
		document
			.querySelectorAll('a[href^="#"]')
			.forEach((anchor) => {
				anchor.addEventListener(
					"click",
					function (e) {
						const href =
							this.getAttribute("href");

						// Handle auth nav links (#signin / #signup)
						if (href === "#signin" || href === "#signup") {
							e.preventDefault();
							const authSection = document.getElementById("signup");
							const authContainer = document.getElementById("authContainer");

							if (authSection && authContainer) {
								// Toggle the correct panel
								if (href === "#signup") {
									authContainer.classList.add("right-panel-active");
								} else {
									authContainer.classList.remove("right-panel-active");
								}

								// Smooth scroll to the auth section
								const headerOffset = 80;
								const elementPosition = authSection.getBoundingClientRect().top;
								const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

								window.scrollTo({
									top: offsetPosition,
									behavior: "smooth",
								});
							}
							return;
						}

						// Only smooth scroll for valid anchors (not just "#")
						if (
							href &&
							href !== "#"
						) {
							const target =
								document.querySelector(href);
							if (target) {
								e.preventDefault();
								const headerOffset = 80;
								const elementPosition =
									target.getBoundingClientRect()
										.top;
								const offsetPosition =
									elementPosition +
									window.pageYOffset -
									headerOffset;

								window.scrollTo({
									top: offsetPosition,
									behavior: "smooth",
								});
							}
						}
					}
				);
			});
	}
);

// ========================================
// TESTIMONIAL CAROUSEL
// ========================================

let currentTestimonial = 0;

function showTestimonial(index) {
	const slides = document.querySelectorAll(
		".testimonial-slide"
	);
	const dots = document.querySelectorAll(".dot");

	// Return early if no slides exist
	if (slides.length === 0) return;

	// Validate index
	if (index >= slides.length) {
		currentTestimonial = 0;
	} else if (index < 0) {
		currentTestimonial = slides.length - 1;
	} else {
		currentTestimonial = index;
	}

	// Hide all slides
	slides.forEach((slide) =>
		slide.classList.remove("active")
	);
	dots.forEach((dot) =>
		dot.classList.remove("active")
	);

	// Show current slide
	if (slides[currentTestimonial]) {
		slides[currentTestimonial].classList.add(
			"active"
		);
	}
	if (dots[currentTestimonial]) {
		dots[currentTestimonial].classList.add(
			"active"
		);
	}
}

function nextTestimonial() {
	showTestimonial(currentTestimonial + 1);
}

function previousTestimonial() {
	showTestimonial(currentTestimonial - 1);
}

function goToTestimonial(index) {
	showTestimonial(index);
}

// Auto-rotate testimonials every 8 seconds
setInterval(() => {
	nextTestimonial();
}, 8000);

// ========================================
// SMOOTH SCROLLING
// ========================================

document
	.querySelectorAll('a[href^="#"]')
	.forEach((anchor) => {
		anchor.addEventListener(
			"click",
			function (e) {
				const href = this.getAttribute("href");
				if (
					href !== "#" &&
					document.querySelector(href)
				) {
					e.preventDefault();
					document
						.querySelector(href)
						.scrollIntoView({
							behavior: "smooth",
						});
				}
			}
		);
	});

// ========================================
// FORM SUBMISSION
// ========================================

function handleSignup(event) {
	event.preventDefault();

	const form = event.target;
	const email = form.querySelector(
		'input[type="email"]'
	).value;

	if (!email) {
		alert("Please enter your email address.");
		return;
	}

	// Validate email
	const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
	if (!emailRegex.test(email)) {
		alert("Please enter a valid email address.");
		return;
	}

	// Here you would typically send the email to your backend
	console.log("Signup initiated for:", email);

	// Show success message
	const button = form.querySelector("button");
	const originalText = button.textContent;
	button.textContent = "✓ Check your email!";
	button.style.background = "#0D9488";

	// Reset form
	form.reset();

	// Reset button after 3 seconds
	setTimeout(() => {
		button.textContent = originalText;
		button.style.background = "";
	}, 3000);
}

function handleNewsletter(event) {
	event.preventDefault();
	const form = event.target;
	const email = form.querySelector(
		'input[type="email"]'
	).value;

	if (email) {
		const button = form.querySelector("button");
		const originalText = button.innerHTML;

		button.innerHTML = "Subscribed!";
		button.style.background = "#0D9488";

		setTimeout(() => {
			button.innerHTML = originalText;
			button.style.background = "";
			form.reset();
		}, 2000);
	}
}

// ========================================
// SCROLL ANIMATIONS - Professional Timing
// ========================================

const observerOptions = {
	threshold: 0.1,
	rootMargin: "0px 0px -60px 0px",
};

const observer = new IntersectionObserver(
	(entries) => {
		entries.forEach((entry) => {
			if (entry.isIntersecting) {
				// Add animate class to trigger CSS animations
				entry.target.classList.add("animate");
			} else {
				entry.target.classList.remove("animate");
			}
		});
	},
	observerOptions
);

// Observe elements for scroll animations
document
	.querySelectorAll(
		".how-it-works, .benefit-card, .step-item, .testimonial-card, .usp-highlight-card, .usp-features-column, .feature-item"
	)
	.forEach((el) => {
		observer.observe(el);
	});

// ========================================
// NAVBAR - NO NAVBAR AS PER DESIGN
// But keeping for potential future use
// ========================================

// Sticky header on scroll (optional enhancement)
window.addEventListener("scroll", () => {
	const hero = document.querySelector(".hero");
	const scrolled = window.scrollY > 100;

	if (scrolled) {
		// Can add scroll-triggered animations here
	}
});

// ========================================
// KEYBOARD NAVIGATION
// ========================================

document.addEventListener("keydown", (e) => {
	// Allow arrow keys for testimonial navigation
	if (e.key === "ArrowLeft") {
		previousTestimonial();
	} else if (e.key === "ArrowRight") {
		nextTestimonial();
	}
});

// ========================================
// MOBILE OPTIMIZATION
// ========================================

// Detect if user is on mobile
const isMobile = () => {
	return window.innerWidth <= 768;
};

// window.addEventListener("resize", () => { ... });

// ========================================
// PERFORMANCE OPTIMIZATION
// ========================================

// Lazy load images if using them
if ("IntersectionObserver" in window) {
	const imageObserver = new IntersectionObserver(
		(entries, observer) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) {
					const img = entry.target;
					if (img.dataset.src) {
						img.src = img.dataset.src;
						img.removeAttribute("data-src");
						observer.unobserve(img);
					}
				}
			});
		}
	);

	document
		.querySelectorAll("img[data-src]")
		.forEach((img) => imageObserver.observe(img));
}

// ========================================
// ANALYTICS TRACKING (Example)
// ========================================

function trackEvent(eventName, eventData = {}) {
	console.log(`Event: ${eventName}`, eventData);
	// Replace with your analytics service (GA, Mixpanel, etc.)
}

// Track CTA clicks
document
	.querySelectorAll(".cta-button")
	.forEach((btn) => {
		btn.addEventListener("click", () => {
			trackEvent("CTA_Click", {
				text: btn.textContent,
			});
		});
	});

// Track testimonial navigation
document
	.querySelectorAll(".carousel-btn, .dot")
	.forEach((btn) => {
		btn.addEventListener("click", () => {
			trackEvent("Testimonial_Navigation", {
				current: currentTestimonial,
			});
		});
	});

// ========================================
// FAQ ACCORDION
// ========================================

const accordionTriggers =
	document.querySelectorAll(".accordion-trigger");

accordionTriggers.forEach((trigger) => {
	trigger.addEventListener("click", () => {
		const isExpanded =
			trigger.getAttribute("aria-expanded") ===
			"true";
		const content = trigger.nextElementSibling;

		// Close all other items
		accordionTriggers.forEach((otherTrigger) => {
			if (otherTrigger !== trigger) {
				otherTrigger.setAttribute(
					"aria-expanded",
					"false"
				);
				otherTrigger.nextElementSibling.style.height =
					"0";
				otherTrigger.nextElementSibling.setAttribute(
					"aria-hidden",
					"true"
				);
			}
		});

		// Toggle current item
		trigger.setAttribute(
			"aria-expanded",
			!isExpanded
		);
		content.setAttribute(
			"aria-hidden",
			isExpanded
		);

		if (!isExpanded) {
			content.style.height =
				content.scrollHeight + "px";
		} else {
			content.style.height = "0";
		}
	});
});

// ========================================
// INITIALIZATION
// ========================================

document.addEventListener(
	"DOMContentLoaded",
	() => {
		console.log("Mintly Landing Page Loaded");

		// Initialize first testimonial
		showTestimonial(0);

	}
);

// ========================================
// SCROLL ANIMATIONS
// ========================================

document.addEventListener(
	"DOMContentLoaded",
	() => {
		// Elements to animate
		const animatedElements =
			document.querySelectorAll(
				".hero-text-wrapper, .hero-visual-wrapper, .benefits-header, .bento-card, .section-header-center, .process-step, .usp-header, .usp-card, .social-proof-header, .testimonial-card, .trust-logos, .faq-header-col, .accordion-item, .signup-visual, .signup-form-container, .footer-cta-wrapper, .footer-col"
			); // Add base class
		animatedElements.forEach((el) => {
			el.classList.add("reveal-element");
		});

		// Intersection Observer
		const observerOptions = {
			root: null,
			rootMargin: "0px",
			threshold: 0.1,
		};

		const observer = new IntersectionObserver(
			(entries, observer) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						// Add staggered delay based on index in container if possible,
						// or just simple reveal
						const target = entry.target;

						// Simple stagger logic for grids
						if (
							target.classList.contains(
								"bento-card"
							) ||
							target.classList.contains(
								"usp-card"
							) ||
							target.classList.contains(
								"process-step"
							) ||
							target.classList.contains(
								"testimonial-card"
							) ||
							target.classList.contains(
								"accordion-item"
							) ||
							target.classList.contains(
								"footer-col"
							)
						) {
							const siblings = Array.from(
								target.parentNode.children
							);
							const index =
								siblings.indexOf(target);
							target.style.transitionDelay = `${index * 0.1
								}s`;
						}

						target.classList.add("revealed");
					} else {
						entry.target.classList.remove("revealed");
						entry.target.style.transitionDelay = '';
					}
				});
			},
			observerOptions
		);

		animatedElements.forEach((el) => {
			observer.observe(el);
		});
	}
);

// ========================================
// ALGERIA MAP (Leaflet)
// ========================================

document.addEventListener("DOMContentLoaded", () => {
	const mapEl = document.getElementById("algeria-map");
	if (!mapEl || typeof L === "undefined") return;

	// Create map centered on Algeria
	const map = L.map("algeria-map", {
		center: [28.0339, 1.6596],
		zoom: 5,
		zoomControl: false,
		scrollWheelZoom: false,
		attributionControl: false,
	});

	// Add zoom control top-right
	L.control.zoom({ position: "topright" }).addTo(map);

	// Use a clean, minimal tile layer (CartoDB Positron)
	L.tileLayer(
		"https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
		{
			maxZoom: 19,
		}
	).addTo(map);

	// Custom marker icon matching the site's color palette
	const markerIcon = L.divIcon({
		className: "custom-marker",
		html: `<div style="
			width: 14px;
			height: 14px;
			background: #6b38d4;
			border: 3px solid #ffffff;
			border-radius: 50%;
			box-shadow: 0 2px 8px rgba(107, 56, 212, 0.4);
		"></div>`,
		iconSize: [14, 14],
		iconAnchor: [7, 7],
		popupAnchor: [0, -10],
	});

	// Major Algerian cities with mock offer counts
	const cities = [
		{ name: "Alger", lat: 36.7538, lng: 3.0588, offers: 487 },
		{ name: "Oran", lat: 35.6969, lng: -0.6331, offers: 312 },
		{ name: "Constantine", lat: 36.365, lng: 6.6147, offers: 245 },
		{ name: "Annaba", lat: 36.9, lng: 7.7667, offers: 156 },
		{ name: "Blida", lat: 36.4722, lng: 2.8278, offers: 134 },
		{ name: "Batna", lat: 35.5553, lng: 6.1742, offers: 98 },
		{ name: "Sétif", lat: 36.1898, lng: 5.4108, offers: 187 },
		{ name: "Tlemcen", lat: 34.8828, lng: -1.3167, offers: 76 },
		{ name: "Béjaïa", lat: 36.7509, lng: 5.0567, offers: 112 },
		{ name: "Tizi Ouzou", lat: 36.7169, lng: 4.0497, offers: 95 },
		{ name: "Biskra", lat: 34.8484, lng: 5.7286, offers: 64 },
		{ name: "Ghardaïa", lat: 32.4912, lng: 3.6734, offers: 42 },
		{ name: "Ouargla", lat: 31.9527, lng: 5.3253, offers: 38 },
		{ name: "Tamanrasset", lat: 22.785, lng: 5.5228, offers: 18 },
	];

	cities.forEach((city) => {
		L.marker([city.lat, city.lng], { icon: markerIcon })
			.addTo(map)
			.bindPopup(
				`<b>${city.name}</b><br><span>${city.offers}</span> offres disponibles`
			);
	});

	// Invalidate map size when it becomes visible (scroll into view)
	const mapObserver = new IntersectionObserver(
		(entries) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) {
					map.invalidateSize();
					mapObserver.unobserve(entry.target);
				}
			});
		},
		{ threshold: 0.1 }
	);
	mapObserver.observe(mapEl);
});

// ========================================
// AUTH DOUBLE SLIDER TOGGLE
// ========================================
document.addEventListener('DOMContentLoaded', () => {
	const authSignUpBtn = document.getElementById('authSignUp');
	const authSignInBtn = document.getElementById('authSignIn');
	const authContainer = document.getElementById('authContainer');

	if (authSignUpBtn && authSignInBtn && authContainer) {
		authSignUpBtn.addEventListener('click', () => {
			authContainer.classList.add('right-panel-active');
		});

		authSignInBtn.addEventListener('click', () => {
			authContainer.classList.remove('right-panel-active');
		});
	}
});
