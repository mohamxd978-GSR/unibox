import { qs, qsa, appToast, setLoading } from '/assets/js/unibox-core.js';
import { getSafeAssetUrl } from '/assets/supabase/unibox-storage.js';
import { SUPABASE_CONFIG } from '/assets/supabase/supabase-config.js';
import { mountAdminShell } from '/assets/js/unibox-admin-shell.js';
import {
  listAdminProfilesByRole,
  listAdminCompanies,
  listAdminOffers,
  listAdminMinuteJobs,
  listAdminApplications,
  listAdminReports,
  listAdminModerationCases,
  listAdminNotifications,
  markAdminNotificationRead,
  markAllAdminNotificationsRead,
  listAdminAuditLogs,
  updateAdminAccountStatus,
  updateAdminCompanyStatus,
  updateAdminOfferVisibility,
  updateAdminMinuteJobVisibility,
  createAdminModerationCase,
  updateAdminModerationCase,
  assignAdminReportToMe,
  resolveAdminReport,
  dismissAdminReport,
  saveAdminSettings,
} from '/assets/supabase/unibox-admin.js';
import { getCurrentProfile, getRoleProfile } from '/assets/supabase/unibox-profile.js';
import { getApplication } from '/assets/supabase/unibox-applications.js';
import { getReportTargetDisplay } from '/assets/supabase/unibox-reports.js';

const APPLICATION_STATUS_LABELS = {
  submitted: 'En examination',
  under_review: 'En examination',
  shortlisted: 'En examination',
  interview_requested: 'En examination',
  accepted: 'Accepté',
  rejected: 'Refusé',
  withdrawn: 'Retiré',
  cancelled: 'Annulé',
};

const REPORT_STATUS_LABELS = {
  open: 'Ouvert',
  in_review: 'En revue',
  resolved: 'Résolu',
  dismissed: 'Classé',
};

const CASE_STATUS_LABELS = {
  open: 'Ouvert',
  investigating: 'En enquête',
  resolved: 'Résolu',
  closed: 'Fermé',
};

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function formatDateTime(value) {
  if (!value) return '—';
  return new Date(value).toLocaleString('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatAccountStatus(value) {
  switch (value) {
    case 'active': return 'Actif';
    case 'pending': return 'En attente';
    case 'restricted': return 'Restreint';
    case 'suspended': return 'Suspendu';
    default: return value || '—';
  }
}

function formatApplicationStatus(value) {
  return APPLICATION_STATUS_LABELS[value] || value || 'En examination';
}

function formatReportStatus(value) {
  return REPORT_STATUS_LABELS[value] || value || 'Ouvert';
}

function formatCaseStatus(value) {
  return CASE_STATUS_LABELS[value] || value || 'Ouvert';
}

function formatLocation(item) {
  return [item?.address_text, item?.city, item?.country].filter(Boolean).join(' · ') || item?.city || 'Localisation non précisée';
}

function openModal(id) {
  const modal = qs(`#${id}`);
  if (modal) {
    modal.classList.add('is-open');
    modal.style.setProperty('display', 'flex', 'important');
  }
}

function closeModal(modal) {
  modal?.classList.remove('is-open');
  modal?.style.removeProperty('display');
}

function initModals() {
  qsa('[data-open-modal]').forEach((button) => {
    button.addEventListener('click', () => openModal(button.dataset.openModal));
  });

  qsa('[data-modal]').forEach((modal) => {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeModal(modal);
    });
  });

  qsa('[data-close-modal]').forEach((button) => {
    button.addEventListener('click', () => closeModal(button.closest('[data-modal]')));
  });
}

function renderEmptyState(target, title, text) {
  if (!target) return;
  target.innerHTML = `
    <div class="empty-state small">
      <strong>${escapeHtml(title)}</strong>
      <span>${escapeHtml(text)}</span>
    </div>
  `;
}

function renderProfiles(target, items, kind) {
  if (!target) return;
  if (!items.length) {
    renderEmptyState(target, 'Aucun résultat', 'Rien à afficher pour le moment.');
    return;
  }

  target.innerHTML = items.map((item) => `
    <article class="data-card">
      <div class="card-row">
        <div>
          <h3 class="card-title">${escapeHtml(item.full_name || item.name || 'UNIBOX')}</h3>
          <p class="card-subtitle">${escapeHtml(item.email || item.owner?.email || item.industry || 'Compte UNIBOX')}</p>
          <div class="card-meta">
            ${item.city ? `<span class="pill soft">${escapeHtml(item.city)}</span>` : ''}
            ${item.role ? `<span class="pill soft">${escapeHtml(item.role)}</span>` : ''}
            ${item.account_status ? `<span class="pill soft">${escapeHtml(formatAccountStatus(item.account_status))}</span>` : ''}
            ${item.status ? `<span class="pill soft">${escapeHtml(item.status)}</span>` : ''}
          </div>
        </div>
      </div>
      <div class="card-actions">
        <button class="btn btn-secondary" type="button" data-admin-restrict="${item.id}" data-admin-kind="${kind}">Restreindre</button>
        <button class="btn btn-secondary" type="button" data-admin-activate="${item.id}" data-admin-kind="${kind}">Activer</button>
      </div>
    </article>
  `).join('');
}

function renderListings(target, items, type) {
  if (!target) return;
  if (!items.length) {
    renderEmptyState(target, 'Aucun contenu', 'Aucune donnée à modérer pour le moment.');
    return;
  }

  target.innerHTML = items.map((item) => `
    <article class="data-card">
      <div class="card-row">
        <div>
          <h3 class="card-title">${escapeHtml(item.title || 'Annonce UNIBOX')}</h3>
          <p class="card-subtitle">${escapeHtml(type === 'offer' ? (item.companies?.name || 'Entreprise UNIBOX') : (item.owner?.full_name || 'Particulier UNIBOX'))}</p>
          <div class="card-meta">
            <span class="pill soft">${escapeHtml(formatLocation(item))}</span>
            <span class="pill soft">${escapeHtml(item.status || 'draft')}</span>
            <span class="pill soft">${item.hidden_by_admin ? 'Masquée' : 'Visible'}</span>
          </div>
        </div>
      </div>
      <div class="card-actions">
        ${item.hidden_by_admin
          ? `<button class="btn btn-secondary" type="button" data-admin-show-item="${item.id}" data-admin-type="${type}">Rétablir</button>`
          : `<button class="btn btn-secondary" type="button" data-admin-hide-item="${item.id}" data-admin-type="${type}">Masquer</button>`}
      </div>
    </article>
  `).join('');
}

const APP_STATUS_STYLE = {
  submitted:           { label: 'En examination', bg: 'rgba(14,165,233,0.12)',   color: '#0369a1' },
  under_review:        { label: 'En examen',      bg: 'rgba(14,165,233,0.12)',   color: '#0369a1' },
  shortlisted:         { label: 'Présélectionné', bg: 'rgba(107,56,212,0.12)',  color: '#6b38d4' },
  interview_requested: { label: 'Entretien dem.', bg: 'rgba(107,56,212,0.12)',  color: '#6b38d4' },
  accepted:            { label: 'Accepté',        bg: 'rgba(5,150,105,0.12)',   color: '#047857' },
  rejected:            { label: 'Refusé',         bg: 'rgba(220,38,38,0.12)',   color: '#dc2626' },
  withdrawn:           { label: 'Retiré',         bg: 'rgba(107,114,128,0.12)', color: '#4b5563' },
  cancelled:           { label: 'Annulé',         bg: 'rgba(107,114,128,0.12)', color: '#4b5563' },
};

function statusPill(status) {
  const s = APP_STATUS_STYLE[status] || { label: status || 'Inconnu', bg: 'rgba(107,114,128,0.12)', color: '#4b5563' };
  return `<span class="pill" style="background:${s.bg};color:${s.color};border:none;font-weight:600;">${s.label}</span>`;
}

function candidateAvatarHtml(item) {
  const initials = (item.profiles?.full_name || 'C').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  const avatarPath = item.profiles?.avatar_path;
  if (avatarPath) {
    return `<div class="app-candidate-avatar" data-avatar-path="${escapeHtml(avatarPath)}">${escapeHtml(initials)}</div>`;
  }
  return `<div class="app-candidate-avatar">${escapeHtml(initials)}</div>`;
}

function renderApplications(target, items) {
  if (!target) return;
  if (!items.length) {
    renderEmptyState(target, 'Aucune candidature', "Les candidatures UNIBOX apparaîtront ici dès qu'elles existeront.");
    return;
  }

  target.innerHTML = items.map((item) => {
    const listingTitle = item.offers?.title || item.minute_jobs?.title || 'Annonce UNIBOX';
    const listingType = item.listing_type === 'minute_job' ? 'Job minute' : 'Offre entreprise';
    const docsCount = (item.application_documents || []).length;
    const candidateName = item.profiles?.full_name || 'Candidat UNIBOX';
    const candidateEmail = item.profiles?.email || '';
    const candidateCity = item.profiles?.city || '';
    return `
      <article class="app-card" data-app-status="${escapeHtml(item.status || '')}">
        <div class="app-card-inner">
          <div class="app-card-avatar-col">
            ${candidateAvatarHtml(item)}
          </div>
          <div class="app-card-body">
            <div class="app-card-top">
              <div>
                <h3 class="app-card-name">${escapeHtml(candidateName)}</h3>
                <p class="app-card-job">${escapeHtml(listingTitle)}</p>
              </div>
            </div>
            <div class="app-card-meta">
              ${statusPill(item.status)}
              <span class="pill soft">${escapeHtml(listingType)}</span>
              ${candidateEmail ? `<span class="pill soft">${escapeHtml(candidateEmail)}</span>` : ''}
              ${candidateCity ? `<span class="pill soft">${escapeHtml(candidateCity)}</span>` : ''}
              <span class="pill soft">${docsCount} doc${docsCount > 1 ? 's' : ''}</span>
            </div>
            <p class="app-card-date">Soumis le ${escapeHtml(formatDateTime(item.submitted_at))}</p>
          </div>
          <div class="app-card-action-col">
            <button class="btn btn-primary" type="button" data-admin-open-application="${item.id}">
              <span class="material-symbols-outlined" style="font-size:16px;">manage_search</span>
              Inspecter
            </button>
          </div>
        </div>
      </article>
    `;
  }).join('');

  // Async hydrate avatars with real images
  qsa('[data-avatar-path]', target).forEach(async (el) => {
    try {
      const url = await getSafeAssetUrl(SUPABASE_CONFIG.buckets.avatars, el.dataset.avatarPath);
      el.innerHTML = `<img src="${url}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    } catch (_) {}
  });
}


function getReportIcon(targetType) {
  const type = (targetType || '').toLowerCase();
  if (type === 'offer') return 'work';
  if (type === 'minute_job') return 'timer';
  if (type === 'profile') return 'person';
  if (type === 'conversation') return 'chat';
  if (type === 'message') return 'message';
  if (type === 'company') return 'business';
  return 'flag';
}

function getReportColor(status) {
  const s = (status || '').toLowerCase();
  if (s === 'open' || s === 'nouveau') return '#dc2626';
  if (s === 'in_review' || s === 'en_cours') return '#f59e0b';
  if (s === 'resolved' || s === 'resolu') return '#10b981';
  if (s === 'dismissed' || s === 'classé') return '#6b7280';
  return '#6b38d4';
}

function getPriorityColor(priority) {
  const p = (priority || '').toLowerCase();
  if (p === 'high' || p === 'urgent' || p === 'critical') return '#dc2626';
  if (p === 'medium') return '#f59e0b';
  return '#6b7280';
}

function renderReports(target, items, options = {}) {
  if (!target) return;
  if (!items.length) {
    target.innerHTML = `
      <div style="text-align: center; padding: 48px 24px;">
        <h3 style="margin: 0 0 8px; font-size: 18px; font-weight: 600; color: #1b1b25;">Aucun signalement</h3>
        <p style="margin: 0; color: #a09ab8; font-size: 14px; line-height: 1.5;">Tout est calme côté modération pour le moment.</p>
      </div>
    `;
    return;
  }

  const showActions = options.showActions !== false;

  target.innerHTML = items.map((item) => {
    const icon = getReportIcon(item.target_type);
    const color = getReportColor(item.status);
    const priorityColor = getPriorityColor(item.priority);

    return `
    <article class="report-card" style="padding: 0; overflow: hidden; border-left: 3px solid ${color};">
      <div style="display: flex; align-items: flex-start; gap: 16px; padding: 18px 20px;">
        <div style="flex-shrink: 0; width: 44px; height: 44px; border-radius: 12px; background: ${color}15; display: grid; place-items: center;">
          <span class="material-symbols-outlined" style="font-size: 22px; color: ${color};">${icon}</span>
        </div>
        <div style="flex: 1; min-width: 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 4px;">
            <h3 style="margin: 0; font-size: 15px; font-weight: 600; color: #1b1b25; line-height: 1.4;">${escapeHtml(getReportTargetDisplay(item))}</h3>
            <div style="display: flex; gap: 6px; flex-shrink: 0;">
              <span class="pill" style="background: ${color}15; color: ${color}; border: 1px solid ${color}30; font-size: 11px; font-weight: 600; padding: 3px 10px; border-radius: 20px;">${escapeHtml(formatReportStatus(item.status))}</span>
              <span class="pill" style="background: ${priorityColor}15; color: ${priorityColor}; border: 1px solid ${priorityColor}30; font-size: 11px; font-weight: 600; padding: 3px 10px; border-radius: 20px;">${escapeHtml(item.priority || 'normal')}</span>
            </div>
          </div>
          <p style="margin: 0 0 8px; color: #5d576c; font-size: 14px; line-height: 1.5;">${escapeHtml(item.description || item.reason_code || 'Signalement UNIBOX')}</p>
          <div style="display: flex; flex-wrap: wrap; gap: 8px; align-items: center;">
            <span class="pill soft" style="font-size: 11px;">${escapeHtml(item.target_type || 'target')}</span>
            <span class="pill soft" style="font-size: 11px;">${escapeHtml(item.reason_code || 'motif')}</span>
            <span style="font-size: 12px; color: #a09ab8; display: flex; align-items: center; gap: 4px;">
              <span class="material-symbols-outlined" style="font-size: 14px;">person</span>
              ${escapeHtml(item.reporter?.full_name || item.reporter?.email || 'Utilisateur UNIBOX')}
            </span>
            <span style="font-size: 12px; color: #a09ab8; display: flex; align-items: center; gap: 4px;">
              <span class="material-symbols-outlined" style="font-size: 14px;">schedule</span>
              ${escapeHtml(formatDateTime(item.created_at))}
            </span>
          </div>
        </div>
      </div>
      ${showActions ? `
        <div style="display: flex; gap: 8px; padding: 0 20px 14px 80px; flex-wrap: wrap;">
          <button class="btn btn-secondary" type="button" data-admin-assign-report="${item.id}" style="padding: 6px 14px; font-size: 13px;">M'assigner</button>
          <button class="btn btn-primary" type="button" data-admin-open-case="${item.id}" style="padding: 6px 14px; font-size: 13px;">Ouvrir un dossier</button>
          <button class="btn btn-secondary" type="button" data-admin-resolve-report="${item.id}" style="padding: 6px 14px; font-size: 13px;">Résoudre</button>
          <button class="btn btn-secondary" type="button" data-admin-dismiss-report="${item.id}" style="padding: 6px 14px; font-size: 13px;">Classer</button>
        </div>
      ` : ''}
    </article>
  `}).join('');
}

function getCaseColor(status) {
  const s = (status || '').toLowerCase();
  if (s === 'open' || s === 'nouveau') return '#dc2626';
  if (s === 'in_review' || s === 'en_cours') return '#f59e0b';
  if (s === 'resolved' || s === 'resolu') return '#10b981';
  if (s === 'closed' || s === 'fermé') return '#6b7280';
  return '#6b38d4';
}

function renderCases(target, items) {
  if (!target) return;
  if (!items.length) {
    target.innerHTML = `
      <div style="text-align: center; padding: 48px 24px;">
        <span class="material-symbols-outlined" style="font-size: 56px; color: #ddd6ea; margin-bottom: 16px; display: block;">folder_off</span>
        <h3 style="margin: 0 0 8px; font-size: 18px; font-weight: 600; color: #1b1b25;">Aucun dossier</h3>
        <p style="margin: 0; color: #a09ab8; font-size: 14px; line-height: 1.5;">Aucun dossier de modération ouvert pour le moment.</p>
      </div>
    `;
    return;
  }

  target.innerHTML = items.map((item) => {
    const color = getCaseColor(item.status);

    return `
    <article class="data-card" style="padding: 0; overflow: hidden; border-left: 3px solid ${color};">
      <div style="display: flex; align-items: flex-start; gap: 16px; padding: 18px 20px;">
        <div style="flex-shrink: 0; width: 44px; height: 44px; border-radius: 12px; background: ${color}15; display: grid; place-items: center;">
          <span class="material-symbols-outlined" style="font-size: 22px; color: ${color};">folder</span>
        </div>
        <div style="flex: 1; min-width: 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 4px;">
            <h3 style="margin: 0; font-size: 15px; font-weight: 600; color: #1b1b25; line-height: 1.4;">Dossier ${escapeHtml(item.id.slice(0, 8))}</h3>
            <span class="pill" style="background: ${color}15; color: ${color}; border: 1px solid ${color}30; font-size: 11px; font-weight: 600; padding: 3px 10px; border-radius: 20px; flex-shrink: 0;">${escapeHtml(formatCaseStatus(item.status))}</span>
          </div>
          <p style="margin: 0 0 8px; color: #5d576c; font-size: 14px; line-height: 1.5;">${escapeHtml(item.decision_note || item.internal_note || 'Dossier de modération UNIBOX')}</p>
          <div style="display: flex; flex-wrap: wrap; gap: 8px; align-items: center;">
            <span class="pill soft" style="font-size: 11px;">${escapeHtml(item.action_type || 'none')}</span>
            <span class="pill soft" style="font-size: 11px;">Report ${escapeHtml((item.report_id || '').slice(0, 8))}</span>
          </div>
        </div>
      </div>
      <div style="display: flex; gap: 8px; padding: 0 20px 14px 80px; flex-wrap: wrap;">
        <button class="btn btn-secondary" type="button" data-admin-resolve-case="${item.id}" style="padding: 6px 14px; font-size: 13px;">Résoudre</button>
        <button class="btn btn-secondary" type="button" data-admin-reopen-case="${item.id}" style="padding: 6px 14px; font-size: 13px;">Réouvrir</button>
      </div>
    </article>
  `}).join('');
}

function getNotificationIcon(title = '', body = '') {
  const text = (title + ' ' + body).toLowerCase();
  if (text.includes('alert') || text.includes('warning') || text.includes('danger')) return 'warning';
  if (text.includes('report') || text.includes('signalement')) return 'flag';
  if (text.includes('user') || text.includes('compte')) return 'person';
  if (text.includes('moderation') || text.includes('modération')) return 'shield';
  if (text.includes('system') || text.includes('erreur')) return 'bug_report';
  return 'notifications';
}

function getNotificationColor(title = '', body = '') {
  const text = (title + ' ' + body).toLowerCase();
  if (text.includes('alert') || text.includes('warning') || text.includes('danger')) return '#dc2626';
  if (text.includes('report') || text.includes('signalement')) return '#f59e0b';
  if (text.includes('user') || text.includes('compte')) return '#6b38d4';
  if (text.includes('moderation') || text.includes('modération')) return '#0ea5e9';
  if (text.includes('system') || text.includes('erreur')) return '#ec4899';
  return '#6b7280';
}

function renderNotifications(target, items) {
  if (!target) return;
  if (!items.length) {
    target.innerHTML = `
      <div style="text-align: center; padding: 48px 24px;">
        <span class="material-symbols-outlined" style="font-size: 56px; color: #ddd6ea; margin-bottom: 16px; display: block;">notifications_off</span>
        <h3 style="margin: 0 0 8px; font-size: 18px; font-weight: 600; color: #1b1b25;">Aucune notification</h3>
        <p style="margin: 0; color: #a09ab8; font-size: 14px; line-height: 1.5;">Les alertes critiques, signalements et événements de modération apparaîtront ici.</p>
      </div>
    `;
    return;
  }

  target.innerHTML = items.map((item) => {
    const icon = getNotificationIcon(item.title, item.body);
    const color = getNotificationColor(item.title, item.body);
    const isNew = !item.is_read;
    const timeAgo = formatDateTime(item.created_at);

    return `
    <article class="notification-card" style="${isNew ? 'border-left: 3px solid ' + color + '; background: linear-gradient(135deg, #f8f6ff 0%, #ffffff 100%);' : ''} padding: 0; overflow: hidden;">
      <div style="display: flex; align-items: flex-start; gap: 16px; padding: 18px 20px;">
        <div style="flex-shrink: 0; width: 44px; height: 44px; border-radius: 12px; background: ${isNew ? color + '15' : '#f5f2ff'}; display: grid; place-items: center;">
          <span class="material-symbols-outlined" style="font-size: 22px; color: ${color};">${icon}</span>
        </div>
        <div style="flex: 1; min-width: 0;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 4px;">
            <h3 style="margin: 0; font-size: 15px; font-weight: 600; color: #1b1b25; line-height: 1.4;">${escapeHtml(item.title)}</h3>
            ${isNew ? `<span style="flex-shrink: 0; width: 8px; height: 8px; border-radius: 50%; background: ${color}; margin-top: 6px;"></span>` : ''}
          </div>
          <p style="margin: 0 0 8px; color: #5d576c; font-size: 14px; line-height: 1.5;">${escapeHtml(item.body || '')}</p>
          <span style="font-size: 12px; color: #a09ab8; display: flex; align-items: center; gap: 4px;">
            <span class="material-symbols-outlined" style="font-size: 14px;">schedule</span>
            ${escapeHtml(timeAgo)}
          </span>
        </div>
      </div>
      <div style="display: flex; gap: 8px; padding: 0 20px 14px 80px;">
        ${item.action_url ? `<a class="btn btn-primary" href="${item.action_url}" style="padding: 6px 14px; font-size: 13px;">Ouvrir</a>` : ''}
        ${isNew ? `<button class="btn btn-secondary" type="button" data-admin-read-notification="${item.id}" style="padding: 6px 14px; font-size: 13px;">Marquer comme lu</button>` : ''}
      </div>
    </article>
  `}).join('');
}

function renderLogs(target, items) {
  if (!target) return;
  if (!items.length) {
    renderEmptyState(target, 'Historique vide', 'Aucune action admin journalisée pour le moment.');
    return;
  }

  target.innerHTML = `
    <div style="position: relative; padding-left: 24px;">
      <div style="position: absolute; left: 11px; top: 8px; bottom: 8px; width: 2px; background: linear-gradient(to bottom, #ddd6ea, #ede9f8); border-radius: 1px;"></div>
      ${items.map((item, index) => {
        const icon = item.action_type?.includes('delete') || item.action_type?.includes('restrict') ? 'block' : 
                     item.action_type?.includes('validate') || item.action_type?.includes('approve') ? 'check_circle' : 
                     'settings';
        const color = item.action_type?.includes('delete') || item.action_type?.includes('restrict') ? '#dc2626' :
                      item.action_type?.includes('validate') || item.action_type?.includes('approve') ? '#059669' : '#6b38d4';
        return `
          <div style="position: relative; margin-bottom: 20px;">
            <div style="position: absolute; left: -19px; top: 2px; width: 16px; height: 16px; border-radius: 50%; background: ${color}; border: 3px solid #fff; box-shadow: 0 0 0 2px ${color}33; z-index: 1;"></div>
            <div style="background: #f8f6ff; border-radius: 12px; padding: 18px 20px; border: 1px solid #ede9f8; display: flex; gap: 16px; align-items: flex-start;">
              <div style="width: 42px; height: 42px; border-radius: 10px; background: linear-gradient(135deg, ${color}, ${color}cc); display: grid; place-items: center; flex-shrink: 0;">
                <span class="material-symbols-outlined" style="font-size: 20px; color: #fff;">${icon}</span>
              </div>
              <div style="flex: 1; min-width: 0;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 4px;">
                  <h4 style="margin: 0; font-size: 15px; font-weight: 600; color: #1b1b25;">${escapeHtml(item.action_type)}</h4>
                  <span style="font-size: 11px; color: #a09ab8; white-space: nowrap;">${escapeHtml(formatDateTime(item.created_at))}</span>
                </div>
                <p style="margin: 0; color: #5d576c; font-size: 13px; line-height: 1.5;">${escapeHtml(item.target_table || 'plateforme')}</p>
              </div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

async function bindCommonAdminActions() {
  qsa('[data-admin-restrict]').forEach((button) => {
    button.addEventListener('click', async () => {
      const id = button.dataset.adminRestrict;
      const kind = button.dataset.adminKind;
      try {
        if (kind === 'company') {
          await updateAdminCompanyStatus(id, 'suspended');
        } else {
          await updateAdminAccountStatus(id, 'restricted');
        }
        appToast('Action admin appliquée', 'success');
        window.location.reload();
      } catch (error) {
        appToast(error.message || 'Action impossible', 'error');
      }
    });
  });

  qsa('[data-admin-activate]').forEach((button) => {
    button.addEventListener('click', async () => {
      const id = button.dataset.adminActivate;
      const kind = button.dataset.adminKind;
      try {
        if (kind === 'company') {
          await updateAdminCompanyStatus(id, 'active');
        } else {
          await updateAdminAccountStatus(id, 'active');
        }
        appToast('Action admin appliquée', 'success');
        window.location.reload();
      } catch (error) {
        appToast(error.message || 'Action impossible', 'error');
      }
    });
  });

  qsa('[data-admin-hide-item]').forEach((button) => {
    button.addEventListener('click', async () => {
      const id = button.dataset.adminHideItem;
      const type = button.dataset.adminType;
      const reason = window.prompt('Raison du masquage', 'Masquée par l’admin UNIBOX') || 'Masquée par l’admin UNIBOX';
      try {
        if (type === 'offer') {
          await updateAdminOfferVisibility(id, true, reason);
        } else {
          await updateAdminMinuteJobVisibility(id, true, reason);
        }
        appToast('Contenu masqué', 'success');
        window.location.reload();
      } catch (error) {
        appToast(error.message || 'Action impossible', 'error');
      }
    });
  });

  qsa('[data-admin-show-item]').forEach((button) => {
    button.addEventListener('click', async () => {
      const id = button.dataset.adminShowItem;
      const type = button.dataset.adminType;
      try {
        if (type === 'offer') {
          await updateAdminOfferVisibility(id, false, '');
        } else {
          await updateAdminMinuteJobVisibility(id, false, '');
        }
        appToast('Contenu rétabli', 'success');
        window.location.reload();
      } catch (error) {
        appToast(error.message || 'Action impossible', 'error');
      }
    });
  });
}

async function initDashboard() {
  const [students, companies, particulars, reports, applications] = await Promise.all([
    listAdminProfilesByRole('student'),
    listAdminCompanies(),
    listAdminProfilesByRole('particular'),
    listAdminReports(),
    listAdminApplications(),
  ]);

  const kpis = {
    students: students.length,
    companies: companies.length,
    particulars: particulars.length,
    reports: reports.length,
    flagged: reports.filter((item) => ['open', 'in_review'].includes(item.status)).length,
  };

  Object.entries(kpis).forEach(([key, value]) => {
    const node = qs(`[data-kpi="${key}"]`);
    if (node) node.textContent = String(value);
  });

  const queueTarget = qs('#adminDashboardQueue');
  const queueItems = [
    ...reports.filter((item) => item.status === 'open').slice(0, 3).map((item) => ({
      title: 'Signalement à traiter',
      text: `${getReportTargetDisplay(item)} · ${item.reason_code}`,
    })),
    ...companies.filter((item) => item.status === 'pending_review').slice(0, 2).map((item) => ({
      title: 'Entreprise à valider',
      text: `${item.name} · ${item.city || 'Localisation à compléter'}`,
    })),
    ...applications.slice(0, 2).map((item) => ({
      title: 'Candidature récente',
      text: `${item.profiles?.full_name || 'Étudiant'} → ${item.offers?.title || item.minute_jobs?.title || 'Annonce'}`,
    })),
  ].slice(0, 6);

  if (!queueItems.length) {
    renderEmptyState(queueTarget, 'Rien à traiter', 'Le cockpit admin est calme pour le moment.');
    return;
  }

  queueTarget.innerHTML = queueItems.map((item) => `
    <article class="queue-card">
      <h3 class="card-title">${escapeHtml(item.title)}</h3>
      <p class="card-subtitle">${escapeHtml(item.text)}</p>
    </article>
  `).join('');
}

async function initStudents() {
  renderProfiles(qs('#adminStudentsList'), await listAdminProfilesByRole('student'), 'profile');
}

async function initCompanies() {
  renderProfiles(qs('#adminCompaniesList'), await listAdminCompanies(), 'company');
}

async function initParticulars() {
  renderProfiles(qs('#adminParticularsList'), await listAdminProfilesByRole('particular'), 'profile');
}

async function initOffers() {
  const [offers, jobs] = await Promise.all([listAdminOffers(), listAdminMinuteJobs()]);
  renderListings(qs('#adminOffersList'), offers, 'offer');
  renderListings(qs('#adminMinuteJobsList'), jobs, 'minute_job');
}

async function openApplicationInspector(applicationId) {
  const modal = qs('#adminApplicationModal');
  const body = qs('#adminApplicationModalBody');
  if (!modal || !body) {
    console.error('Modal adminApplicationModal ou adminApplicationModalBody introuvable dans le DOM');
    appToast('Impossible d\'ouvrir l\'inspecteur. Recharge la page.', 'error');
    return;
  }

  body.innerHTML = '<div class="empty-state small"><strong>Chargement...</strong><span>Inspection de la candidature UNIBOX en cours.</span></div>';
  openModal('adminApplicationModal');

  try {
    console.log('[DEBUG] openApplicationInspector appId:', applicationId);
    const application = await getApplication(applicationId);
    console.log('[DEBUG] application:', application);
    const profile = application.profiles || {};
    const studentProfile = application.student_profile || {};
    console.log('[DEBUG] profile:', profile);
    const initials = (profile.full_name || 'C').split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();

    let avatarHtml = `<div class="modal-candidate-avatar">${escapeHtml(initials)}</div>`;
    if (profile.avatar_path) {
      try {
        const avatarUrl = await getSafeAssetUrl(SUPABASE_CONFIG.buckets.avatars, profile.avatar_path);
        avatarHtml = `<div class="modal-candidate-avatar"><img src="${avatarUrl}" alt="Avatar" style="width:100%;height:100%;border-radius:50%;object-fit:cover;"></div>`;
      } catch (_) {}
    }

    const docs = (application.application_documents || []).map((doc) => `
      <li class="modal-doc-item">
        <span class="material-symbols-outlined" style="font-size:16px;color:#6b38d4;flex-shrink:0;">description</span>
        <a href="${escapeHtml(doc.signed_url || '#')}" target="_blank" rel="noreferrer" style="color:#6b38d4;font-weight:500;word-break:break-all;">${escapeHtml(doc.file_name || 'Document')}</a>
      </li>
    `).join('') || '<li style="color:#5d576c;padding:8px 0;">Aucun document soumis</li>';

    const statuses = (application.application_status_events || []).map((ev) => {
      const s = APP_STATUS_STYLE[ev.status] || { label: ev.status, color: '#5d576c' };
      return `<li class="modal-status-event"><span style="color:${s.color};font-weight:600;">${escapeHtml(s.label)}</span><span class="modal-status-date">${escapeHtml(formatDateTime(ev.created_at))}</span></li>`;
    }).join('') || '<li style="color:#5d576c;padding:8px 0;">Aucun historique de statut</li>';

    const listingTitle = escapeHtml(application.offers?.title || application.minute_jobs?.title || 'Annonce UNIBOX');
    const listingType = application.listing_type === 'minute_job' ? 'Job minute' : 'Offre entreprise';

    console.log('[DEBUG] generating modal HTML...');
    body.innerHTML = `
      <!-- Header candidat -->
      <div style="display:flex;align-items:flex-start;gap:18px;padding:0 0 20px;border-bottom:1px solid #ede9f8;">
        ${avatarHtml}
        <div style="flex:1;min-width:0;">
          <h4 class="modal-candidate-name">${escapeHtml(profile.full_name || 'Etudiant UNIBOX')}</h4>
          <p class="modal-candidate-sub">${escapeHtml(profile.email || '')}</p>
          <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;">
            ${profile.city ? `<span class="pill soft"><span class="material-symbols-outlined" style="font-size:13px;">location_on</span> ${escapeHtml(profile.city)}</span>` : ''}
            ${statusPill(application.status)}
            <span class="pill soft">${escapeHtml(listingType)}</span>
            <span class="pill soft">Soumis le ${escapeHtml(formatDateTime(application.submitted_at))}</span>
          </div>
        </div>
      </div>

      <!-- Mission -->
      <div style="padding:20px 0;border-bottom:1px solid #ede9f8;">
        <p style="margin:0 0 6px;font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Mission</p>
        <h3 style="margin:0;font-size:16px;font-weight:700;color:#1b1b25;">${listingTitle}</h3>
        ${application.message_body ? `<p style="margin:12px 0 0;font-size:14px;color:#5d576c;font-style:italic;border-left:3px solid #6b38d4;padding-left:12px;line-height:1.5;">${escapeHtml(application.message_body)}</p>` : ''}
      </div>

      <!-- Documents & Historique -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;padding:20px 0;border-bottom:1px solid #ede9f8;">
        <div>
          <h4 style="margin:0 0 14px;font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Documents soumis</h4>
          <ul class="modal-doc-list">${docs}</ul>
        </div>
        <div>
          <h4 style="margin:0 0 14px;font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Historique des statuts</h4>
          <ul class="modal-status-list">${statuses}</ul>
        </div>
      </div>

      <!-- Profil étudiant -->
      ${studentProfile?.bio || studentProfile?.skills || studentProfile?.headline ? `
      <div style="border-top:1px solid #ede9f8;padding-top:20px;">
        <h4 style="margin:0 0 12px;font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:#8b85a0;font-weight:700;">Profil étudiant</h4>
        <div style="display:flex;flex-direction:column;">
          ${studentProfile.headline ? `
          <div style="padding:10px 0;border-bottom:1px solid #ede9f8;">
            <div style="font-size:11px;color:#8b85a0;text-transform:uppercase;letter-spacing:.03em;font-weight:600;">Titre</div>
            <div style="font-size:14px;color:#1b1b25;font-weight:500;margin-top:2px;">${escapeHtml(studentProfile.headline)}</div>
          </div>` : ''}
          ${studentProfile.skills ? `
          <div style="padding:10px 0;border-bottom:1px solid #ede9f8;">
            <div style="font-size:11px;color:#8b85a0;text-transform:uppercase;letter-spacing:.03em;font-weight:600;">Compétences</div>
            <div style="font-size:14px;color:#1b1b25;margin-top:2px;">${escapeHtml(studentProfile.skills)}</div>
          </div>` : ''}
          ${studentProfile.study_level ? `
          <div style="padding:10px 0;border-bottom:1px solid #ede9f8;">
            <div style="font-size:11px;color:#8b85a0;text-transform:uppercase;letter-spacing:.03em;font-weight:600;">Niveau d'études</div>
            <div style="font-size:14px;color:#1b1b25;margin-top:2px;">${escapeHtml(studentProfile.study_level)}</div>
          </div>` : ''}
          ${studentProfile.bio ? `
          <div style="padding:10px 0;">
            <div style="font-size:11px;color:#8b85a0;text-transform:uppercase;letter-spacing:.03em;font-weight:600;">Biographie</div>
            <div style="font-size:14px;color:#5d576c;line-height:1.5;margin-top:2px;">${escapeHtml(studentProfile.bio)}</div>
          </div>` : ''}
        </div>
      </div>` : ''}
    `;
    console.log('[DEBUG] modal HTML set, body length:', body.innerHTML.length);
    console.log('[DEBUG] modal class:', modal.className);
    console.log('[DEBUG] modal display:', getComputedStyle(modal).display);
  } catch (error) {
    console.error('[DEBUG] ERROR in openApplicationInspector:', error);
    body.innerHTML = `<div class="empty-state small"><strong>Inspection impossible</strong><span>${escapeHtml(error.message || 'Reessaie dans un instant.')}</span></div>`;
  }
}

async function initApplications() {
  const result = await listAdminApplications();
  const allItems = result?.data ?? (Array.isArray(result) ? result : []);

  const countPill = qs('#adminApplicationsCount');
  if (countPill) countPill.textContent = `${allItems.length} candidature${allItems.length > 1 ? 's' : ''}`;

  function bindInspectButtons() {
    qsa('[data-admin-open-application]').forEach((button) => {
      button.addEventListener('click', () => openApplicationInspector(button.dataset.adminOpenApplication));
    });
  }

  function applyFilter(status) {
    const filtered = status === 'all'
      ? allItems
      : allItems.filter(i => {
          if (status === 'submitted') return ['submitted', 'under_review', 'shortlisted', 'interview_requested'].includes(i.status);
          return i.status === status;
        });
    renderApplications(qs('#adminApplicationsList'), filtered);
    bindInspectButtons();
  }

  renderApplications(qs('#adminApplicationsList'), allItems);
  bindInspectButtons();

  qsa('[data-app-status-filter]').forEach((chip) => {
    chip.addEventListener('click', () => {
      qsa('[data-app-status-filter]').forEach(c => c.classList.remove('is-active'));
      chip.classList.add('is-active');
      applyFilter(chip.dataset.appStatusFilter);
    });
  });
}

function prefillCaseModal(reportId) {
  const field = qs('#adminCaseReportId');
  if (field) field.value = reportId;
  openModal('moderationCaseModal');
}

async function bindReportActions() {
  qsa('[data-admin-assign-report]').forEach((button) => {
    button.addEventListener('click', async () => {
      try {
        await assignAdminReportToMe(button.dataset.adminAssignReport);
        appToast('Signalement assigné', 'success');
        window.location.reload();
      } catch (error) {
        appToast(error.message || 'Impossible d’assigner le signalement.', 'error');
      }
    });
  });

  qsa('[data-admin-open-case]').forEach((button) => {
    button.addEventListener('click', () => prefillCaseModal(button.dataset.adminOpenCase));
  });

  qsa('[data-admin-resolve-report]').forEach((button) => {
    button.addEventListener('click', async () => {
      const note = window.prompt('Note de résolution', 'Signalement traité par l’admin UNIBOX') || '';
      try {
        await resolveAdminReport(button.dataset.adminResolveReport, note);
        appToast('Signalement résolu', 'success');
        window.location.reload();
      } catch (error) {
        appToast(error.message || 'Impossible de résoudre le signalement.', 'error');
      }
    });
  });

  qsa('[data-admin-dismiss-report]').forEach((button) => {
    button.addEventListener('click', async () => {
      const note = window.prompt('Note de classement', 'Signalement classé par l’admin UNIBOX') || '';
      try {
        await dismissAdminReport(button.dataset.adminDismissReport, note);
        appToast('Signalement classé', 'success');
        window.location.reload();
      } catch (error) {
        appToast(error.message || 'Impossible de classer le signalement.', 'error');
      }
    });
  });
}

async function initReports() {
  const items = await listAdminReports();
  renderReports(qs('#adminReportsList'), items, { showActions: true });
  await bindReportActions();
}

async function initModeration() {
  const [reports, cases] = await Promise.all([listAdminReports(), listAdminModerationCases()]);
  renderReports(qs('#adminModerationReports'), reports.filter((item) => ['open', 'in_review'].includes(item.status)), { showActions: true });
  renderCases(qs('#adminModerationCases'), cases);
  await bindReportActions();

  qsa('[data-admin-resolve-case]').forEach((button) => {
    button.addEventListener('click', async () => {
      try {
        await updateAdminModerationCase(button.dataset.adminResolveCase, { status: 'resolved', resolved_at: new Date().toISOString() });
        appToast('Dossier résolu', 'success');
        window.location.reload();
      } catch (error) {
        appToast(error.message || 'Impossible de résoudre le dossier.', 'error');
      }
    });
  });

  qsa('[data-admin-reopen-case]').forEach((button) => {
    button.addEventListener('click', async () => {
      try {
        await updateAdminModerationCase(button.dataset.adminReopenCase, { status: 'open', resolved_at: null });
        appToast('Dossier réouvert', 'success');
        window.location.reload();
      } catch (error) {
        appToast(error.message || 'Impossible de réouvrir le dossier.', 'error');
      }
    });
  });

  qs('#adminCreateCaseButton')?.addEventListener('click', async () => {
    const reportId = qs('#adminCaseReportId')?.value?.trim();
    const actionType = qs('#adminCaseActionType')?.value || 'none';
    const decisionNote = qs('#adminCaseDecision')?.value?.trim() || '';
    const internalNote = qs('#adminCaseNote')?.value?.trim() || '';
    const button = qs('#adminCreateCaseButton');

    if (!reportId) {
      appToast('Sélectionne un signalement avant de créer un dossier.', 'warning');
      return;
    }

    try {
      setLoading(button, true, 'Création...');
      await createAdminModerationCase({
        report_id: reportId,
        action_type: actionType,
        decision_note: decisionNote,
        internal_note: internalNote,
      });
      appToast('Dossier de modération créé', 'success');
      closeModal(qs('#moderationCaseModal'));
      window.location.reload();
    } catch (error) {
      appToast(error.message || 'Impossible de créer le dossier.', 'error');
    } finally {
      setLoading(button, false);
    }
  });
}

async function initHistory() {
  renderLogs(qs('#adminHistoryList'), await listAdminAuditLogs());
}

async function initNotifications() {
  const mount = qs('#adminNotificationsList');
  const items = await listAdminNotifications();
  renderNotifications(mount, items);

  qsa('[data-admin-read-notification]').forEach((button) => {
    button.addEventListener('click', async () => {
      try {
        await markAdminNotificationRead(button.dataset.adminReadNotification);
        const card = button.closest('.notification-card');
        if (card) {
          card.style.borderLeft = 'none';
          card.style.background = '';
          const dot = card.querySelector('[style*="border-radius: 50%"]');
          if (dot) dot.remove();
        }
        button.remove();
        appToast('Notification admin lue', 'success');
      } catch (error) {
        appToast(error.message || 'Impossible de mettre la notification à jour.', 'error');
      }
    });
  });

  qs('#adminNotificationsMarkAll')?.addEventListener('click', async () => {
    try {
      await markAllAdminNotificationsRead();
      qsa('[data-admin-read-notification]').forEach((button) => button.remove());
      qsa('#adminNotificationsList .notification-card').forEach((card) => {
        card.style.borderLeft = 'none';
        card.style.background = '';
        const dot = card.querySelector('[style*="border-radius: 50%"]');
        if (dot) dot.remove();
      });
      appToast('Toutes les notifications admin sont à jour', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible de marquer les notifications comme lues.', 'error');
    }
  });
}

async function initSettings() {
  const profile = await getCurrentProfile().catch(() => null);
  const roleProfile = profile ? await getRoleProfile('admin', profile.id).catch(() => null) : null;

  if (qs('#adminFullName') && profile) qs('#adminFullName').value = profile.full_name || '';
  if (qs('#adminEmail') && profile) qs('#adminEmail').value = profile.email || '';
  if (qs('#adminCity') && profile) qs('#adminCity').value = profile.city || '';
  if (qs('#adminAccessLevel') && roleProfile) qs('#adminAccessLevel').value = roleProfile.access_level || 'platform_admin';

  qs('#adminSettingsForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const button = qs('#adminSettingsSave');
    try {
      setLoading(button, true, 'Enregistrement...');
      await saveAdminSettings({
        full_name: qs('#adminFullName')?.value.trim(),
        city: qs('#adminCity')?.value.trim(),
        access_level: qs('#adminAccessLevel')?.value.trim(),
      });
      appToast('Paramètres admin enregistrés', 'success');
    } catch (error) {
      appToast(error.message || 'Impossible d’enregistrer les paramètres.', 'error');
    } finally {
      setLoading(button, false);
    }
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  await mountAdminShell();
  initModals();

  const page = document.body.dataset.page;
  try {
    if (page === 'admin-dashboard') await initDashboard();
    if (page === 'admin-students') await initStudents();
    if (page === 'admin-companies') await initCompanies();
    if (page === 'admin-particulars') await initParticulars();
    if (page === 'admin-offers') await initOffers();
    if (page === 'admin-applications') await initApplications();
    if (page === 'admin-reports') await initReports();
    if (page === 'admin-moderation') await initModeration();
    if (page === 'admin-history') await initHistory();
    if (page === 'admin-notifications') await initNotifications();
    if (page === 'admin-settings') await initSettings();
    await bindCommonAdminActions();
  } catch (error) {
    appToast(error.message || 'Impossible de charger le back-office admin.', 'error');
  }
});
