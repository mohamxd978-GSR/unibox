import { mountAppShell, bindPasswordToggles } from '/assets/js/unibox-core.js';

document.addEventListener('DOMContentLoaded', () => {
  mountAppShell();
  bindPasswordToggles();
});
